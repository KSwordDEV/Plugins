/*++

Module Name:

    platform_audit.c

Abstract:

    HAL 与 KMDF 绑定表审计，以及两者函数槽的受控原子编辑。KMDF 绑定表位于
    Wdf01000.sys 的只读节，提交路径会为它建立临时 MDL 可写别名。

Environment:

    Kernel-mode Driver Framework

--*/

#include "ark/ark_driver.h"
#include "driver/KswordArkPlatformAuditIoctl.h"
#include "../kernel/hook_scan_support.h"
#include "../../dispatch/ioctl_validation.h"

#include <ntimage.h>
#include <ntstrsafe.h>
#include <stdarg.h>

// ntddk.h exposes these HAL_DISPATCH members as object-like convenience
// macros.  Undefine the aliases in this translation unit so FIELD_OFFSET and
// member-size expressions below refer to the actual structure fields.
#undef HalQuerySystemInformation
#undef HalSetSystemInformation
#undef HalQueryBusSlots
#undef HalReferenceHandlerForBus
#undef HalReferenceBusHandler
#undef HalDereferenceBusHandler
#undef HalInitPnpDriver
#undef HalInitPowerManagement
#undef HalGetDmaAdapter
#undef HalGetInterruptTranslator
#undef HalStartMirroring
#undef HalEndMirroring
#undef HalMirrorPhysicalMemory
#undef HalEndOfBoot
#undef HalMirrorVerify
#undef HalGetCachedAcpiTable
#undef HalSetPciErrorHandlerCallback
#undef HalGetPrmCache
#undef HalInvokePrmFwHandler

#define KSW_PLATFORM_RESPONSE_HEADER_SIZE \
    (FIELD_OFFSET(KSWORD_ARK_QUERY_PLATFORM_AUDIT_RESPONSE, entries))
// 中文说明：内存中的 ULONG 值是 0x48414C20；不要按 ASCII "HAL "
// 的字节展示顺序误写成 0x204C4148，否则所有真实表都会被拒绝。
#define KSW_PLATFORM_HAL_ACPI_SIGNATURE 0x48414C20UL
#define KSW_PLATFORM_HAL_ACPI_VERSION_V4 4UL
#define KSW_PLATFORM_HAL_ACPI_VERSION_V5 5UL
#define KSW_PLATFORM_HAL_ACPI_V4_FUNCTION_COUNT 21UL
#define KSW_PLATFORM_HAL_ACPI_V5_FUNCTION_COUNT 18UL
#define KSW_PLATFORM_HAL_ACPI_MAX_FUNCTION_COUNT \
    KSW_PLATFORM_HAL_ACPI_V4_FUNCTION_COUNT
#define KSW_PLATFORM_HAL_SUBCOMPONENT_LEGACY_COUNT 21UL
#define KSW_PLATFORM_HAL_SUBCOMPONENT_MAX_COUNT    22UL
#define KSW_PLATFORM_HAL_SUBCOMPONENT_QOS_INDEX    18UL

typedef struct _KSW_PLATFORM_SLOT_DESCRIPTOR
{
    ULONG Offset;
    ULONG Width;
    PCWSTR Name;
    ULONG SlotKind;
    ULONG OwnerPolicy;
} KSW_PLATFORM_SLOT_DESCRIPTOR;

typedef struct _KSW_PLATFORM_PRIVATE_BUILD_DESCRIPTOR
{
    ULONG BuildNumber;
    ULONG Version;
    ULONG ByteSize;
    ULONG SignatureId;
} KSW_PLATFORM_PRIVATE_BUILD_DESCRIPTOR;

typedef struct _KSW_PLATFORM_HAL_ACPI_VIEW
{
    ULONG Signature;
    ULONG Version;
    PVOID Functions[KSW_PLATFORM_HAL_ACPI_MAX_FUNCTION_COUNT];
} KSW_PLATFORM_HAL_ACPI_VIEW;

typedef struct _KSW_PLATFORM_HAL_SUBCOMPONENT
{
    PVOID Function;
    PCWSTR Name;
} KSW_PLATFORM_HAL_SUBCOMPONENT;

typedef struct _KSW_PLATFORM_CALLBACK_DESCRIPTOR
{
    PVOID Address;
    PCWSTR Name;
} KSW_PLATFORM_CALLBACK_DESCRIPTOR;

#define KSW_PLATFORM_WIDE_IMPL(Value) L##Value
#define KSW_PLATFORM_WIDE(Value) KSW_PLATFORM_WIDE_IMPL(#Value)
#define KSW_HAL_PUBLIC_FUNCTION(Field, Policy) \
    { FIELD_OFFSET(HAL_DISPATCH, Field), sizeof(((PHAL_DISPATCH)0)->Field), \
      KSW_PLATFORM_WIDE(Field), KSWORD_ARK_PLATFORM_SLOT_FUNCTION, Policy }
#define KSW_HAL_PUBLIC_SCALAR(Field) \
    { FIELD_OFFSET(HAL_DISPATCH, Field), sizeof(((PHAL_DISPATCH)0)->Field), \
      KSW_PLATFORM_WIDE(Field), KSWORD_ARK_PLATFORM_SLOT_SCALAR, KSWORD_ARK_PLATFORM_OWNER_NONE }

static const KSW_PLATFORM_SLOT_DESCRIPTOR g_KswHalDispatchSlots[] = {
    KSW_HAL_PUBLIC_FUNCTION(HalQuerySystemInformation, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalSetSystemInformation, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalQueryBusSlots, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_SCALAR(Spare1),
    KSW_HAL_PUBLIC_FUNCTION(HalExamineMBR, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalIoReadPartitionTable, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalIoSetPartitionInformation, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalIoWritePartitionTable, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalReferenceHandlerForBus, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalReferenceBusHandler, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalDereferenceBusHandler, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalInitPnpDriver, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalInitPowerManagement, KSWORD_ARK_PLATFORM_OWNER_NT_HAL_ACPI),
    KSW_HAL_PUBLIC_FUNCTION(HalGetDmaAdapter, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalGetInterruptTranslator, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalStartMirroring, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalEndMirroring, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalMirrorPhysicalMemory, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalEndOfBoot, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalMirrorVerify, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalGetCachedAcpiTable, KSWORD_ARK_PLATFORM_OWNER_NT_HAL_ACPI),
    KSW_HAL_PUBLIC_FUNCTION(HalSetPciErrorHandlerCallback, KSWORD_ARK_PLATFORM_OWNER_NT_HAL_PCI),
    KSW_HAL_PUBLIC_FUNCTION(HalGetPrmCache, KSWORD_ARK_PLATFORM_OWNER_NT_HAL),
    KSW_HAL_PUBLIC_FUNCTION(HalInvokePrmFwHandler, KSWORD_ARK_PLATFORM_OWNER_NT_HAL)
};

#undef KSW_HAL_PUBLIC_SCALAR
#undef KSW_HAL_PUBLIC_FUNCTION
#undef KSW_PLATFORM_WIDE
#undef KSW_PLATFORM_WIDE_IMPL

#define KSW_PRIVATE_FUNCTION(OffsetValue, NameValue, PolicyValue) \
    { OffsetValue, sizeof(PVOID), L##NameValue, KSWORD_ARK_PLATFORM_SLOT_FUNCTION, PolicyValue }
#define KSW_PRIVATE_DUMMY(OffsetValue, NameValue) \
    { OffsetValue, sizeof(PVOID), L##NameValue, KSWORD_ARK_PLATFORM_SLOT_DUMMY, KSWORD_ARK_PLATFORM_OWNER_NONE }
#define KSW_PF(OffsetValue, NameValue) \
    KSW_PRIVATE_FUNCTION(OffsetValue, NameValue, KSWORD_ARK_PLATFORM_OWNER_NT_HAL)
#define KSW_PFP(OffsetValue, NameValue) \
    KSW_PRIVATE_FUNCTION(OffsetValue, NameValue, KSWORD_ARK_PLATFORM_OWNER_NT_HAL_PCI)
#define KSW_PFA(OffsetValue, NameValue) \
    KSW_PRIVATE_FUNCTION(OffsetValue, NameValue, KSWORD_ARK_PLATFORM_OWNER_NT_HAL_ACPI)

// 中文说明：该描述表是 ntdiff 22000/22621/26100 结构的共同前缀。
// 每个版本只能读取其 build descriptor 指定的 ByteSize，绝不把尾部或 padding 当函数。
static const KSW_PLATFORM_SLOT_DESCRIPTOR g_KswHalPrivateSlots[] = {
    KSW_PF(0x008, "HalHandlerForBus"),
    KSW_PF(0x010, "HalHandlerForConfigSpace"),
    KSW_PF(0x018, "HalLocateHiberRanges"),
    KSW_PF(0x020, "HalRegisterBusHandler"),
    KSW_PFA(0x028, "HalSetWakeEnable"),
    KSW_PFA(0x030, "HalSetWakeAlarm"),
    KSW_PFP(0x038, "HalPciTranslateBusAddress"),
    KSW_PFP(0x040, "HalPciAssignSlotResources"),
    KSW_PF(0x048, "HalHaltSystem"),
    KSW_PF(0x050, "HalFindBusAddressTranslation"),
    KSW_PF(0x058, "HalResetDisplay"),
    KSW_PF(0x060, "HalAllocateMapRegisters"),
    KSW_PFP(0x068, "KdSetupPciDeviceForDebugging"),
    KSW_PFP(0x070, "KdReleasePciDeviceForDebugging"),
    KSW_PFA(0x078, "KdGetAcpiTablePhase0"),
    KSW_PFA(0x080, "KdCheckPowerButton"),
    KSW_PF(0x088, "HalVectorToIDTEntry"),
    KSW_PF(0x090, "KdMapPhysicalMemory64"),
    KSW_PF(0x098, "KdUnmapVirtualAddress"),
    KSW_PFP(0x0A0, "KdGetPciDataByOffset"),
    KSW_PFP(0x0A8, "KdSetPciDataByOffset"),
    KSW_PFA(0x0B0, "HalGetInterruptVectorOverride"),
    KSW_PFA(0x0B8, "HalGetVectorInputOverride"),
    KSW_PF(0x0C0, "HalLoadMicrocode"),
    KSW_PF(0x0C8, "HalUnloadMicrocode"),
    KSW_PF(0x0D0, "HalPostMicrocodeUpdate"),
    KSW_PFA(0x0D8, "HalAllocateMessageTargetOverride"),
    KSW_PFA(0x0E0, "HalFreeMessageTargetOverride"),
    KSW_PF(0x0E8, "HalDpReplaceBegin"),
    KSW_PF(0x0F0, "HalDpReplaceTarget"),
    KSW_PF(0x0F8, "HalDpReplaceControl"),
    KSW_PF(0x100, "HalDpReplaceEnd"),
    KSW_PF(0x108, "HalPrepareForBugcheck"),
    KSW_PFA(0x110, "HalQueryWakeTime"),
    KSW_PF(0x118, "HalReportIdleStateUsage"),
    KSW_PF(0x120, "HalTscSynchronization"),
    KSW_PF(0x128, "HalWheaInitProcessorGenericSection"),
    KSW_PF(0x130, "HalStopLegacyUsbInterrupts"),
    KSW_PF(0x138, "HalReadWheaPhysicalMemory"),
    KSW_PF(0x140, "HalWriteWheaPhysicalMemory"),
    KSW_PF(0x148, "HalDpMaskLevelTriggeredInterrupts"),
    KSW_PF(0x150, "HalDpUnmaskLevelTriggeredInterrupts"),
    KSW_PF(0x158, "HalDpGetInterruptReplayState"),
    KSW_PF(0x160, "HalDpReplayInterrupts"),
    KSW_PF(0x168, "HalQueryIoPortAccessSupported"),
    KSW_PF(0x170, "KdSetupIntegratedDeviceForDebugging"),
    KSW_PF(0x178, "KdReleaseIntegratedDeviceForDebugging"),
    KSW_PF(0x180, "HalGetEnlightenmentInformation"),
    KSW_PF(0x188, "HalAllocateEarlyPages"),
    KSW_PF(0x190, "HalMapEarlyPages"),
    KSW_PRIVATE_DUMMY(0x198, "Dummy1"),
    KSW_PRIVATE_DUMMY(0x1A0, "Dummy2"),
    KSW_PF(0x1A8, "HalNotifyProcessorFreeze"),
    KSW_PF(0x1B0, "HalPrepareProcessorForIdle"),
    KSW_PF(0x1B8, "HalRegisterLogRoutine"),
    KSW_PF(0x1C0, "HalResumeProcessorFromIdle"),
    KSW_PRIVATE_DUMMY(0x1C8, "Dummy"),
    KSW_PF(0x1D0, "HalVectorToIDTEntryEx"),
    KSW_PF(0x1D8, "HalSecondaryInterruptQueryPrimaryInformation"),
    KSW_PF(0x1E0, "HalMaskInterrupt"),
    KSW_PF(0x1E8, "HalUnmaskInterrupt"),
    KSW_PF(0x1F0, "HalIsInterruptTypeSecondary"),
    KSW_PF(0x1F8, "HalAllocateGsivForSecondaryInterrupt"),
    KSW_PF(0x200, "HalAddInterruptRemapping"),
    KSW_PF(0x208, "HalRemoveInterruptRemapping"),
    KSW_PF(0x210, "HalSaveAndDisableHvEnlightenment"),
    KSW_PF(0x218, "HalRestoreHvEnlightenment"),
    KSW_PF(0x220, "HalFlushIoBuffersExternalCache"),
    KSW_PF(0x228, "HalFlushExternalCache"),
    KSW_PFP(0x230, "HalPciEarlyRestore"),
    KSW_PF(0x238, "HalGetProcessorId"),
    KSW_PF(0x240, "HalAllocatePmcCounterSet"),
    KSW_PF(0x248, "HalCollectPmcCounters"),
    KSW_PF(0x250, "HalFreePmcCounterSet"),
    KSW_PF(0x258, "HalProcessorHalt"),
    KSW_PF(0x260, "HalTimerQueryCycleCounter"),
    KSW_PRIVATE_DUMMY(0x268, "Dummy3"),
    KSW_PFP(0x270, "HalPciMarkHiberPhase"),
    KSW_PF(0x278, "HalQueryProcessorRestartEntryPoint"),
    KSW_PF(0x280, "HalRequestInterrupt"),
    KSW_PF(0x288, "HalEnumerateUnmaskedInterrupts"),
    KSW_PF(0x290, "HalFlushAndInvalidatePageExternalCache"),
    KSW_PF(0x298, "KdEnumerateDebuggingDevices"),
    KSW_PF(0x2A0, "HalFlushIoRectangleExternalCache"),
    KSW_PFA(0x2A8, "HalPowerEarlyRestore"),
    KSW_PF(0x2B0, "HalQueryCapsuleCapabilities"),
    KSW_PF(0x2B8, "HalUpdateCapsule"),
    KSW_PFP(0x2C0, "HalPciMultiStageResumeCapable"),
    KSW_PF(0x2C8, "HalDmaFreeCrashDumpRegisters"),
    KSW_PFA(0x2D0, "HalAcpiAoacCapable"),
    KSW_PF(0x2D8, "HalInterruptSetDestination"),
    KSW_PF(0x2E0, "HalGetClockConfiguration"),
    KSW_PF(0x2E8, "HalClockTimerActivate"),
    KSW_PF(0x2F0, "HalClockTimerInitialize"),
    KSW_PF(0x2F8, "HalClockTimerStop"),
    KSW_PF(0x300, "HalClockTimerArm"),
    KSW_PF(0x308, "HalTimerOnlyClockInterruptPending"),
    KSW_PFA(0x310, "HalAcpiGetMultiNode"),
    KSW_PFA(0x318, "HalPowerSetRebootHandler"),
    KSW_PF(0x320, "HalIommuRegisterDispatchTable"),
    KSW_PF(0x328, "HalTimerWatchdogStart"),
    KSW_PF(0x330, "HalTimerWatchdogResetCountdown"),
    KSW_PF(0x338, "HalTimerWatchdogStop"),
    KSW_PF(0x340, "HalTimerWatchdogGeneratedLastReset"),
    KSW_PF(0x348, "HalTimerWatchdogTriggerSystemReset"),
    KSW_PF(0x350, "HalInterruptVectorDataToGsiv"),
    KSW_PF(0x358, "HalInterruptGetHighestPriorityInterrupt"),
    KSW_PF(0x360, "HalProcessorOn"),
    KSW_PF(0x368, "HalProcessorOff"),
    KSW_PF(0x370, "HalProcessorFreeze"),
    KSW_PF(0x378, "HalDmaLinkDeviceObjectByToken"),
    KSW_PF(0x380, "HalDmaCheckAdapterToken"),
    KSW_PRIVATE_DUMMY(0x388, "Dummy4"),
    KSW_PF(0x390, "HalTimerConvertPerformanceCounterToAuxiliaryCounter"),
    KSW_PF(0x398, "HalTimerConvertAuxiliaryCounterToPerformanceCounter"),
    KSW_PF(0x3A0, "HalTimerQueryAuxiliaryCounterFrequency"),
    KSW_PF(0x3A8, "HalConnectThermalInterrupt"),
    KSW_PF(0x3B0, "HalIsEFIRuntimeActive"),
    KSW_PF(0x3B8, "HalTimerQueryAndResetRtcErrors"),
    KSW_PFA(0x3C0, "HalAcpiLateRestore"),
    KSW_PF(0x3C8, "KdWatchdogDelayExpiration"),
    KSW_PF(0x3D0, "HalGetProcessorStats"),
    KSW_PF(0x3D8, "HalTimerWatchdogQueryDueTime"),
    KSW_PF(0x3E0, "HalConnectSyntheticInterrupt"),
    KSW_PF(0x3E8, "HalPreprocessNmi"),
    KSW_PF(0x3F0, "HalEnumerateEnvironmentVariablesWithFilter"),
    KSW_PF(0x3F8, "HalCaptureLastBranchRecordStack"),
    KSW_PF(0x400, "HalClearLastBranchRecordStack"),
    KSW_PF(0x408, "HalConfigureLastBranchRecord"),
    KSW_PF(0x410, "HalGetLastBranchInformation"),
    KSW_PF(0x418, "HalResumeLastBranchRecord"),
    KSW_PF(0x420, "HalStartLastBranchRecord"),
    KSW_PF(0x428, "HalStopLastBranchRecord"),
    KSW_PF(0x430, "HalIommuBlockDevice"),
    KSW_PF(0x438, "HalIommuUnblockDevice"),
    KSW_PF(0x440, "HalGetIommuInterface"),
    KSW_PF(0x448, "HalRequestGenericErrorRecovery"),
    KSW_PF(0x450, "HalTimerQueryHostPerformanceCounter"),
    KSW_PF(0x458, "HalTopologyQueryProcessorRelationships"),
    KSW_PF(0x460, "HalInitPlatformDebugTriggers"),
    KSW_PF(0x468, "HalRunPlatformDebugTriggers"),
    KSW_PF(0x470, "HalTimerGetReferencePage"),
    KSW_PF(0x478, "HalGetHiddenProcessorPowerInterface"),
    KSW_PF(0x480, "HalGetHiddenProcessorPackageId"),
    KSW_PF(0x488, "HalGetHiddenPackageProcessorCount"),
    KSW_PF(0x490, "HalGetHiddenProcessorApicIdByIndex"),
    KSW_PF(0x498, "HalRegisterHiddenProcessorIdleState"),
    KSW_PF(0x4A0, "HalIommuReportIommuFault"),
    KSW_PF(0x4A8, "HalIommuDmaRemappingCapable"),
    KSW_PF(0x4B0, "HalAllocatePmcCounterSetEx"),
    KSW_PF(0x4B8, "HalStartProfileInterruptEx"),
    KSW_PF(0x4C0, "HalGetIommuInterfaceEx"),
    KSW_PF(0x4C8, "HalNotifyIommuDomainPolicyChange"),
    KSW_PFP(0x4D0, "HalPciGetDeviceLocationFromPhysicalAddress"),
    KSW_PF(0x4D8, "HalInvokeSmc"),
    KSW_PF(0x4E0, "HalInvokeHvc"),
    KSW_PF(0x4E8, "HalGetSoftRebootDatabase"),
    KSW_PF(0x4F0, "HalRequestPmuAccess"),
    KSW_PF(0x4F8, "HalTopologyQueryProcessorCacheInformation"),
    KSW_PF(0x500, "HalReleasePmuAccessRequest"),
    KSW_PF(0x508, "HalTimerQueryRtcErrors"),
    KSW_PFP(0x510, "HalExternalPciConfigSpaceAccess")
};

#undef KSW_PFA
#undef KSW_PFP
#undef KSW_PF
#undef KSW_PRIVATE_DUMMY
#undef KSW_PRIVATE_FUNCTION

static const KSW_PLATFORM_PRIVATE_BUILD_DESCRIPTOR g_KswHalPrivateBuilds[] = {
    // 中文说明：19041～19045 共用 Vibranium 内核结构；运行时仍以 Version=51
    // 和完整 0x4B0 受界范围双重确认，不能只凭系统报告的产品 build 放行。
    { 19041UL, 51UL, 0x4B0UL, KSWORD_ARK_PLATFORM_SIGNATURE_HAL_PRIVATE_V51 },
    { 22000UL, 54UL, 0x4D8UL, KSWORD_ARK_PLATFORM_SIGNATURE_HAL_PRIVATE_V54 },
    { 22621UL, 58UL, 0x4F0UL, KSWORD_ARK_PLATFORM_SIGNATURE_HAL_PRIVATE_V58 },
    { 26100UL, 61UL, 0x518UL, KSWORD_ARK_PLATFORM_SIGNATURE_HAL_PRIVATE_V61 },
    { 26220UL, 61UL, 0x518UL, KSWORD_ARK_PLATFORM_SIGNATURE_HAL_PRIVATE_V61 }
};

static const PCWSTR
g_KswHalAcpiFunctionNames[KSW_PLATFORM_HAL_ACPI_MAX_FUNCTION_COUNT] = {
    // 中文说明：这里展示经公开符号样本核对过的实现语义名，而不是旧头文件
    // 中容易误导的字段别名；槽位顺序仍由 HAL ACPI v5 的结构身份约束。
    L"HalpAcpiTimerInterrupt",
    L"HaliAcpiMachineStateInit",
    L"HalpAcpiQueryFlags",
    L"HalpInterruptIsPicStateIntact",
    L"HalpInterruptRestoreAllControllerState",
    L"HaliPciInterfaceReadConfig",
    L"HaliPciInterfaceWriteConfig",
    L"HalpInterruptGetApicVersion",
    L"HaliSetMaxLegacyPciBusNumber",
    L"HalpInterruptIsGsiValid",
    L"HalAcpiGetTableDispatch",
    L"HalAcpiGetRsdpDispatch",
    L"HalAcpiGetFacsMappingDispatch",
    L"HalAcpiGetAllTablesDispatch",
    L"HalpAcpiPmRegisterAvailable",
    L"HalpAcpiPmRegisterRead",
    L"HalpAcpiPmRegisterWrite",
    L"HalpAcpiAccessSecureAddress",
    // 中文说明：ACPI v4 的尾部还保留三个旧式 PCI I/O 配置读取槽；
    // v5 删除这些槽，因此输出数量必须由表头 Version 决定。
    L"HalpPciReadIoConfigUlong",
    L"HalpPciReadIoConfigUchar",
    L"HalpPciReadIoConfigUshort"
};

static const PCWSTR
g_KswHalSubcomponentNames[KSW_PLATFORM_HAL_SUBCOMPONENT_MAX_COUNT] = {
    L"Acpi", L"Dbg", L"Dma", L"Dp", L"Errata", L"ExtEnv", L"Firmware",
    L"HalExt", L"Hv", L"HwPerfCnt", L"Interrupt", L"Iommu", L"Misc", L"Mm",
    L"Pci", L"Pnp", L"Power", L"Proc", L"Qos", L"Timer", L"Topology", L"Whea"
};

static const PCWSTR
g_KswHalSubcomponentFunctionNames[KSW_PLATFORM_HAL_SUBCOMPONENT_MAX_COUNT] = {
    L"HalpAcpiInitSystem",
    L"HalpDbgInitSystem",
    L"HalpDmaInitSystem",
    L"HalpDpInitSystem",
    L"HalpErrataInitSystem",
    L"HalpExtEnvInitSystem",
    L"HalpFirmwareInitSystem",
    L"HalpHalExtInitSystem",
    L"HalpHvInitSystem",
    L"HalpHwPerfCntInitSystem",
    L"HalpInterruptInitSystem",
    L"HalpIommuInitSystem",
    L"HalpMiscInitSystem",
    L"HalpMmInitSystem",
    L"HalpPciInitSystem",
    L"HalpPnpInitSystem",
    L"HalpPowerInitSystem",
    L"HalpProcInitSystem",
    L"HalpQosInitSystem",
    L"HalpTimerInitSystem",
    L"HalpTopologyInitSystem",
    L"HalpWheaInitSystem"
};

// KMDF 1.15 wdffuncenum.h defines a contiguous, index-stable table of 444 APIs.
// Keep the display names in that exact order so every WdfFunctions slot is named
// without relying on PDBs or runtime signature guesses.
static const PCWSTR g_KswWdfFunctionNames[] = {
    L"WdfChildListCreate",
    L"WdfChildListGetDevice",
    L"WdfChildListRetrievePdo",
    L"WdfChildListRetrieveAddressDescription",
    L"WdfChildListBeginScan",
    L"WdfChildListEndScan",
    L"WdfChildListBeginIteration",
    L"WdfChildListRetrieveNextDevice",
    L"WdfChildListEndIteration",
    L"WdfChildListAddOrUpdateChildDescriptionAsPresent",
    L"WdfChildListUpdateChildDescriptionAsMissing",
    L"WdfChildListUpdateAllChildDescriptionsAsPresent",
    L"WdfChildListRequestChildEject",
    L"WdfCollectionCreate",
    L"WdfCollectionGetCount",
    L"WdfCollectionAdd",
    L"WdfCollectionRemove",
    L"WdfCollectionRemoveItem",
    L"WdfCollectionGetItem",
    L"WdfCollectionGetFirstItem",
    L"WdfCollectionGetLastItem",
    L"WdfCommonBufferCreate",
    L"WdfCommonBufferGetAlignedVirtualAddress",
    L"WdfCommonBufferGetAlignedLogicalAddress",
    L"WdfCommonBufferGetLength",
    L"WdfControlDeviceInitAllocate",
    L"WdfControlDeviceInitSetShutdownNotification",
    L"WdfControlFinishInitializing",
    L"WdfDeviceGetDeviceState",
    L"WdfDeviceSetDeviceState",
    L"WdfWdmDeviceGetWdfDeviceHandle",
    L"WdfDeviceWdmGetDeviceObject",
    L"WdfDeviceWdmGetAttachedDevice",
    L"WdfDeviceWdmGetPhysicalDevice",
    L"WdfDeviceWdmDispatchPreprocessedIrp",
    L"WdfDeviceAddDependentUsageDeviceObject",
    L"WdfDeviceAddRemovalRelationsPhysicalDevice",
    L"WdfDeviceRemoveRemovalRelationsPhysicalDevice",
    L"WdfDeviceClearRemovalRelationsDevices",
    L"WdfDeviceGetDriver",
    L"WdfDeviceRetrieveDeviceName",
    L"WdfDeviceAssignMofResourceName",
    L"WdfDeviceGetIoTarget",
    L"WdfDeviceGetDevicePnpState",
    L"WdfDeviceGetDevicePowerState",
    L"WdfDeviceGetDevicePowerPolicyState",
    L"WdfDeviceAssignS0IdleSettings",
    L"WdfDeviceAssignSxWakeSettings",
    L"WdfDeviceOpenRegistryKey",
    L"WdfDeviceSetSpecialFileSupport",
    L"WdfDeviceSetCharacteristics",
    L"WdfDeviceGetCharacteristics",
    L"WdfDeviceGetAlignmentRequirement",
    L"WdfDeviceSetAlignmentRequirement",
    L"WdfDeviceInitFree",
    L"WdfDeviceInitSetPnpPowerEventCallbacks",
    L"WdfDeviceInitSetPowerPolicyEventCallbacks",
    L"WdfDeviceInitSetPowerPolicyOwnership",
    L"WdfDeviceInitRegisterPnpStateChangeCallback",
    L"WdfDeviceInitRegisterPowerStateChangeCallback",
    L"WdfDeviceInitRegisterPowerPolicyStateChangeCallback",
    L"WdfDeviceInitSetIoType",
    L"WdfDeviceInitSetExclusive",
    L"WdfDeviceInitSetPowerNotPageable",
    L"WdfDeviceInitSetPowerPageable",
    L"WdfDeviceInitSetPowerInrush",
    L"WdfDeviceInitSetDeviceType",
    L"WdfDeviceInitAssignName",
    L"WdfDeviceInitAssignSDDLString",
    L"WdfDeviceInitSetDeviceClass",
    L"WdfDeviceInitSetCharacteristics",
    L"WdfDeviceInitSetFileObjectConfig",
    L"WdfDeviceInitSetRequestAttributes",
    L"WdfDeviceInitAssignWdmIrpPreprocessCallback",
    L"WdfDeviceInitSetIoInCallerContextCallback",
    L"WdfDeviceCreate",
    L"WdfDeviceSetStaticStopRemove",
    L"WdfDeviceCreateDeviceInterface",
    L"WdfDeviceSetDeviceInterfaceState",
    L"WdfDeviceRetrieveDeviceInterfaceString",
    L"WdfDeviceCreateSymbolicLink",
    L"WdfDeviceQueryProperty",
    L"WdfDeviceAllocAndQueryProperty",
    L"WdfDeviceSetPnpCapabilities",
    L"WdfDeviceSetPowerCapabilities",
    L"WdfDeviceSetBusInformationForChildren",
    L"WdfDeviceIndicateWakeStatus",
    L"WdfDeviceSetFailed",
    L"WdfDeviceStopIdleNoTrack",
    L"WdfDeviceResumeIdleNoTrack",
    L"WdfDeviceGetFileObject",
    L"WdfDeviceEnqueueRequest",
    L"WdfDeviceGetDefaultQueue",
    L"WdfDeviceConfigureRequestDispatching",
    L"WdfDmaEnablerCreate",
    L"WdfDmaEnablerGetMaximumLength",
    L"WdfDmaEnablerGetMaximumScatterGatherElements",
    L"WdfDmaEnablerSetMaximumScatterGatherElements",
    L"WdfDmaTransactionCreate",
    L"WdfDmaTransactionInitialize",
    L"WdfDmaTransactionInitializeUsingRequest",
    L"WdfDmaTransactionExecute",
    L"WdfDmaTransactionRelease",
    L"WdfDmaTransactionDmaCompleted",
    L"WdfDmaTransactionDmaCompletedWithLength",
    L"WdfDmaTransactionDmaCompletedFinal",
    L"WdfDmaTransactionGetBytesTransferred",
    L"WdfDmaTransactionSetMaximumLength",
    L"WdfDmaTransactionGetRequest",
    L"WdfDmaTransactionGetCurrentDmaTransferLength",
    L"WdfDmaTransactionGetDevice",
    L"WdfDpcCreate",
    L"WdfDpcEnqueue",
    L"WdfDpcCancel",
    L"WdfDpcGetParentObject",
    L"WdfDpcWdmGetDpc",
    L"WdfDriverCreate",
    L"WdfDriverGetRegistryPath",
    L"WdfDriverWdmGetDriverObject",
    L"WdfDriverOpenParametersRegistryKey",
    L"WdfWdmDriverGetWdfDriverHandle",
    L"WdfDriverRegisterTraceInfo",
    L"WdfDriverRetrieveVersionString",
    L"WdfDriverIsVersionAvailable",
    L"WdfFdoInitWdmGetPhysicalDevice",
    L"WdfFdoInitOpenRegistryKey",
    L"WdfFdoInitQueryProperty",
    L"WdfFdoInitAllocAndQueryProperty",
    L"WdfFdoInitSetEventCallbacks",
    L"WdfFdoInitSetFilter",
    L"WdfFdoInitSetDefaultChildListConfig",
    L"WdfFdoQueryForInterface",
    L"WdfFdoGetDefaultChildList",
    L"WdfFdoAddStaticChild",
    L"WdfFdoLockStaticChildListForIteration",
    L"WdfFdoRetrieveNextStaticChild",
    L"WdfFdoUnlockStaticChildListFromIteration",
    L"WdfFileObjectGetFileName",
    L"WdfFileObjectGetFlags",
    L"WdfFileObjectGetDevice",
    L"WdfFileObjectWdmGetFileObject",
    L"WdfInterruptCreate",
    L"WdfInterruptQueueDpcForIsr",
    L"WdfInterruptSynchronize",
    L"WdfInterruptAcquireLock",
    L"WdfInterruptReleaseLock",
    L"WdfInterruptEnable",
    L"WdfInterruptDisable",
    L"WdfInterruptWdmGetInterrupt",
    L"WdfInterruptGetInfo",
    L"WdfInterruptSetPolicy",
    L"WdfInterruptGetDevice",
    L"WdfIoQueueCreate",
    L"WdfIoQueueGetState",
    L"WdfIoQueueStart",
    L"WdfIoQueueStop",
    L"WdfIoQueueStopSynchronously",
    L"WdfIoQueueGetDevice",
    L"WdfIoQueueRetrieveNextRequest",
    L"WdfIoQueueRetrieveRequestByFileObject",
    L"WdfIoQueueFindRequest",
    L"WdfIoQueueRetrieveFoundRequest",
    L"WdfIoQueueDrainSynchronously",
    L"WdfIoQueueDrain",
    L"WdfIoQueuePurgeSynchronously",
    L"WdfIoQueuePurge",
    L"WdfIoQueueReadyNotify",
    L"WdfIoTargetCreate",
    L"WdfIoTargetOpen",
    L"WdfIoTargetCloseForQueryRemove",
    L"WdfIoTargetClose",
    L"WdfIoTargetStart",
    L"WdfIoTargetStop",
    L"WdfIoTargetGetState",
    L"WdfIoTargetGetDevice",
    L"WdfIoTargetQueryTargetProperty",
    L"WdfIoTargetAllocAndQueryTargetProperty",
    L"WdfIoTargetQueryForInterface",
    L"WdfIoTargetWdmGetTargetDeviceObject",
    L"WdfIoTargetWdmGetTargetPhysicalDevice",
    L"WdfIoTargetWdmGetTargetFileObject",
    L"WdfIoTargetWdmGetTargetFileHandle",
    L"WdfIoTargetSendReadSynchronously",
    L"WdfIoTargetFormatRequestForRead",
    L"WdfIoTargetSendWriteSynchronously",
    L"WdfIoTargetFormatRequestForWrite",
    L"WdfIoTargetSendIoctlSynchronously",
    L"WdfIoTargetFormatRequestForIoctl",
    L"WdfIoTargetSendInternalIoctlSynchronously",
    L"WdfIoTargetFormatRequestForInternalIoctl",
    L"WdfIoTargetSendInternalIoctlOthersSynchronously",
    L"WdfIoTargetFormatRequestForInternalIoctlOthers",
    L"WdfMemoryCreate",
    L"WdfMemoryCreatePreallocated",
    L"WdfMemoryGetBuffer",
    L"WdfMemoryAssignBuffer",
    L"WdfMemoryCopyToBuffer",
    L"WdfMemoryCopyFromBuffer",
    L"WdfLookasideListCreate",
    L"WdfMemoryCreateFromLookaside",
    L"WdfDeviceMiniportCreate",
    L"WdfDriverMiniportUnload",
    L"WdfObjectGetTypedContextWorker",
    L"WdfObjectAllocateContext",
    L"WdfObjectContextGetObject",
    L"WdfObjectReferenceActual",
    L"WdfObjectDereferenceActual",
    L"WdfObjectCreate",
    L"WdfObjectDelete",
    L"WdfObjectQuery",
    L"WdfPdoInitAllocate",
    L"WdfPdoInitSetEventCallbacks",
    L"WdfPdoInitAssignDeviceID",
    L"WdfPdoInitAssignInstanceID",
    L"WdfPdoInitAddHardwareID",
    L"WdfPdoInitAddCompatibleID",
    L"WdfPdoInitAddDeviceText",
    L"WdfPdoInitSetDefaultLocale",
    L"WdfPdoInitAssignRawDevice",
    L"WdfPdoMarkMissing",
    L"WdfPdoRequestEject",
    L"WdfPdoGetParent",
    L"WdfPdoRetrieveIdentificationDescription",
    L"WdfPdoRetrieveAddressDescription",
    L"WdfPdoUpdateAddressDescription",
    L"WdfPdoAddEjectionRelationsPhysicalDevice",
    L"WdfPdoRemoveEjectionRelationsPhysicalDevice",
    L"WdfPdoClearEjectionRelationsDevices",
    L"WdfDeviceAddQueryInterface",
    L"WdfRegistryOpenKey",
    L"WdfRegistryCreateKey",
    L"WdfRegistryClose",
    L"WdfRegistryWdmGetHandle",
    L"WdfRegistryRemoveKey",
    L"WdfRegistryRemoveValue",
    L"WdfRegistryQueryValue",
    L"WdfRegistryQueryMemory",
    L"WdfRegistryQueryMultiString",
    L"WdfRegistryQueryUnicodeString",
    L"WdfRegistryQueryString",
    L"WdfRegistryQueryULong",
    L"WdfRegistryAssignValue",
    L"WdfRegistryAssignMemory",
    L"WdfRegistryAssignMultiString",
    L"WdfRegistryAssignUnicodeString",
    L"WdfRegistryAssignString",
    L"WdfRegistryAssignULong",
    L"WdfRequestCreate",
    L"WdfRequestCreateFromIrp",
    L"WdfRequestReuse",
    L"WdfRequestChangeTarget",
    L"WdfRequestFormatRequestUsingCurrentType",
    L"WdfRequestWdmFormatUsingStackLocation",
    L"WdfRequestSend",
    L"WdfRequestGetStatus",
    L"WdfRequestMarkCancelable",
    L"WdfRequestUnmarkCancelable",
    L"WdfRequestIsCanceled",
    L"WdfRequestCancelSentRequest",
    L"WdfRequestIsFrom32BitProcess",
    L"WdfRequestSetCompletionRoutine",
    L"WdfRequestGetCompletionParams",
    L"WdfRequestAllocateTimer",
    L"WdfRequestComplete",
    L"WdfRequestCompleteWithPriorityBoost",
    L"WdfRequestCompleteWithInformation",
    L"WdfRequestGetParameters",
    L"WdfRequestRetrieveInputMemory",
    L"WdfRequestRetrieveOutputMemory",
    L"WdfRequestRetrieveInputBuffer",
    L"WdfRequestRetrieveOutputBuffer",
    L"WdfRequestRetrieveInputWdmMdl",
    L"WdfRequestRetrieveOutputWdmMdl",
    L"WdfRequestRetrieveUnsafeUserInputBuffer",
    L"WdfRequestRetrieveUnsafeUserOutputBuffer",
    L"WdfRequestSetInformation",
    L"WdfRequestGetInformation",
    L"WdfRequestGetFileObject",
    L"WdfRequestProbeAndLockUserBufferForRead",
    L"WdfRequestProbeAndLockUserBufferForWrite",
    L"WdfRequestGetRequestorMode",
    L"WdfRequestForwardToIoQueue",
    L"WdfRequestGetIoQueue",
    L"WdfRequestRequeue",
    L"WdfRequestStopAcknowledge",
    L"WdfRequestWdmGetIrp",
    L"WdfIoResourceRequirementsListSetSlotNumber",
    L"WdfIoResourceRequirementsListSetInterfaceType",
    L"WdfIoResourceRequirementsListAppendIoResList",
    L"WdfIoResourceRequirementsListInsertIoResList",
    L"WdfIoResourceRequirementsListGetCount",
    L"WdfIoResourceRequirementsListGetIoResList",
    L"WdfIoResourceRequirementsListRemove",
    L"WdfIoResourceRequirementsListRemoveByIoResList",
    L"WdfIoResourceListCreate",
    L"WdfIoResourceListAppendDescriptor",
    L"WdfIoResourceListInsertDescriptor",
    L"WdfIoResourceListUpdateDescriptor",
    L"WdfIoResourceListGetCount",
    L"WdfIoResourceListGetDescriptor",
    L"WdfIoResourceListRemove",
    L"WdfIoResourceListRemoveByDescriptor",
    L"WdfCmResourceListAppendDescriptor",
    L"WdfCmResourceListInsertDescriptor",
    L"WdfCmResourceListGetCount",
    L"WdfCmResourceListGetDescriptor",
    L"WdfCmResourceListRemove",
    L"WdfCmResourceListRemoveByDescriptor",
    L"WdfStringCreate",
    L"WdfStringGetUnicodeString",
    L"WdfObjectAcquireLock",
    L"WdfObjectReleaseLock",
    L"WdfWaitLockCreate",
    L"WdfWaitLockAcquire",
    L"WdfWaitLockRelease",
    L"WdfSpinLockCreate",
    L"WdfSpinLockAcquire",
    L"WdfSpinLockRelease",
    L"WdfTimerCreate",
    L"WdfTimerStart",
    L"WdfTimerStop",
    L"WdfTimerGetParentObject",
    L"WdfUsbTargetDeviceCreate",
    L"WdfUsbTargetDeviceRetrieveInformation",
    L"WdfUsbTargetDeviceGetDeviceDescriptor",
    L"WdfUsbTargetDeviceRetrieveConfigDescriptor",
    L"WdfUsbTargetDeviceQueryString",
    L"WdfUsbTargetDeviceAllocAndQueryString",
    L"WdfUsbTargetDeviceFormatRequestForString",
    L"WdfUsbTargetDeviceGetNumInterfaces",
    L"WdfUsbTargetDeviceSelectConfig",
    L"WdfUsbTargetDeviceWdmGetConfigurationHandle",
    L"WdfUsbTargetDeviceRetrieveCurrentFrameNumber",
    L"WdfUsbTargetDeviceSendControlTransferSynchronously",
    L"WdfUsbTargetDeviceFormatRequestForControlTransfer",
    L"WdfUsbTargetDeviceIsConnectedSynchronous",
    L"WdfUsbTargetDeviceResetPortSynchronously",
    L"WdfUsbTargetDeviceCyclePortSynchronously",
    L"WdfUsbTargetDeviceFormatRequestForCyclePort",
    L"WdfUsbTargetDeviceSendUrbSynchronously",
    L"WdfUsbTargetDeviceFormatRequestForUrb",
    L"WdfUsbTargetPipeGetInformation",
    L"WdfUsbTargetPipeIsInEndpoint",
    L"WdfUsbTargetPipeIsOutEndpoint",
    L"WdfUsbTargetPipeGetType",
    L"WdfUsbTargetPipeSetNoMaximumPacketSizeCheck",
    L"WdfUsbTargetPipeWriteSynchronously",
    L"WdfUsbTargetPipeFormatRequestForWrite",
    L"WdfUsbTargetPipeReadSynchronously",
    L"WdfUsbTargetPipeFormatRequestForRead",
    L"WdfUsbTargetPipeConfigContinuousReader",
    L"WdfUsbTargetPipeAbortSynchronously",
    L"WdfUsbTargetPipeFormatRequestForAbort",
    L"WdfUsbTargetPipeResetSynchronously",
    L"WdfUsbTargetPipeFormatRequestForReset",
    L"WdfUsbTargetPipeSendUrbSynchronously",
    L"WdfUsbTargetPipeFormatRequestForUrb",
    L"WdfUsbInterfaceGetInterfaceNumber",
    L"WdfUsbInterfaceGetNumEndpoints",
    L"WdfUsbInterfaceGetDescriptor",
    L"WdfUsbInterfaceSelectSetting",
    L"WdfUsbInterfaceGetEndpointInformation",
    L"WdfUsbTargetDeviceGetInterface",
    L"WdfUsbInterfaceGetConfiguredSettingIndex",
    L"WdfUsbInterfaceGetNumConfiguredPipes",
    L"WdfUsbInterfaceGetConfiguredPipe",
    L"WdfUsbTargetPipeWdmGetPipeHandle",
    L"WdfVerifierDbgBreakPoint",
    L"WdfVerifierKeBugCheck",
    L"WdfWmiProviderCreate",
    L"WdfWmiProviderGetDevice",
    L"WdfWmiProviderIsEnabled",
    L"WdfWmiProviderGetTracingHandle",
    L"WdfWmiInstanceCreate",
    L"WdfWmiInstanceRegister",
    L"WdfWmiInstanceDeregister",
    L"WdfWmiInstanceGetDevice",
    L"WdfWmiInstanceGetProvider",
    L"WdfWmiInstanceFireEvent",
    L"WdfWorkItemCreate",
    L"WdfWorkItemEnqueue",
    L"WdfWorkItemGetParentObject",
    L"WdfWorkItemFlush",
    L"WdfCommonBufferCreateWithConfig",
    L"WdfDmaEnablerGetFragmentLength",
    L"WdfDmaEnablerWdmGetDmaAdapter",
    L"WdfUsbInterfaceGetNumSettings",
    L"WdfDeviceRemoveDependentUsageDeviceObject",
    L"WdfDeviceGetSystemPowerAction",
    L"WdfInterruptSetExtendedPolicy",
    L"WdfIoQueueAssignForwardProgressPolicy",
    L"WdfPdoInitAssignContainerID",
    L"WdfPdoInitAllowForwardingRequestToParent",
    L"WdfRequestMarkCancelableEx",
    L"WdfRequestIsReserved",
    L"WdfRequestForwardToParentDeviceIoQueue",
    L"WdfCxDeviceInitAllocate",
    L"WdfCxDeviceInitAssignWdmIrpPreprocessCallback",
    L"WdfCxDeviceInitSetIoInCallerContextCallback",
    L"WdfCxDeviceInitSetRequestAttributes",
    L"WdfCxDeviceInitSetFileObjectConfig",
    L"WdfDeviceWdmDispatchIrp",
    L"WdfDeviceWdmDispatchIrpToIoQueue",
    L"WdfDeviceInitSetRemoveLockOptions",
    L"WdfDeviceConfigureWdmIrpDispatchCallback",
    L"WdfDmaEnablerConfigureSystemProfile",
    L"WdfDmaTransactionInitializeUsingOffset",
    L"WdfDmaTransactionGetTransferInfo",
    L"WdfDmaTransactionSetChannelConfigurationCallback",
    L"WdfDmaTransactionSetTransferCompleteCallback",
    L"WdfDmaTransactionSetImmediateExecution",
    L"WdfDmaTransactionAllocateResources",
    L"WdfDmaTransactionSetDeviceAddressOffset",
    L"WdfDmaTransactionFreeResources",
    L"WdfDmaTransactionCancel",
    L"WdfDmaTransactionWdmGetTransferContext",
    L"WdfInterruptQueueWorkItemForIsr",
    L"WdfInterruptTryToAcquireLock",
    L"WdfIoQueueStopAndPurge",
    L"WdfIoQueueStopAndPurgeSynchronously",
    L"WdfIoTargetPurge",
    L"WdfUsbTargetDeviceCreateWithParameters",
    L"WdfUsbTargetDeviceQueryUsbCapability",
    L"WdfUsbTargetDeviceCreateUrb",
    L"WdfUsbTargetDeviceCreateIsochUrb",
    L"WdfDeviceWdmAssignPowerFrameworkSettings",
    L"WdfDmaTransactionStopSystemTransfer",
    L"WdfCxVerifierKeBugCheck",
    L"WdfInterruptReportActive",
    L"WdfInterruptReportInactive",
    L"WdfDeviceInitSetReleaseHardwareOrderOnFailure",
    L"WdfGetTriageInfo",
    L"WdfDeviceInitSetIoTypeEx",
    L"WdfDeviceQueryPropertyEx",
    L"WdfDeviceAllocAndQueryPropertyEx",
    L"WdfDeviceAssignProperty",
    L"WdfFdoInitQueryPropertyEx",
    L"WdfFdoInitAllocAndQueryPropertyEx",
    L"WdfDeviceStopIdleActual",
    L"WdfDeviceResumeIdleActual",
    L"WdfDeviceGetSelfIoTarget",
    L"WdfDeviceInitAllowSelfIoTarget",
    L"WdfIoTargetSelfAssignDefaultIoQueue",
    L"WdfDeviceOpenDevicemapKey"
};
C_ASSERT(RTL_NUMBER_OF(g_KswWdfFunctionNames) == WdfFunctionTableNumEntries);

static const KSW_PLATFORM_CALLBACK_DESCRIPTOR g_KswWdfCallbacks[] = {
    { (PVOID)KswordARKDriverEvtDriverUnload, L"KswordARKDriverEvtDriverUnload" },
    { (PVOID)KswordARKDriverEvtDriverContextCleanup, L"KswordARKDriverEvtDriverContextCleanup" },
    { (PVOID)KswordARKDriverEvtIoDeviceControl, L"KswordARKDriverEvtIoDeviceControl" },
    { (PVOID)KswordARKDriverEvtIoRead, L"KswordARKDriverEvtIoRead" },
    { (PVOID)KswordARKDriverEvtIoStop, L"KswordARKDriverEvtIoStop" },
    { (PVOID)KswordARKDriverEvtDevicePrepareHardware, L"KswordARKDriverEvtDevicePrepareHardware" }
};

static VOID
KswPlatformCopyWide(
    _Out_writes_(DestinationChars) PWCHAR Destination,
    _In_ ULONG DestinationChars,
    _In_opt_z_ PCWSTR Source
    )
{
    if (Destination == NULL || DestinationChars == 0UL) {
        return;
    }
    Destination[0] = L'\0';
    if (Source != NULL) {
        (VOID)RtlStringCchCopyNW(Destination, DestinationChars, Source, DestinationChars - 1UL);
    }
}

static PVOID
KswPlatformGetRoutine(
    _In_z_ PCWSTR RoutineName
    )
{
    UNICODE_STRING routineNameString;

    if (RoutineName == NULL) {
        return NULL;
    }
    RtlInitUnicodeString(&routineNameString, RoutineName);
    return MmGetSystemRoutineAddress(&routineNameString);
}

static BOOLEAN
KswPlatformModuleNameEquals(
    _In_opt_ const KSW_HOOK_SYSTEM_MODULE_ENTRY* Module,
    _In_z_ PCSTR ExpectedName
    )
{
    const UCHAR* fileName = NULL;
    ULONG fileNameBytes = 0UL;

    if (Module == NULL || ExpectedName == NULL) {
        return FALSE;
    }
    KswordARKHookGetModuleFileName(Module, &fileName, &fileNameBytes);
    return KswordARKHookBoundedAnsiEqualsInsensitive(fileName, fileNameBytes, ExpectedName);
}

static BOOLEAN
KswPlatformIsExpectedHalOwner(
    _In_opt_ const KSW_HOOK_SYSTEM_MODULE_ENTRY* Module
    )
{
    return KswPlatformModuleNameEquals(Module, "ntoskrnl.exe") ||
        KswPlatformModuleNameEquals(Module, "ntkrnlmp.exe") ||
        KswPlatformModuleNameEquals(Module, "ntkrnlpa.exe") ||
        KswPlatformModuleNameEquals(Module, "ntkrpamp.exe") ||
        KswPlatformModuleNameEquals(Module, "hal.dll");
}

static BOOLEAN
KswPlatformOwnerMatchesPolicy(
    _In_opt_ const KSW_HOOK_SYSTEM_MODULE_ENTRY* Module,
    _In_ ULONG OwnerPolicy
    )
{
    switch (OwnerPolicy) {
    case KSWORD_ARK_PLATFORM_OWNER_NT_HAL:
        return KswPlatformIsExpectedHalOwner(Module);
    case KSWORD_ARK_PLATFORM_OWNER_NT_HAL_PCI:
        return KswPlatformIsExpectedHalOwner(Module) ||
            KswPlatformModuleNameEquals(Module, "pci.sys");
    case KSWORD_ARK_PLATFORM_OWNER_NT_HAL_ACPI:
        return KswPlatformIsExpectedHalOwner(Module) ||
            KswPlatformModuleNameEquals(Module, "ACPI.sys");
    case KSWORD_ARK_PLATFORM_OWNER_WDF:
        return KswPlatformModuleNameEquals(Module, "Wdf01000.sys");
    case KSWORD_ARK_PLATFORM_OWNER_KSWORD:
        return KswPlatformModuleNameEquals(Module, "KswordARK.sys");
    default:
        return FALSE;
    }
}

static VOID
KswPlatformFillModule(
    _Inout_ KSWORD_ARK_PLATFORM_AUDIT_ENTRY* Entry,
    _In_opt_ const KSW_HOOK_SYSTEM_MODULE_ENTRY* Module
    )
{
    if (Entry == NULL || Module == NULL) {
        return;
    }

    Entry->moduleBase = (ULONGLONG)(ULONG_PTR)Module->ImageBase;
    Entry->moduleSize = Module->ImageSize;
    Entry->fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_MODULE;
    KswordARKHookCopyBoundedAnsiToWide(
        Module->FullPathName,
        RTL_NUMBER_OF(Module->FullPathName),
        Entry->modulePath,
        RTL_NUMBER_OF(Entry->modulePath));
}

static BOOLEAN
KswPlatformAddressSectionMatches(
    _In_ const KSW_HOOK_SYSTEM_MODULE_ENTRY* Module,
    _In_ ULONG_PTR Address,
    _In_ BOOLEAN RequireExecutable
    )
{
    IMAGE_DOS_HEADER dosHeader;
    IMAGE_NT_HEADERS ntHeaders;
    ULONG sectionIndex = 0UL;
    ULONG sectionTableRva = 0UL;

    if (Module == NULL ||
        Address < (ULONG_PTR)Module->ImageBase ||
        Address >= ((ULONG_PTR)Module->ImageBase + Module->ImageSize)) {
        return FALSE;
    }
    if (!KswordARKHookReadMemorySafe(Module->ImageBase, &dosHeader, sizeof(dosHeader)) ||
        dosHeader.e_magic != IMAGE_DOS_SIGNATURE ||
        dosHeader.e_lfanew <= 0 ||
        !KswordARKHookValidateRvaRange((ULONG)dosHeader.e_lfanew, sizeof(ntHeaders), Module->ImageSize) ||
        !KswordARKHookReadMemorySafe(
            (const UCHAR*)Module->ImageBase + (ULONG)dosHeader.e_lfanew,
            &ntHeaders,
            sizeof(ntHeaders)) ||
        ntHeaders.Signature != IMAGE_NT_SIGNATURE ||
        ntHeaders.FileHeader.NumberOfSections == 0U ||
        ntHeaders.FileHeader.NumberOfSections > 96U) {
        return FALSE;
    }

    sectionTableRva = (ULONG)dosHeader.e_lfanew +
        FIELD_OFFSET(IMAGE_NT_HEADERS, OptionalHeader) +
        ntHeaders.FileHeader.SizeOfOptionalHeader;
    for (sectionIndex = 0UL; sectionIndex < ntHeaders.FileHeader.NumberOfSections; ++sectionIndex) {
        IMAGE_SECTION_HEADER sectionHeader;
        ULONG currentRva = sectionTableRva + (sectionIndex * sizeof(IMAGE_SECTION_HEADER));
        ULONG span = 0UL;
        ULONG_PTR startAddress = 0U;
        ULONG_PTR endAddress = 0U;
        BOOLEAN executable = FALSE;

        if (!KswordARKHookValidateRvaRange(currentRva, sizeof(sectionHeader), Module->ImageSize) ||
            !KswordARKHookReadMemorySafe(
                (const UCHAR*)Module->ImageBase + currentRva,
                &sectionHeader,
                sizeof(sectionHeader))) {
            return FALSE;
        }

        span = sectionHeader.Misc.VirtualSize;
        if (span < sectionHeader.SizeOfRawData) {
            span = sectionHeader.SizeOfRawData;
        }
        if (span == 0UL ||
            !KswordARKHookValidateRvaRange(sectionHeader.VirtualAddress, span, Module->ImageSize)) {
            continue;
        }

        startAddress = (ULONG_PTR)Module->ImageBase + sectionHeader.VirtualAddress;
        endAddress = startAddress + span;
        executable = (sectionHeader.Characteristics & IMAGE_SCN_MEM_EXECUTE) != 0UL;
        if (Address >= startAddress &&
            Address < endAddress &&
            executable == RequireExecutable) {
            return TRUE;
        }
    }
    return FALSE;
}

static BOOLEAN
KswPlatformRangeInSection(
    _In_ const KSW_HOOK_SYSTEM_MODULE_ENTRY* Module,
    _In_ ULONG_PTR Address,
    _In_ SIZE_T ByteCount,
    _In_ BOOLEAN RequireExecutable,
    _In_ BOOLEAN RequireReadOnly
    )
{
    IMAGE_DOS_HEADER dosHeader;
    IMAGE_NT_HEADERS ntHeaders;
    ULONG sectionIndex = 0UL;
    ULONG sectionTableRva = 0UL;
    ULONG_PTR rangeEnd = 0U;

    if (Module == NULL || ByteCount == 0U ||
        Address < (ULONG_PTR)Module->ImageBase ||
        Address > MAXULONG_PTR - ByteCount) {
        return FALSE;
    }
    rangeEnd = Address + ByteCount;
    if (rangeEnd > (ULONG_PTR)Module->ImageBase + Module->ImageSize) {
        return FALSE;
    }
    if (!KswordARKHookReadMemorySafe(Module->ImageBase, &dosHeader, sizeof(dosHeader)) ||
        dosHeader.e_magic != IMAGE_DOS_SIGNATURE ||
        dosHeader.e_lfanew <= 0 ||
        !KswordARKHookValidateRvaRange((ULONG)dosHeader.e_lfanew, sizeof(ntHeaders), Module->ImageSize) ||
        !KswordARKHookReadMemorySafe(
            (const UCHAR*)Module->ImageBase + (ULONG)dosHeader.e_lfanew,
            &ntHeaders,
            sizeof(ntHeaders)) ||
        ntHeaders.Signature != IMAGE_NT_SIGNATURE ||
        ntHeaders.FileHeader.NumberOfSections == 0U ||
        ntHeaders.FileHeader.NumberOfSections > 96U) {
        return FALSE;
    }

    sectionTableRva = (ULONG)dosHeader.e_lfanew +
        FIELD_OFFSET(IMAGE_NT_HEADERS, OptionalHeader) +
        ntHeaders.FileHeader.SizeOfOptionalHeader;
    for (sectionIndex = 0UL; sectionIndex < ntHeaders.FileHeader.NumberOfSections; ++sectionIndex) {
        IMAGE_SECTION_HEADER sectionHeader;
        ULONG currentRva = sectionTableRva + (sectionIndex * sizeof(IMAGE_SECTION_HEADER));
        ULONG span = 0UL;
        ULONG_PTR sectionStart = 0U;
        ULONG_PTR sectionEnd = 0U;
        BOOLEAN executable = FALSE;
        BOOLEAN writable = FALSE;

        if (!KswordARKHookValidateRvaRange(currentRva, sizeof(sectionHeader), Module->ImageSize) ||
            !KswordARKHookReadMemorySafe(
                (const UCHAR*)Module->ImageBase + currentRva,
                &sectionHeader,
                sizeof(sectionHeader))) {
            return FALSE;
        }
        span = sectionHeader.Misc.VirtualSize;
        if (span < sectionHeader.SizeOfRawData) {
            span = sectionHeader.SizeOfRawData;
        }
        if (span == 0UL ||
            !KswordARKHookValidateRvaRange(sectionHeader.VirtualAddress, span, Module->ImageSize)) {
            continue;
        }
        sectionStart = (ULONG_PTR)Module->ImageBase + sectionHeader.VirtualAddress;
        sectionEnd = sectionStart + span;
        executable = (sectionHeader.Characteristics & IMAGE_SCN_MEM_EXECUTE) != 0UL;
        writable = (sectionHeader.Characteristics & IMAGE_SCN_MEM_WRITE) != 0UL;
        if (Address >= sectionStart && rangeEnd <= sectionEnd &&
            executable == RequireExecutable &&
            (!RequireReadOnly || !writable)) {
            return TRUE;
        }
    }
    return FALSE;
}

static BOOLEAN
KswPlatformRangeInWritableDataSection(
    _In_ const KSW_HOOK_SYSTEM_MODULE_ENTRY* Module,
    _In_ ULONG_PTR Address,
    _In_ SIZE_T ByteCount
    )
/*++

Routine Description:

    判定范围所在的非执行节是否带 IMAGE_SCN_MEM_WRITE。用两次现有查询表达，
    避免为一个编辑期判据改动被十余处只读路径依赖的节校验函数：第一次确认范围
    确实落在某个非执行节内，第二次确认它不是"非执行且不可写"的节。

Return Value:

    TRUE 表示槽位落在可写数据节，直接 CAS 即可；FALSE 时调用方必须先建立 MDL
    可写别名，否则写只读映像页会直接 bug check 0xBE。

--*/
{
    return (BOOLEAN)(
        KswPlatformRangeInSection(Module, Address, ByteCount, FALSE, FALSE) &&
        !KswPlatformRangeInSection(Module, Address, ByteCount, FALSE, TRUE));
}

static BOOLEAN
KswPlatformAddSignedDisplacement(
    _In_ ULONG64 Base,
    _In_ LONGLONG Displacement,
    _Out_ ULONG64* ResultOut
    );

static BOOLEAN
KswPlatformDecodeDetourTarget(
    _In_ ULONG64 Address,
    _Out_ ULONG64* TargetOut
    )
{
    UCHAR codeBytes[16];
    ULONG offset = 0UL;

    if (TargetOut == NULL || Address == 0ULL) {
        return FALSE;
    }
    *TargetOut = 0ULL;
    RtlZeroMemory(codeBytes, sizeof(codeBytes));
    if (!KswordARKHookReadMemorySafe((const VOID*)(ULONG_PTR)Address, codeBytes, sizeof(codeBytes))) {
        return FALSE;
    }

    if (codeBytes[0] == 0xF3U && codeBytes[1] == 0x0FU &&
        codeBytes[2] == 0x1EU && codeBytes[3] == 0xFAU) {
        offset = 4UL;
    }

    if (codeBytes[offset] == 0xE9U) {
        LONG displacement = 0;
        ULONG64 instructionEnd = 0ULL;
        RtlCopyMemory(&displacement, &codeBytes[offset + 1UL], sizeof(displacement));
        if (Address > MAXULONGLONG - offset - 5ULL) {
            return FALSE;
        }
        instructionEnd = Address + offset + 5ULL;
        return KswPlatformAddSignedDisplacement(
            instructionEnd,
            (LONGLONG)displacement,
            TargetOut);
    }
    if (codeBytes[offset] == 0xEBU) {
        CHAR displacement8 = (CHAR)codeBytes[offset + 1UL];
        ULONG64 instructionEnd = 0ULL;
        if (Address > MAXULONGLONG - offset - 2ULL) {
            return FALSE;
        }
        instructionEnd = Address + offset + 2ULL;
        return KswPlatformAddSignedDisplacement(
            instructionEnd,
            (LONGLONG)displacement8,
            TargetOut);
    }
    if (codeBytes[offset] == 0xFFU && codeBytes[offset + 1UL] == 0x25U) {
        LONG displacement = 0;
        ULONG64 pointerAddress = 0ULL;
        ULONG64 instructionEnd = 0ULL;
        RtlCopyMemory(&displacement, &codeBytes[offset + 2UL], sizeof(displacement));
        if (Address > MAXULONGLONG - offset - 6ULL) {
            return FALSE;
        }
        instructionEnd = Address + offset + 6ULL;
        if (!KswPlatformAddSignedDisplacement(
                instructionEnd,
                (LONGLONG)displacement,
                &pointerAddress)) {
            return FALSE;
        }
        return KswordARKHookReadMemorySafe(
            (const VOID*)(ULONG_PTR)pointerAddress,
            TargetOut,
            sizeof(*TargetOut));
    }
    if (codeBytes[offset] == 0x48U && codeBytes[offset + 1UL] == 0xB8U &&
        codeBytes[offset + 10UL] == 0xFFU && codeBytes[offset + 11UL] == 0xE0U) {
        RtlCopyMemory(TargetOut, &codeBytes[offset + 2UL], sizeof(*TargetOut));
        return TRUE;
    }
    return FALSE;
}

static BOOLEAN
KswPlatformAddSignedDisplacement(
    _In_ ULONG64 Base,
    _In_ LONGLONG Displacement,
    _Out_ ULONG64* ResultOut
    )
{
    ULONG64 magnitude = 0ULL;

    if (ResultOut == NULL) {
        return FALSE;
    }
    *ResultOut = 0ULL;
    if (Displacement >= 0) {
        magnitude = (ULONG64)Displacement;
        if (Base > MAXULONGLONG - magnitude) {
            return FALSE;
        }
        *ResultOut = Base + magnitude;
        return TRUE;
    }

    // 中文说明：避免直接对最小 LONGLONG 取负导致有符号溢出。
    magnitude = (ULONG64)(-(Displacement + 1LL)) + 1ULL;
    if (Base < magnitude) {
        return FALSE;
    }
    *ResultOut = Base - magnitude;
    return TRUE;
}

typedef struct _KSW_PLATFORM_MASKED_SIGNATURE
{
    UCHAR Bytes[12];
    UCHAR Mask[12];
    ULONG Length;
    ULONG Identifier;
} KSW_PLATFORM_MASKED_SIGNATURE;

static const KSW_PLATFORM_MASKED_SIGNATURE g_KswX64PrologueSignatures[] = {
    { { 0x48, 0x89, 0x5C, 0x24, 0x00, 0x57, 0x48, 0x83, 0xEC, 0x00 },
      { 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0x00 },
      10UL, 1UL },
    { { 0x40, 0x53, 0x48, 0x83, 0xEC, 0x00 },
      { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00 },
      6UL, 2UL },
    { { 0x48, 0x83, 0xEC, 0x00 },
      { 0xFF, 0xFF, 0xFF, 0x00 },
      4UL, 3UL },
    { { 0x4C, 0x8B, 0xDC, 0x49, 0x89, 0x5B, 0x00 },
      { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00 },
      7UL, 4UL },
    { { 0x48, 0x8B, 0xC4, 0x48, 0x89, 0x58, 0x00 },
      { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00 },
      7UL, 5UL },
    { { 0x48, 0x89, 0x5C, 0x24, 0x00, 0x48, 0x89, 0x6C, 0x24, 0x00 },
      { 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0x00 },
      10UL, 6UL },
    { { 0x48, 0x8B, 0xC4, 0x55, 0x53, 0x56, 0x57 },
      { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF },
      7UL, 7UL },
    { { 0x40, 0x55, 0x53, 0x56, 0x57, 0x41, 0x54 },
      { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF },
      7UL, 8UL }
};

static BOOLEAN
KswPlatformMaskedBytesMatch(
    _In_reads_(ByteCount) const UCHAR* Data,
    _In_reads_(ByteCount) const UCHAR* Bytes,
    _In_reads_(ByteCount) const UCHAR* Mask,
    _In_ ULONG ByteCount
    )
{
    ULONG index = 0UL;

    if (Data == NULL || Bytes == NULL || Mask == NULL || ByteCount == 0UL) {
        return FALSE;
    }
    for (index = 0UL; index < ByteCount; ++index) {
        if ((Data[index] & Mask[index]) != (Bytes[index] & Mask[index])) {
            return FALSE;
        }
    }
    return TRUE;
}

static BOOLEAN
KswPlatformIdentifyX64Prologue(
    _In_ ULONG64 Address,
    _Out_ ULONG* SignatureIdOut
    )
{
    UCHAR bytes[20];
    ULONG codeOffset = 0UL;
    ULONG index = 0UL;
    ULONG matchedCount = 0UL;
    ULONG matchedId = 0UL;

    if (SignatureIdOut == NULL) {
        return FALSE;
    }
    *SignatureIdOut = 0UL;
    RtlZeroMemory(bytes, sizeof(bytes));
    if (Address == 0ULL ||
        !KswordARKHookReadMemorySafe((const VOID*)(ULONG_PTR)Address, bytes, sizeof(bytes))) {
        return FALSE;
    }
    if (bytes[0] == 0xF3U && bytes[1] == 0x0FU &&
        bytes[2] == 0x1EU && bytes[3] == 0xFAU) {
        codeOffset = 4UL;
    }

    // 中文说明：每个模式都是真实字节 + mask，且只检查函数头固定 20 字节。
    // 只有恰好一个模式命中才接受；多命中与零命中都按未知版本失败关闭。
    for (index = 0UL; index < RTL_NUMBER_OF(g_KswX64PrologueSignatures); ++index) {
        const KSW_PLATFORM_MASKED_SIGNATURE* signature =
            &g_KswX64PrologueSignatures[index];
        if (codeOffset + signature->Length > sizeof(bytes)) {
            continue;
        }
        if (KswPlatformMaskedBytesMatch(
                bytes + codeOffset,
                signature->Bytes,
                signature->Mask,
                signature->Length)) {
            matchedCount += 1UL;
            matchedId = signature->Identifier;
        }
    }
    if (matchedCount != 1UL) {
        return FALSE;
    }
    *SignatureIdOut = matchedId;
    return TRUE;
}

static VOID
KswPlatformSetDetail(
    _Inout_ KSWORD_ARK_PLATFORM_AUDIT_ENTRY* Entry,
    _In_ ULONG DetailCode,
    _In_ ULONGLONG Arg0,
    _In_ ULONGLONG Arg1,
    _In_ ULONGLONG Arg2,
    _In_ ULONGLONG Arg3
    )
{
    if (Entry == NULL) {
        return;
    }
    Entry->detailCode = DetailCode;
    Entry->detailArgs[0] = Arg0;
    Entry->detailArgs[1] = Arg1;
    Entry->detailArgs[2] = Arg2;
    Entry->detailArgs[3] = Arg3;
    if (DetailCode != KSWORD_ARK_PLATFORM_DETAIL_NONE) {
        Entry->fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_DETAIL_ARGS;
    }
}

static VOID
KswPlatformClassifyFunction(
    _Inout_ KSWORD_ARK_PLATFORM_AUDIT_ENTRY* Entry,
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ ULONG OwnerPolicy
    )
{
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* owner = NULL;
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* detourOwner = NULL;
    ULONG64 detourTarget = 0ULL;
    BOOLEAN ownerExpected = FALSE;
    BOOLEAN executable = FALSE;
    ULONG prologueSignatureId = 0UL;

    if (Entry == NULL || Entry->liveAddress == 0ULL) {
        return;
    }

    owner = KswordARKHookFindModuleForAddress(ModuleInfo, (ULONG_PTR)Entry->liveAddress);
    KswPlatformFillModule(Entry, owner);
    executable = owner != NULL &&
        KswPlatformAddressSectionMatches(owner, (ULONG_PTR)Entry->liveAddress, TRUE);
    Entry->ownerPolicy = OwnerPolicy;
    ownerExpected = KswPlatformOwnerMatchesPolicy(owner, OwnerPolicy);

    if (ownerExpected) {
        Entry->fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_OWNER_VALIDATED;
    }
    if (!ownerExpected) {
        Entry->hookStatus = KSWORD_ARK_PLATFORM_HOOK_SUSPICIOUS;
        Entry->confidence = KSWORD_ARK_PLATFORM_CONFIDENCE_HIGH;
        Entry->status = KSWORD_ARK_PLATFORM_AUDIT_STATUS_SIGNATURE_MISMATCH;
        Entry->lastStatus = STATUS_OBJECT_TYPE_MISMATCH;
        KswPlatformSetDetail(
            Entry,
            KSWORD_ARK_PLATFORM_DETAIL_OWNER_MISMATCH,
            Entry->liveAddress,
            Entry->moduleBase,
            OwnerPolicy,
            0ULL);
        return;
    }
    if (!executable) {
        Entry->hookStatus = KSWORD_ARK_PLATFORM_HOOK_SUSPICIOUS;
        Entry->confidence = KSWORD_ARK_PLATFORM_CONFIDENCE_HIGH;
        Entry->status = KSWORD_ARK_PLATFORM_AUDIT_STATUS_SIGNATURE_MISMATCH;
        Entry->lastStatus = STATUS_INVALID_ADDRESS;
        KswPlatformSetDetail(
            Entry,
            KSWORD_ARK_PLATFORM_DETAIL_NON_EXECUTABLE,
            Entry->liveAddress,
            Entry->moduleBase,
            OwnerPolicy,
            0ULL);
        return;
    }
    Entry->fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_EXECUTABLE_VALIDATED;

    if (KswPlatformDecodeDetourTarget(Entry->liveAddress, &detourTarget)) {
        detourOwner = KswordARKHookFindModuleForAddress(ModuleInfo, (ULONG_PTR)detourTarget);
        if (!KswPlatformOwnerMatchesPolicy(detourOwner, OwnerPolicy)) {
            Entry->hookStatus = KSWORD_ARK_PLATFORM_HOOK_SUSPICIOUS;
            Entry->confidence = KSWORD_ARK_PLATFORM_CONFIDENCE_HIGH;
            Entry->status = KSWORD_ARK_PLATFORM_AUDIT_STATUS_SIGNATURE_MISMATCH;
            Entry->lastStatus = STATUS_OBJECT_TYPE_MISMATCH;
            KswPlatformSetDetail(
                Entry,
                KSWORD_ARK_PLATFORM_DETAIL_DETOUR_EXTERNAL,
                Entry->liveAddress,
                detourTarget,
                OwnerPolicy,
                0ULL);
        }
        else {
            Entry->hookStatus = KSWORD_ARK_PLATFORM_HOOK_UNKNOWN;
            Entry->confidence = KSWORD_ARK_PLATFORM_CONFIDENCE_MEDIUM;
            KswPlatformSetDetail(
                Entry,
                KSWORD_ARK_PLATFORM_DETAIL_DETOUR_SAME_OWNER,
                Entry->liveAddress,
                detourTarget,
                OwnerPolicy,
                0ULL);
        }
        return;
    }

    if (KswPlatformIdentifyX64Prologue(Entry->liveAddress, &prologueSignatureId)) {
        Entry->fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_PROLOGUE_FORMAT;
        Entry->prologueSignatureId = prologueSignatureId;
        Entry->hookStatus = KSWORD_ARK_PLATFORM_HOOK_UNKNOWN;
        Entry->confidence = KSWORD_ARK_PLATFORM_CONFIDENCE_MEDIUM;
        KswPlatformSetDetail(
            Entry,
            KSWORD_ARK_PLATFORM_DETAIL_FORMAT_RECOGNIZED,
            prologueSignatureId,
            OwnerPolicy,
            0ULL,
            0ULL);
    }
    else {
        Entry->hookStatus = KSWORD_ARK_PLATFORM_HOOK_UNKNOWN;
        Entry->confidence = KSWORD_ARK_PLATFORM_CONFIDENCE_LOW;
        KswPlatformSetDetail(
            Entry,
            KSWORD_ARK_PLATFORM_DETAIL_FORMAT_UNKNOWN,
            OwnerPolicy,
            0ULL,
            0ULL,
            0ULL);
    }
}

static ULONG
KswPlatformOutputCapacity(
    _In_ size_t OutputBytes
    )
{
    size_t payloadBytes = 0U;
    size_t capacity = 0U;

    if (OutputBytes <= KSW_PLATFORM_RESPONSE_HEADER_SIZE) {
        return 0UL;
    }
    payloadBytes = OutputBytes - KSW_PLATFORM_RESPONSE_HEADER_SIZE;
    capacity = payloadBytes / sizeof(KSWORD_ARK_PLATFORM_AUDIT_ENTRY);
    if (capacity > MAXULONG) {
        return MAXULONG;
    }
    return (ULONG)capacity;
}

static VOID
KswPlatformAppend(
    _Inout_ KSWORD_ARK_QUERY_PLATFORM_AUDIT_RESPONSE* Response,
    _In_ ULONG Capacity,
    _In_ ULONG MaxRows,
    _In_ const KSWORD_ARK_PLATFORM_AUDIT_ENTRY* Entry
    )
{
    if (Response == NULL || Entry == NULL) {
        return;
    }
    Response->totalCount += 1UL;
    if (Response->returnedCount >= Capacity || Response->returnedCount >= MaxRows) {
        Response->responseFlags |= KSWORD_ARK_PLATFORM_RESPONSE_TRUNCATED |
            KSWORD_ARK_PLATFORM_RESPONSE_PARTIAL;
        Response->queryStatus = KSWORD_ARK_PLATFORM_AUDIT_STATUS_PARTIAL;
        Response->lastStatus = STATUS_BUFFER_OVERFLOW;
        return;
    }
    Response->entries[Response->returnedCount] = *Entry;
    Response->returnedCount += 1UL;
    if (Entry->status != KSWORD_ARK_PLATFORM_AUDIT_STATUS_OK) {
        Response->responseFlags |= KSWORD_ARK_PLATFORM_RESPONSE_PARTIAL;
        if (Response->queryStatus == KSWORD_ARK_PLATFORM_AUDIT_STATUS_OK) {
            Response->queryStatus = KSWORD_ARK_PLATFORM_AUDIT_STATUS_PARTIAL;
        }
    }
}

static VOID
KswPlatformAddDiagnostic(
    _Inout_ KSWORD_ARK_QUERY_PLATFORM_AUDIT_RESPONSE* Response,
    _In_ ULONG Capacity,
    _In_ ULONG MaxRows,
    _In_ ULONG Scope,
    _In_ ULONG Status,
    _In_ NTSTATUS LastStatus,
    _In_z_ PCWSTR Name,
    _In_ ULONG DetailCode,
    _In_ ULONGLONG DetailArg0,
    _In_ ULONGLONG DetailArg1
    )
{
    KSWORD_ARK_PLATFORM_AUDIT_ENTRY entry;

    RtlZeroMemory(&entry, sizeof(entry));
    entry.size = sizeof(entry);
    entry.scope = Scope;
    entry.rowKind = KSWORD_ARK_PLATFORM_AUDIT_ROW_DIAGNOSTIC;
    entry.status = Status;
    entry.hookStatus = KSWORD_ARK_PLATFORM_HOOK_UNSUPPORTED;
    entry.confidence = KSWORD_ARK_PLATFORM_CONFIDENCE_NONE;
    entry.signatureId = KSWORD_ARK_PLATFORM_SIGNATURE_EXACT_EXPORT_ONLY;
    entry.lastStatus = LastStatus;
    KswPlatformCopyWide(entry.name, RTL_NUMBER_OF(entry.name), Name);
    KswPlatformSetDetail(&entry, DetailCode, DetailArg0, DetailArg1, 0ULL, 0ULL);
    KswPlatformAppend(Response, Capacity, MaxRows, &entry);
    Response->responseFlags |= KSWORD_ARK_PLATFORM_RESPONSE_PARTIAL |
        KSWORD_ARK_PLATFORM_RESPONSE_FAIL_CLOSED;
    if (Response->queryStatus == KSWORD_ARK_PLATFORM_AUDIT_STATUS_OK) {
        Response->queryStatus = KSWORD_ARK_PLATFORM_AUDIT_STATUS_PARTIAL;
    }
    Response->lastStatus = LastStatus;
}





static VOID
KswPlatformInitializeEntry(
    _Out_ KSWORD_ARK_PLATFORM_AUDIT_ENTRY* Entry,
    _In_ ULONG Scope,
    _In_ ULONG RowKind,
    _In_ ULONG SignatureId,
    _In_ ULONG SlotKind,
    _In_ ULONG OwnerPolicy,
    _In_ ULONG EntryIndex,
    _In_opt_ PVOID TableAddress,
    _In_z_ PCWSTR Name
    )
{
    RtlZeroMemory(Entry, sizeof(*Entry));
    Entry->size = sizeof(*Entry);
    Entry->scope = Scope;
    Entry->rowKind = RowKind;
    Entry->status = KSWORD_ARK_PLATFORM_AUDIT_STATUS_OK;
    Entry->hookStatus = KSWORD_ARK_PLATFORM_HOOK_UNKNOWN;
    Entry->confidence = KSWORD_ARK_PLATFORM_CONFIDENCE_NONE;
    Entry->signatureId = SignatureId;
    Entry->slotKind = SlotKind;
    Entry->ownerPolicy = OwnerPolicy;
    Entry->entryIndex = EntryIndex;
    Entry->lastStatus = STATUS_SUCCESS;
    if (TableAddress != NULL) {
        Entry->tableAddress = (ULONGLONG)(ULONG_PTR)TableAddress;
        Entry->fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_TABLE_ADDRESS;
    }
    KswPlatformCopyWide(Entry->name, RTL_NUMBER_OF(Entry->name), Name);
}

static BOOLEAN
KswPlatformAddExportedFunction(
    _Inout_ KSWORD_ARK_QUERY_PLATFORM_AUDIT_RESPONSE* Response,
    _In_ ULONG Capacity,
    _In_ ULONG MaxRows,
    _In_ ULONG Scope,
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_z_ PCWSTR ExportName,
    _In_ ULONG OwnerPolicy
    )
{
    PVOID functionAddress = KswPlatformGetRoutine(ExportName);
    KSWORD_ARK_PLATFORM_AUDIT_ENTRY entry;

    if (functionAddress == NULL) {
        return FALSE;
    }
    KswPlatformInitializeEntry(
        &entry,
        Scope,
        KSWORD_ARK_PLATFORM_AUDIT_ROW_FUNCTION,
        KSWORD_ARK_PLATFORM_SIGNATURE_EXACT_EXPORT_ONLY,
        KSWORD_ARK_PLATFORM_SLOT_FUNCTION,
        OwnerPolicy,
        0UL,
        NULL,
        ExportName);
    entry.liveAddress = (ULONGLONG)(ULONG_PTR)functionAddress;
    entry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_LIVE_ADDRESS |
        KSWORD_ARK_PLATFORM_FIELD_EXACT_EXPORT;
    KswPlatformClassifyFunction(&entry, ModuleInfo, OwnerPolicy);
    KswPlatformAppend(Response, Capacity, MaxRows, &entry);
    return TRUE;
}

static ULONG
KswPlatformHalDispatchSlotCount(
    _In_ ULONG Version
    )
{
    // 中文说明：HAL_DISPATCH 以尾部追加字段演进；v4 到
    // HalSetPciErrorHandlerCallback，v5 再含 HalGetPrmCache，v6 含全部字段。
    if (Version == 4UL) {
        return 22UL;
    }
    if (Version == 5UL) {
        return 23UL;
    }
    if (Version == 6UL) {
        return (ULONG)RTL_NUMBER_OF(g_KswHalDispatchSlots);
    }
    return 0UL;
}

static VOID
KswPlatformAddHalDispatch(
    _Inout_ KSWORD_ARK_QUERY_PLATFORM_AUDIT_RESPONSE* Response,
    _In_ ULONG Capacity,
    _In_ ULONG MaxRows,
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo
    )
{
    PVOID tableAddress = KswPlatformGetRoutine(L"HalDispatchTable");
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* tableOwner = NULL;
    ULONG version = 0UL;
    ULONG index = 0UL;
    ULONG slotCount = 0UL;
    ULONG tableBytes = 0UL;
    ULONG signatureId = KSWORD_ARK_PLATFORM_SIGNATURE_NONE;
    KSWORD_ARK_PLATFORM_AUDIT_ENTRY versionEntry;

    if (tableAddress == NULL) {
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_DISPATCH,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNSUPPORTED,
            STATUS_PROCEDURE_NOT_FOUND,
            L"HalDispatchTable",
            KSWORD_ARK_PLATFORM_DETAIL_LOCATOR_NOT_FOUND,
            0ULL,
            0ULL);
        return;
    }

    tableOwner = KswordARKHookFindModuleForAddress(ModuleInfo, (ULONG_PTR)tableAddress);
    if (!KswPlatformIsExpectedHalOwner(tableOwner) ||
        !KswPlatformRangeInSection(
            tableOwner,
            (ULONG_PTR)tableAddress,
            sizeof(version),
            FALSE,
            FALSE) ||
        !KswordARKHookReadMemorySafe(tableAddress, &version, sizeof(version))) {
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_DISPATCH,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_SIGNATURE_MISMATCH,
            STATUS_DATA_ERROR,
            L"HalDispatchTable",
            KSWORD_ARK_PLATFORM_DETAIL_RANGE_INVALID,
            sizeof(version),
            0ULL);
        return;
    }
    slotCount = KswPlatformHalDispatchSlotCount(version);
    if (slotCount == 0UL) {
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_DISPATCH,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNSUPPORTED,
            STATUS_REVISION_MISMATCH,
            L"HalDispatchTable",
            KSWORD_ARK_PLATFORM_DETAIL_VERSION_MISMATCH,
            4ULL,
            version);
        return;
    }
    tableBytes = g_KswHalDispatchSlots[slotCount - 1UL].Offset +
        g_KswHalDispatchSlots[slotCount - 1UL].Width;
    if (!KswPlatformIsExpectedHalOwner(tableOwner) ||
        !KswPlatformRangeInSection(
            tableOwner,
            (ULONG_PTR)tableAddress,
            tableBytes,
            FALSE,
            FALSE)) {
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_DISPATCH,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_SIGNATURE_MISMATCH,
            STATUS_DATA_ERROR,
            L"HalDispatchTable",
            KSWORD_ARK_PLATFORM_DETAIL_RANGE_INVALID,
            tableBytes,
            0ULL);
        return;
    }
    signatureId = version == HAL_DISPATCH_VERSION ?
        KSWORD_ARK_PLATFORM_SIGNATURE_PUBLIC_HAL_V6 :
        KSWORD_ARK_PLATFORM_SIGNATURE_PUBLIC_HAL_V4_V5;
    KswPlatformInitializeEntry(
        &versionEntry,
        KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_DISPATCH,
        KSWORD_ARK_PLATFORM_AUDIT_ROW_TABLE,
        signatureId,
        KSWORD_ARK_PLATFORM_SLOT_SCALAR,
        KSWORD_ARK_PLATFORM_OWNER_NONE,
        0UL,
        tableAddress,
        L"Version");
    versionEntry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_EXACT_EXPORT |
        KSWORD_ARK_PLATFORM_FIELD_STRUCTURE_VALIDATED;
    KswPlatformSetDetail(
        &versionEntry,
        KSWORD_ARK_PLATFORM_DETAIL_SCALAR_VALUE,
        version,
        tableBytes,
        slotCount,
        0ULL);
    KswPlatformAppend(Response, Capacity, MaxRows, &versionEntry);

    for (index = 0UL; index < slotCount; ++index) {
        const KSW_PLATFORM_SLOT_DESCRIPTOR* descriptor = &g_KswHalDispatchSlots[index];
        KSWORD_ARK_PLATFORM_AUDIT_ENTRY entry;
        ULONGLONG value = 0ULL;

        KswPlatformInitializeEntry(
            &entry,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_DISPATCH,
            descriptor->SlotKind == KSWORD_ARK_PLATFORM_SLOT_FUNCTION ?
                KSWORD_ARK_PLATFORM_AUDIT_ROW_FUNCTION :
                KSWORD_ARK_PLATFORM_AUDIT_ROW_TABLE,
            signatureId,
            descriptor->SlotKind,
            descriptor->OwnerPolicy,
            index,
            tableAddress,
            descriptor->Name);
        entry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_STRUCTURE_VALIDATED |
            KSWORD_ARK_PLATFORM_FIELD_EXACT_EXPORT;

        if (descriptor->Width > sizeof(value) ||
            !KswordARKHookReadMemorySafe(
                (const UCHAR*)tableAddress + descriptor->Offset,
                &value,
                descriptor->Width)) {
            entry.status = KSWORD_ARK_PLATFORM_AUDIT_STATUS_QUERY_FAILED;
            entry.lastStatus = STATUS_PARTIAL_COPY;
            KswPlatformSetDetail(
                &entry,
                KSWORD_ARK_PLATFORM_DETAIL_READ_FAILED,
                descriptor->Offset,
                descriptor->Width,
                0ULL,
                0ULL);
        }
        else if (descriptor->SlotKind == KSWORD_ARK_PLATFORM_SLOT_SCALAR) {
            KswPlatformSetDetail(
                &entry,
                KSWORD_ARK_PLATFORM_DETAIL_SCALAR_VALUE,
                value,
                descriptor->Offset,
                descriptor->Width,
                0ULL);
        }
        else if (value == 0ULL) {
            entry.status = KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNAVAILABLE;
            KswPlatformSetDetail(
                &entry,
                KSWORD_ARK_PLATFORM_DETAIL_NULL_SLOT,
                descriptor->Offset,
                0ULL,
                0ULL,
                0ULL);
        }
        else {
            entry.liveAddress = value;
            entry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_LIVE_ADDRESS;
            KswPlatformClassifyFunction(&entry, ModuleInfo, descriptor->OwnerPolicy);
        }
        KswPlatformAppend(Response, Capacity, MaxRows, &entry);
    }
}

static ULONG
KswPlatformCanonicalBuildNumber(
    _In_ ULONG BuildNumber
    )
{
    // 中文说明：Windows 10 2004～22H2 都报告不同产品 build，但共享
    // 19041 内核基线；同理 22621/22631 共用同一 22H2/23H2 结构族。
    if (BuildNumber >= 19041UL && BuildNumber <= 19045UL) {
        return 19041UL;
    }
    if (BuildNumber >= 22621UL && BuildNumber <= 22631UL) {
        return 22621UL;
    }
    return BuildNumber;
}

static const KSW_PLATFORM_PRIVATE_BUILD_DESCRIPTOR*
KswPlatformFindPrivateBuild(
    _In_ ULONG BuildNumber
    )
{
    ULONG canonicalBuild = KswPlatformCanonicalBuildNumber(BuildNumber);
    ULONG index = 0UL;

    for (index = 0UL; index < RTL_NUMBER_OF(g_KswHalPrivateBuilds); ++index) {
        if (g_KswHalPrivateBuilds[index].BuildNumber == canonicalBuild) {
            return &g_KswHalPrivateBuilds[index];
        }
    }
    return NULL;
}

static const KSW_PLATFORM_PRIVATE_BUILD_DESCRIPTOR*
KswPlatformFindPrivateVersion(
    _In_ ULONG Version
    )
{
    ULONG index = 0UL;

    for (index = 0UL; index < RTL_NUMBER_OF(g_KswHalPrivateBuilds); ++index) {
        if (g_KswHalPrivateBuilds[index].Version == Version) {
            return &g_KswHalPrivateBuilds[index];
        }
    }
    return NULL;
}

static NTSTATUS
KswPlatformLocateHalPrivateBySignature(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ ULONG BuildNumber,
    _In_ const KSW_PLATFORM_PRIVATE_BUILD_DESCRIPTOR* Build,
    _Outptr_ PVOID* TableAddressOut,
    _Out_ ULONG* VersionOut
    );

static VOID
KswPlatformAddHalPrivate(
    _Inout_ KSWORD_ARK_QUERY_PLATFORM_AUDIT_RESPONSE* Response,
    _In_ ULONG Capacity,
    _In_ ULONG MaxRows,
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ ULONG BuildNumber
    )
{
    const KSW_PLATFORM_PRIVATE_BUILD_DESCRIPTOR* build =
        KswPlatformFindPrivateBuild(BuildNumber);
    PVOID tableAddress = NULL;
    ULONG version = 0UL;
    ULONG index = 0UL;
    NTSTATUS locateStatus = STATUS_NOT_SUPPORTED;
    BOOLEAN exactExport = FALSE;
    KSWORD_ARK_PLATFORM_AUDIT_ENTRY versionEntry;
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* tableOwner = NULL;

    // 中文说明：数据导出提供精确表地址，先验证 owner、受界范围和版本，
    // 避免依赖单一系统构建的指令窗口。只有已知 Version/ByteSize 才展开槽位。
    tableAddress = KswPlatformGetRoutine(L"HalPrivateDispatchTable");
    tableOwner = KswordARKHookFindModuleForAddress(
        ModuleInfo,
        (ULONG_PTR)tableAddress);
    if (tableAddress != NULL &&
        KswPlatformIsExpectedHalOwner(tableOwner) &&
        KswPlatformRangeInSection(
            tableOwner,
            (ULONG_PTR)tableAddress,
            sizeof(version),
            FALSE,
            FALSE) &&
        KswordARKHookReadMemorySafe(
            tableAddress,
            &version,
            sizeof(version))) {
        const KSW_PLATFORM_PRIVATE_BUILD_DESCRIPTOR* versionBuild =
            KswPlatformFindPrivateVersion(version);
        if (versionBuild != NULL &&
            KswPlatformRangeInSection(
                tableOwner,
                (ULONG_PTR)tableAddress,
                versionBuild->ByteSize,
                FALSE,
                FALSE)) {
            build = versionBuild;
            locateStatus = STATUS_SUCCESS;
            exactExport = TRUE;
        }
        else {
            KswPlatformInitializeEntry(
                &versionEntry,
                KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_PRIVATE,
                KSWORD_ARK_PLATFORM_AUDIT_ROW_TABLE,
                KSWORD_ARK_PLATFORM_SIGNATURE_EXACT_EXPORT_ONLY,
                KSWORD_ARK_PLATFORM_SLOT_SCALAR,
                KSWORD_ARK_PLATFORM_OWNER_NONE,
                0UL,
                tableAddress,
                L"Version");
            versionEntry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_EXACT_EXPORT;
            KswPlatformSetDetail(
                &versionEntry,
                KSWORD_ARK_PLATFORM_DETAIL_SCALAR_VALUE,
                version,
                BuildNumber,
                0ULL,
                0ULL);
            KswPlatformAppend(Response, Capacity, MaxRows, &versionEntry);
            (VOID)KswPlatformAddExportedFunction(
                Response,
                Capacity,
                MaxRows,
                KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_PRIVATE,
                ModuleInfo,
                L"HalTranslateBusAddress",
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL_PCI);
            (VOID)KswPlatformAddExportedFunction(
                Response,
                Capacity,
                MaxRows,
                KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_PRIVATE,
                ModuleInfo,
                L"HalAssignSlotResources",
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL_PCI);
            return;
        }
    }

    // 中文说明：旧系统若不暴露数据导出，仍保留受界 RIP-relative
    // 定位；候选必须唯一，且完整 Version/ByteSize 同时验证。
    if (!NT_SUCCESS(locateStatus) && build != NULL) {
        locateStatus = KswPlatformLocateHalPrivateBySignature(
            ModuleInfo,
            BuildNumber,
            build,
            &tableAddress,
            &version);
    }
    if (!NT_SUCCESS(locateStatus)) {
        if (KswPlatformAddExportedFunction(
                Response,
                Capacity,
                MaxRows,
                KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_PRIVATE,
                ModuleInfo,
                L"HalTranslateBusAddress",
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL_PCI)) {
            return;
        }
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_PRIVATE,
            locateStatus == STATUS_NOT_SUPPORTED ?
                KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNSUPPORTED :
                KSWORD_ARK_PLATFORM_AUDIT_STATUS_SIGNATURE_MISMATCH,
            locateStatus,
            L"HalPrivateDispatchTable",
            locateStatus == STATUS_OBJECT_NAME_COLLISION ?
                KSWORD_ARK_PLATFORM_DETAIL_LOCATOR_NOT_UNIQUE :
                (locateStatus == STATUS_REVISION_MISMATCH ?
                    KSWORD_ARK_PLATFORM_DETAIL_VERSION_MISMATCH :
                    (locateStatus == STATUS_NOT_SUPPORTED ?
                        KSWORD_ARK_PLATFORM_DETAIL_BUILD_UNSUPPORTED :
                        KSWORD_ARK_PLATFORM_DETAIL_LOCATOR_NOT_FOUND)),
            locateStatus == STATUS_REVISION_MISMATCH && build != NULL ?
                build->Version :
                BuildNumber,
            locateStatus == STATUS_REVISION_MISMATCH && build != NULL ?
                version :
                (build != NULL ? build->ByteSize : 0UL));
        return;
    }

    KswPlatformInitializeEntry(
        &versionEntry,
        KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_PRIVATE,
        KSWORD_ARK_PLATFORM_AUDIT_ROW_TABLE,
        build->SignatureId,
        KSWORD_ARK_PLATFORM_SLOT_SCALAR,
        KSWORD_ARK_PLATFORM_OWNER_NONE,
        0UL,
        tableAddress,
        L"Version");
    versionEntry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_STRUCTURE_VALIDATED |
        (exactExport ?
            KSWORD_ARK_PLATFORM_FIELD_EXACT_EXPORT :
            KSWORD_ARK_PLATFORM_FIELD_LOCATOR_VALIDATED);
    KswPlatformSetDetail(
        &versionEntry,
        KSWORD_ARK_PLATFORM_DETAIL_SCALAR_VALUE,
        version,
        build->ByteSize,
        BuildNumber,
        0ULL);
    KswPlatformAppend(Response, Capacity, MaxRows, &versionEntry);

    for (index = 0UL; index < RTL_NUMBER_OF(g_KswHalPrivateSlots); ++index) {
        const KSW_PLATFORM_SLOT_DESCRIPTOR* descriptor = &g_KswHalPrivateSlots[index];
        KSWORD_ARK_PLATFORM_AUDIT_ENTRY entry;
        PVOID functionAddress = NULL;

        if (descriptor->Offset + descriptor->Width > build->ByteSize) {
            break;
        }
        KswPlatformInitializeEntry(
            &entry,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_PRIVATE,
            descriptor->SlotKind == KSWORD_ARK_PLATFORM_SLOT_FUNCTION ?
                KSWORD_ARK_PLATFORM_AUDIT_ROW_FUNCTION :
                KSWORD_ARK_PLATFORM_AUDIT_ROW_TABLE,
            build->SignatureId,
            descriptor->SlotKind,
            descriptor->OwnerPolicy,
            index + 1UL,
            tableAddress,
            descriptor->Name);
        entry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_STRUCTURE_VALIDATED |
            (exactExport ?
                KSWORD_ARK_PLATFORM_FIELD_EXACT_EXPORT :
                KSWORD_ARK_PLATFORM_FIELD_LOCATOR_VALIDATED);

        if (!KswordARKHookReadMemorySafe(
                (const UCHAR*)tableAddress + descriptor->Offset,
                &functionAddress,
                descriptor->Width)) {
            entry.status = KSWORD_ARK_PLATFORM_AUDIT_STATUS_QUERY_FAILED;
            entry.lastStatus = STATUS_PARTIAL_COPY;
            KswPlatformSetDetail(
                &entry,
                KSWORD_ARK_PLATFORM_DETAIL_READ_FAILED,
                descriptor->Offset,
                descriptor->Width,
                BuildNumber,
                version);
        }
        else if (descriptor->SlotKind == KSWORD_ARK_PLATFORM_SLOT_DUMMY) {
            KswPlatformSetDetail(
                &entry,
                KSWORD_ARK_PLATFORM_DETAIL_DUMMY_SLOT,
                (ULONGLONG)(ULONG_PTR)functionAddress,
                descriptor->Offset,
                BuildNumber,
                version);
        }
        else if (functionAddress == NULL) {
            entry.status = KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNAVAILABLE;
            KswPlatformSetDetail(
                &entry,
                KSWORD_ARK_PLATFORM_DETAIL_NULL_SLOT,
                descriptor->Offset,
                BuildNumber,
                version,
                0ULL);
        }
        else {
            entry.liveAddress = (ULONGLONG)(ULONG_PTR)functionAddress;
            entry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_LIVE_ADDRESS;
            KswPlatformClassifyFunction(&entry, ModuleInfo, descriptor->OwnerPolicy);
        }
        KswPlatformAppend(Response, Capacity, MaxRows, &entry);
    }
}

typedef struct _KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR
{
    ULONG BuildNumber;
    PCWSTR AnchorName;
    ULONG ScanOffset;
    ULONG ScanBytes;
    LONG CandidateAdjustment;
    ULONG TableByteSize;
    ULONG ExpectedVersion;
    UCHAR Bytes[7];
    UCHAR Mask[7];
} KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR;

typedef BOOLEAN
(*KSW_PLATFORM_VALIDATE_TABLE_ROUTINE)(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ PVOID Candidate,
    _In_ const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR* Locator
    );

// HalTranslateBusAddress 通过 HalPrivateDispatchTable+0x38 分派。
// 表基址必须由该受信导出的有界代码窗口内唯一的 RIP-relative 读取反推，
// 不允许回退到 HalPrivateDispatchTable 导出，也不扫描整个内核映像。
static const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR g_KswHalPrivateLocators[] = {
    {
        19041UL, L"HalTranslateBusAddress", 0x00UL, 0x80UL, -0x38L,
        0x4B0UL, 51UL,
        { 0x48U, 0x8BU, 0x05U, 0U, 0U, 0U, 0U },
        { 0xFFU, 0xFFU, 0xFFU, 0U, 0U, 0U, 0U }
    },
    {
        22000UL, L"HalTranslateBusAddress", 0x00UL, 0x80UL, -0x38L,
        0x4D8UL, 54UL,
        { 0x48U, 0x8BU, 0x05U, 0U, 0U, 0U, 0U },
        { 0xFFU, 0xFFU, 0xFFU, 0U, 0U, 0U, 0U }
    },
    {
        22621UL, L"HalTranslateBusAddress", 0x00UL, 0x80UL, -0x38L,
        0x4F0UL, 58UL,
        { 0x48U, 0x8BU, 0x05U, 0U, 0U, 0U, 0U },
        { 0xFFU, 0xFFU, 0xFFU, 0U, 0U, 0U, 0U }
    },
    {
        26100UL, L"HalTranslateBusAddress", 0x00UL, 0x80UL, -0x38L,
        0x518UL, 61UL,
        { 0x48U, 0x8BU, 0x05U, 0U, 0U, 0U, 0U },
        { 0xFFU, 0xFFU, 0xFFU, 0U, 0U, 0U, 0U }
    },
    {
        26220UL, L"HalTranslateBusAddress", 0x00UL, 0x80UL, -0x38L,
        0x518UL, 61UL,
        { 0x48U, 0x8BU, 0x05U, 0U, 0U, 0U, 0U },
        { 0xFFU, 0xFFU, 0xFFU, 0U, 0U, 0U, 0U }
    }
};

static const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR g_KswHalAcpiLocators[] = {
    {
        19041UL, NULL, 0x00UL, 0xC0UL, 0L,
        FIELD_OFFSET(KSW_PLATFORM_HAL_ACPI_VIEW, Functions), 0UL,
        { 0x48U, 0x8DU, 0x05U, 0U, 0U, 0U, 0U },
        { 0xF8U, 0xFFU, 0xC7U, 0U, 0U, 0U, 0U }
    },
    {
        22000UL, NULL, 0x00UL, 0xC0UL, 0L,
        FIELD_OFFSET(KSW_PLATFORM_HAL_ACPI_VIEW, Functions), 0UL,
        { 0x48U, 0x8DU, 0x05U, 0U, 0U, 0U, 0U },
        { 0xF8U, 0xFFU, 0xC7U, 0U, 0U, 0U, 0U }
    },
    {
        22621UL, NULL, 0x00UL, 0xC0UL, 0L,
        FIELD_OFFSET(KSW_PLATFORM_HAL_ACPI_VIEW, Functions), 0UL,
        { 0x48U, 0x8DU, 0x05U, 0U, 0U, 0U, 0U },
        { 0xF8U, 0xFFU, 0xC7U, 0U, 0U, 0U, 0U }
    },
    {
        26100UL, NULL, 0x00UL, 0x80UL, 0L,
        FIELD_OFFSET(KSW_PLATFORM_HAL_ACPI_VIEW, Functions), 0UL,
        { 0x48U, 0x8DU, 0x05U, 0U, 0U, 0U, 0U },
        { 0xF8U, 0xFFU, 0xC7U, 0U, 0U, 0U, 0U }
    },
    {
        26220UL, NULL, 0x00UL, 0x80UL, 0L,
        FIELD_OFFSET(KSW_PLATFORM_HAL_ACPI_VIEW, Functions), 0UL,
        { 0x48U, 0x8DU, 0x05U, 0U, 0U, 0U, 0U },
        { 0xF8U, 0xFFU, 0xC7U, 0U, 0U, 0U, 0U }
    }
};

static const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR g_KswHalSubcomponentLocators[] = {
    {
        // 中文说明：Vibranium 的导出入口先转入紧邻的 phase/helper，
        // helper 在 +0xAB 以 lea r12,[HalSubComponents] 取得 21 项表。
        // 仅扫描该短窗口，并继续用全部只读名称对确认候选身份。
        19041UL, L"HalInitSystem", 0xA0UL, 0x20UL, 0L,
        sizeof(KSW_PLATFORM_HAL_SUBCOMPONENT) *
            KSW_PLATFORM_HAL_SUBCOMPONENT_LEGACY_COUNT,
        KSW_PLATFORM_HAL_SUBCOMPONENT_LEGACY_COUNT,
        { 0x4CU, 0x8DU, 0x25U, 0U, 0U, 0U, 0U },
        { 0xFFU, 0xFFU, 0xFFU, 0U, 0U, 0U, 0U }
    },
    {
        26100UL, L"HalInitSystem", 0x00UL, 0x90UL, 0L,
        sizeof(KSW_PLATFORM_HAL_SUBCOMPONENT) *
            KSW_PLATFORM_HAL_SUBCOMPONENT_MAX_COUNT,
        KSW_PLATFORM_HAL_SUBCOMPONENT_MAX_COUNT,
        { 0x48U, 0x8DU, 0x05U, 0U, 0U, 0U, 0U },
        { 0xF8U, 0xFFU, 0xC7U, 0U, 0U, 0U, 0U }
    },
    {
        26220UL, L"HalInitSystem", 0x70UL, 0x20UL, 0L,
        sizeof(KSW_PLATFORM_HAL_SUBCOMPONENT) *
            KSW_PLATFORM_HAL_SUBCOMPONENT_MAX_COUNT,
        KSW_PLATFORM_HAL_SUBCOMPONENT_MAX_COUNT,
        { 0x4CU, 0x8DU, 0x25U, 0U, 0U, 0U, 0U },
        { 0xFFU, 0xFFU, 0xFFU, 0U, 0U, 0U, 0U }
    }
};

static const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR*
KswPlatformFindRipLocator(
    _In_reads_(DescriptorCount) const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR* Descriptors,
    _In_ ULONG DescriptorCount,
    _In_ ULONG BuildNumber
    )
{
    ULONG canonicalBuild = KswPlatformCanonicalBuildNumber(BuildNumber);
    ULONG index = 0UL;

    for (index = 0UL; index < DescriptorCount; ++index) {
        if (Descriptors[index].BuildNumber == canonicalBuild) {
            return &Descriptors[index];
        }
    }
    return NULL;
}

static NTSTATUS
KswPlatformLocateRipTable(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_opt_ PVOID Anchor,
    _In_ const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR* Locator,
    _In_ KSW_PLATFORM_VALIDATE_TABLE_ROUTINE ValidateCandidate,
    _Outptr_ PVOID* TableAddressOut
    )
{
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* anchorOwner = NULL;
    ULONG offset = 0UL;
    ULONG uniqueCount = 0UL;
    PVOID uniqueCandidate = NULL;

    if (ModuleInfo == NULL || Anchor == NULL || Locator == NULL ||
        ValidateCandidate == NULL || TableAddressOut == NULL ||
        Locator->ScanBytes < RTL_NUMBER_OF(Locator->Bytes) ||
        Locator->ScanOffset > MAXULONG - Locator->ScanBytes ||
        Locator->TableByteSize == 0UL) {
        return STATUS_INVALID_PARAMETER;
    }
    *TableAddressOut = NULL;
    anchorOwner = KswordARKHookFindModuleForAddress(ModuleInfo, (ULONG_PTR)Anchor);
    if (!KswPlatformIsExpectedHalOwner(anchorOwner) ||
        !KswPlatformRangeInSection(
            anchorOwner,
            (ULONG_PTR)Anchor,
            Locator->ScanOffset + Locator->ScanBytes,
            TRUE,
            FALSE)) {
        return STATUS_INVALID_ADDRESS;
    }

    // 中文说明：只检查 build descriptor 指定的小窗口，并要求完整结构验证后
    // 恰好产生一个候选；不会扫描内核映像的其它区域。
    for (offset = 0UL;
         offset + RTL_NUMBER_OF(Locator->Bytes) <= Locator->ScanBytes;
         ++offset) {
        UCHAR instruction[7];
        LONG displacement = 0;
        ULONG_PTR candidateAddress = 0U;
        ULONG64 candidateAddress64 = 0ULL;
        ULONG64 instructionEnd = 0ULL;
        PVOID candidate = NULL;

        RtlZeroMemory(instruction, sizeof(instruction));
        if (!KswordARKHookReadMemorySafe(
                (const UCHAR*)Anchor + Locator->ScanOffset + offset,
                instruction,
                sizeof(instruction)) ||
            !KswPlatformMaskedBytesMatch(
                instruction,
                Locator->Bytes,
                Locator->Mask,
                RTL_NUMBER_OF(Locator->Bytes))) {
            continue;
        }
        RtlCopyMemory(&displacement, instruction + 3UL, sizeof(displacement));
        if ((ULONG64)(ULONG_PTR)Anchor >
            MAXULONGLONG -
                (ULONG64)Locator->ScanOffset -
                (ULONG64)offset -
                (ULONG64)RTL_NUMBER_OF(Locator->Bytes)) {
            continue;
        }
        instructionEnd =
            (ULONG64)(ULONG_PTR)Anchor +
            (ULONG64)Locator->ScanOffset +
            (ULONG64)offset +
            (ULONG64)RTL_NUMBER_OF(Locator->Bytes);
        if (!KswPlatformAddSignedDisplacement(
                instructionEnd,
                (LONGLONG)displacement,
                &candidateAddress64) ||
            !KswPlatformAddSignedDisplacement(
                candidateAddress64,
                (LONGLONG)Locator->CandidateAdjustment,
                &candidateAddress64) ||
            candidateAddress64 > MAXULONG_PTR) {
            continue;
        }
        candidateAddress = (ULONG_PTR)candidateAddress64;
        candidate = (PVOID)candidateAddress;
        if (!ValidateCandidate(ModuleInfo, candidate, Locator)) {
            continue;
        }
        if (candidate == uniqueCandidate) {
            continue;
        }
        uniqueCandidate = candidate;
        uniqueCount += 1UL;
    }

    if (uniqueCount == 0UL) {
        return STATUS_NOT_FOUND;
    }
    if (uniqueCount != 1UL) {
        return STATUS_OBJECT_NAME_COLLISION;
    }
    *TableAddressOut = uniqueCandidate;
    return STATUS_SUCCESS;
}

static BOOLEAN
KswPlatformValidateHalPrivateCandidate(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ PVOID Candidate,
    _In_ const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR* Locator
    )
{
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* tableOwner = NULL;
    ULONG version = 0UL;

    if (ModuleInfo == NULL || Candidate == NULL || Locator == NULL ||
        Locator->TableByteSize < sizeof(version)) {
        return FALSE;
    }
    tableOwner = KswordARKHookFindModuleForAddress(
        ModuleInfo,
        (ULONG_PTR)Candidate);
    return KswPlatformIsExpectedHalOwner(tableOwner) &&
        KswPlatformRangeInSection(
            tableOwner,
            (ULONG_PTR)Candidate,
            Locator->TableByteSize,
            FALSE,
            FALSE) &&
        KswordARKHookReadMemorySafe(Candidate, &version, sizeof(version)) &&
        version == Locator->ExpectedVersion;
}

static NTSTATUS
KswPlatformLocateHalPrivateBySignature(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ ULONG BuildNumber,
    _In_ const KSW_PLATFORM_PRIVATE_BUILD_DESCRIPTOR* Build,
    _Outptr_ PVOID* TableAddressOut,
    _Out_ ULONG* VersionOut
    )
{
    const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR* locator = NULL;
    PVOID anchor = NULL;
    NTSTATUS status = STATUS_NOT_SUPPORTED;

    if (ModuleInfo == NULL || Build == NULL ||
        TableAddressOut == NULL || VersionOut == NULL) {
        return STATUS_INVALID_PARAMETER;
    }
    *TableAddressOut = NULL;
    *VersionOut = 0UL;
    locator = KswPlatformFindRipLocator(
        g_KswHalPrivateLocators,
        RTL_NUMBER_OF(g_KswHalPrivateLocators),
        BuildNumber);
    if (locator == NULL ||
        locator->AnchorName == NULL ||
        locator->TableByteSize != Build->ByteSize ||
        locator->ExpectedVersion != Build->Version) {
        return STATUS_NOT_SUPPORTED;
    }
    anchor = KswPlatformGetRoutine(locator->AnchorName);
    if (anchor == NULL) {
        return STATUS_NOT_SUPPORTED;
    }
    status = KswPlatformLocateRipTable(
        ModuleInfo,
        anchor,
        locator,
        KswPlatformValidateHalPrivateCandidate,
        TableAddressOut);
    if (!NT_SUCCESS(status)) {
        return status;
    }
    if (!KswordARKHookReadMemorySafe(
            *TableAddressOut,
            VersionOut,
            sizeof(*VersionOut))) {
        *TableAddressOut = NULL;
        return STATUS_PARTIAL_COPY;
    }
    if (*VersionOut != Build->Version) {
        *TableAddressOut = NULL;
        return STATUS_REVISION_MISMATCH;
    }
    return STATUS_SUCCESS;
}

static BOOLEAN
KswPlatformGetHalAcpiLayout(
    _In_ ULONG Version,
    _Out_ ULONG* FunctionCountOut,
    _Out_ ULONG* ByteSizeOut
    )
{
    ULONG functionCount = 0UL;

    if (FunctionCountOut == NULL || ByteSizeOut == NULL) {
        return FALSE;
    }
    *FunctionCountOut = 0UL;
    *ByteSizeOut = 0UL;
    if (Version == KSW_PLATFORM_HAL_ACPI_VERSION_V4) {
        functionCount = KSW_PLATFORM_HAL_ACPI_V4_FUNCTION_COUNT;
    }
    else if (Version == KSW_PLATFORM_HAL_ACPI_VERSION_V5) {
        functionCount = KSW_PLATFORM_HAL_ACPI_V5_FUNCTION_COUNT;
    }
    else {
        return FALSE;
    }
    *FunctionCountOut = functionCount;
    *ByteSizeOut =
        FIELD_OFFSET(KSW_PLATFORM_HAL_ACPI_VIEW, Functions) +
        (ULONG)(sizeof(PVOID) * functionCount);
    return TRUE;
}

static BOOLEAN
KswPlatformHalAcpiIdentityMatches(
    _In_ const KSW_PLATFORM_HAL_ACPI_VIEW* View,
    _Out_opt_ ULONG* FunctionCountOut,
    _Out_opt_ ULONG* ByteSizeOut
    )
{
    ULONG functionCount = 0UL;
    ULONG byteSize = 0UL;

    if (View == NULL ||
        View->Signature != KSW_PLATFORM_HAL_ACPI_SIGNATURE ||
        !KswPlatformGetHalAcpiLayout(
            View->Version,
            &functionCount,
            &byteSize)) {
        return FALSE;
    }
    if (FunctionCountOut != NULL) {
        *FunctionCountOut = functionCount;
    }
    if (ByteSizeOut != NULL) {
        *ByteSizeOut = byteSize;
    }
    return TRUE;
}

static BOOLEAN
KswPlatformValidateHalAcpiCandidate(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ PVOID Candidate,
    _In_ const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR* Locator
    )
{
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* tableOwner = NULL;
    KSW_PLATFORM_HAL_ACPI_VIEW view;
    ULONG functionCount = 0UL;
    ULONG byteSize = 0UL;
    const ULONG headerSize =
        FIELD_OFFSET(KSW_PLATFORM_HAL_ACPI_VIEW, Functions);

    if (ModuleInfo == NULL || Candidate == NULL || Locator == NULL ||
        Locator->TableByteSize != headerSize ||
        Locator->ExpectedVersion != 0UL) {
        return FALSE;
    }
    tableOwner = KswordARKHookFindModuleForAddress(ModuleInfo, (ULONG_PTR)Candidate);
    RtlZeroMemory(&view, sizeof(view));
    if (!KswPlatformIsExpectedHalOwner(tableOwner) ||
        !KswPlatformRangeInSection(
            tableOwner,
            (ULONG_PTR)Candidate,
            headerSize,
            FALSE,
            TRUE) ||
        !KswordARKHookReadMemorySafe(Candidate, &view, headerSize) ||
        !KswPlatformHalAcpiIdentityMatches(
            &view,
            &functionCount,
            &byteSize) ||
        functionCount > RTL_NUMBER_OF(view.Functions) ||
        !KswPlatformRangeInSection(
            tableOwner,
            (ULONG_PTR)Candidate,
            byteSize,
            FALSE,
            TRUE) ||
        !KswordARKHookReadMemorySafe(Candidate, &view, byteSize) ||
        !KswPlatformHalAcpiIdentityMatches(&view, NULL, NULL)) {
        return FALSE;
    }
    // 函数槽内容不是表身份条件：外部 owner、非执行地址或 NULL 正是需要
    // 逐行保留并报告的异常证据，不能让它们把整个候选吞成 locator-not-found。
    return TRUE;
}

static BOOLEAN
KswPlatformValidateBoundedWideName(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ PCWSTR NameAddress,
    _In_z_ PCWSTR ExpectedName
    )
{
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* owner = NULL;
    SIZE_T expectedChars = 0U;
    WCHAR buffer[32];

    if (ModuleInfo == NULL || NameAddress == NULL || ExpectedName == NULL) {
        return FALSE;
    }
    while (ExpectedName[expectedChars] != L'\0' &&
           expectedChars < RTL_NUMBER_OF(buffer) - 1U) {
        expectedChars += 1U;
    }
    if (ExpectedName[expectedChars] != L'\0') {
        return FALSE;
    }
    owner = KswordARKHookFindModuleForAddress(ModuleInfo, (ULONG_PTR)NameAddress);
    RtlZeroMemory(buffer, sizeof(buffer));
    if (!KswPlatformIsExpectedHalOwner(owner) ||
        !KswPlatformRangeInSection(
            owner,
            (ULONG_PTR)NameAddress,
            (expectedChars + 1U) * sizeof(WCHAR),
            FALSE,
            TRUE) ||
        !KswordARKHookReadMemorySafe(
            NameAddress,
            buffer,
            (expectedChars + 1U) * sizeof(WCHAR))) {
        return FALSE;
    }
    return RtlCompareMemory(
        buffer,
        ExpectedName,
        (expectedChars + 1U) * sizeof(WCHAR)) ==
        (expectedChars + 1U) * sizeof(WCHAR);
}

static BOOLEAN
KswPlatformHalSubcomponentIndex(
    _In_ ULONG EntryIndex,
    _In_ ULONG EntryCount,
    _Out_ ULONG* NameIndexOut
    )
{
    ULONG nameIndex = EntryIndex;

    if (NameIndexOut == NULL ||
        (EntryCount != KSW_PLATFORM_HAL_SUBCOMPONENT_LEGACY_COUNT &&
         EntryCount != KSW_PLATFORM_HAL_SUBCOMPONENT_MAX_COUNT) ||
        EntryIndex >= EntryCount) {
        return FALSE;
    }

    // 中文说明：Vibranium 的 21 项表没有 Qos；新表在 Proc 与 Timer
    // 之间插入 Qos，因此旧表从该索引开始要跳过一个显示/身份名称。
    if (EntryCount == KSW_PLATFORM_HAL_SUBCOMPONENT_LEGACY_COUNT &&
        EntryIndex >= KSW_PLATFORM_HAL_SUBCOMPONENT_QOS_INDEX) {
        nameIndex += 1UL;
    }
    if (nameIndex >= RTL_NUMBER_OF(g_KswHalSubcomponentNames)) {
        return FALSE;
    }
    *NameIndexOut = nameIndex;
    return TRUE;
}

static BOOLEAN
KswPlatformHalSubcomponentIdentityMatches(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_reads_(EntryCount) const KSW_PLATFORM_HAL_SUBCOMPONENT* Entries,
    _In_ ULONG EntryCount
    )
{
    ULONG index = 0UL;

    if (ModuleInfo == NULL || Entries == NULL ||
        (EntryCount != KSW_PLATFORM_HAL_SUBCOMPONENT_LEGACY_COUNT &&
         EntryCount != KSW_PLATFORM_HAL_SUBCOMPONENT_MAX_COUNT)) {
        return FALSE;
    }
    for (index = 0UL; index < EntryCount; ++index) {
        ULONG nameIndex = 0UL;

        if (!KswPlatformHalSubcomponentIndex(
                index,
                EntryCount,
                &nameIndex)) {
            return FALSE;
        }
        if (!KswPlatformValidateBoundedWideName(
                ModuleInfo,
                Entries[index].Name,
                g_KswHalSubcomponentNames[nameIndex])) {
            return FALSE;
        }
    }
    return TRUE;
}

static BOOLEAN
KswPlatformValidateHalSubcomponentCandidate(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ PVOID Candidate,
    _In_ const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR* Locator
    )
{
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* tableOwner = NULL;
    KSW_PLATFORM_HAL_SUBCOMPONENT
        entries[KSW_PLATFORM_HAL_SUBCOMPONENT_MAX_COUNT];
    ULONG entryCount = 0UL;

    if (ModuleInfo == NULL || Candidate == NULL || Locator == NULL) {
        return FALSE;
    }
    entryCount = Locator->ExpectedVersion;
    if ((entryCount != KSW_PLATFORM_HAL_SUBCOMPONENT_LEGACY_COUNT &&
         entryCount != KSW_PLATFORM_HAL_SUBCOMPONENT_MAX_COUNT) ||
        Locator->TableByteSize !=
            (ULONG)(sizeof(KSW_PLATFORM_HAL_SUBCOMPONENT) * entryCount)) {
        return FALSE;
    }
    tableOwner = KswordARKHookFindModuleForAddress(ModuleInfo, (ULONG_PTR)Candidate);
    RtlZeroMemory(entries, sizeof(entries));
    if (!KswPlatformIsExpectedHalOwner(tableOwner) ||
        !KswPlatformRangeInSection(
            tableOwner,
            (ULONG_PTR)Candidate,
            Locator->TableByteSize,
            FALSE,
            TRUE) ||
        !KswordARKHookReadMemorySafe(
            Candidate,
            entries,
            Locator->TableByteSize)) {
        return FALSE;
    }

    if (!KswPlatformHalSubcomponentIdentityMatches(
            ModuleInfo,
            entries,
            entryCount)) {
        return FALSE;
    }
    // 21/22 个只读名称对和受界表范围负责候选身份；函数槽逐项分类。
    // 因此被替换到外部模块、未知地址或 NULL 的函数仍会作为对应行返回。
    return TRUE;
}

static BOOLEAN
KswPlatformGetHalPowerAnchor(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _Outptr_ PVOID* AnchorOut
    )
{
    PVOID tableAddress = KswPlatformGetRoutine(L"HalDispatchTable");
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* tableOwner = NULL;
    ULONG version = 0UL;
    PVOID anchor = NULL;
    ULONG minimumBytes =
        FIELD_OFFSET(HAL_DISPATCH, HalInitPowerManagement) +
        sizeof(((PHAL_DISPATCH)0)->HalInitPowerManagement);

    if (AnchorOut == NULL) {
        return FALSE;
    }
    *AnchorOut = NULL;
    tableOwner = KswordARKHookFindModuleForAddress(ModuleInfo, (ULONG_PTR)tableAddress);
    if (tableAddress == NULL ||
        !KswPlatformIsExpectedHalOwner(tableOwner) ||
        !KswPlatformRangeInSection(
            tableOwner,
            (ULONG_PTR)tableAddress,
            minimumBytes,
            FALSE,
            FALSE) ||
        !KswordARKHookReadMemorySafe(tableAddress, &version, sizeof(version)) ||
        version != HAL_DISPATCH_VERSION ||
        !KswordARKHookReadMemorySafe(
            (const UCHAR*)tableAddress +
                FIELD_OFFSET(HAL_DISPATCH, HalInitPowerManagement),
            &anchor,
            sizeof(anchor)) ||
        anchor == NULL) {
        return FALSE;
    }
    *AnchorOut = anchor;
    return TRUE;
}

static VOID
KswPlatformAddHalAcpi(
    _Inout_ KSWORD_ARK_QUERY_PLATFORM_AUDIT_RESPONSE* Response,
    _In_ ULONG Capacity,
    _In_ ULONG MaxRows,
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ ULONG BuildNumber
    )
{
    const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR* locator =
        KswPlatformFindRipLocator(
            g_KswHalAcpiLocators,
            RTL_NUMBER_OF(g_KswHalAcpiLocators),
            BuildNumber);
    PVOID anchor = NULL;
    PVOID tableAddress = NULL;
    KSW_PLATFORM_HAL_ACPI_VIEW view;
    NTSTATUS locateStatus = STATUS_NOT_SUPPORTED;
    ULONG functionCount = 0UL;
    ULONG byteSize = 0UL;
    const ULONG headerSize =
        FIELD_OFFSET(KSW_PLATFORM_HAL_ACPI_VIEW, Functions);
    ULONG index = 0UL;

    if (locator == NULL ||
        !KswPlatformGetHalPowerAnchor(ModuleInfo, &anchor)) {
        if (KswPlatformAddExportedFunction(
                Response,
                Capacity,
                MaxRows,
                KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI,
                ModuleInfo,
                L"HalAcpiGetTableEx",
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL_ACPI)) {
            return;
        }
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNSUPPORTED,
            STATUS_NOT_SUPPORTED,
            L"HalAcpiDispatchTable",
            KSWORD_ARK_PLATFORM_DETAIL_BUILD_UNSUPPORTED,
            BuildNumber,
            0ULL);
        return;
    }
    locateStatus = KswPlatformLocateRipTable(
        ModuleInfo,
        anchor,
        locator,
        KswPlatformValidateHalAcpiCandidate,
        &tableAddress);
    if (!NT_SUCCESS(locateStatus)) {
        if (KswPlatformAddExportedFunction(
                Response,
                Capacity,
                MaxRows,
                KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI,
                ModuleInfo,
                L"HalAcpiGetTableEx",
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL_ACPI)) {
            return;
        }
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNSUPPORTED,
            locateStatus,
            L"HalAcpiDispatchTable",
            locateStatus == STATUS_OBJECT_NAME_COLLISION ?
                KSWORD_ARK_PLATFORM_DETAIL_LOCATOR_NOT_UNIQUE :
                KSWORD_ARK_PLATFORM_DETAIL_LOCATOR_NOT_FOUND,
            BuildNumber,
            (ULONGLONG)(ULONG_PTR)anchor);
        return;
    }

    RtlZeroMemory(&view, sizeof(view));
    if (!KswordARKHookReadMemorySafe(tableAddress, &view, headerSize)) {
        if (KswPlatformAddExportedFunction(
                Response,
                Capacity,
                MaxRows,
                KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI,
                ModuleInfo,
                L"HalAcpiGetTableEx",
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL_ACPI)) {
            return;
        }
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_QUERY_FAILED,
            STATUS_PARTIAL_COPY,
            L"HalAcpiDispatchTable",
            KSWORD_ARK_PLATFORM_DETAIL_READ_FAILED,
            (ULONGLONG)(ULONG_PTR)tableAddress,
            headerSize);
        return;
    }
    if (!KswPlatformHalAcpiIdentityMatches(
            &view,
            &functionCount,
            &byteSize)) {
        if (KswPlatformAddExportedFunction(
                Response,
                Capacity,
                MaxRows,
                KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI,
                ModuleInfo,
                L"HalAcpiGetTableEx",
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL_ACPI)) {
            return;
        }
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_QUERY_FAILED,
            STATUS_REVISION_MISMATCH,
            L"HalAcpiDispatchTable",
            KSWORD_ARK_PLATFORM_DETAIL_TABLE_INVALID,
            view.Signature,
            view.Version);
        return;
    }
    if (functionCount > RTL_NUMBER_OF(view.Functions) ||
        byteSize > sizeof(view) ||
        !KswordARKHookReadMemorySafe(tableAddress, &view, byteSize)) {
        if (KswPlatformAddExportedFunction(
                Response,
                Capacity,
                MaxRows,
                KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI,
                ModuleInfo,
                L"HalAcpiGetTableEx",
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL_ACPI)) {
            return;
        }
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_QUERY_FAILED,
            STATUS_PARTIAL_COPY,
            L"HalAcpiDispatchTable",
            KSWORD_ARK_PLATFORM_DETAIL_READ_FAILED,
            (ULONGLONG)(ULONG_PTR)tableAddress,
            byteSize);
        return;
    }
    if (!KswPlatformHalAcpiIdentityMatches(&view, NULL, NULL)) {
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_QUERY_FAILED,
            STATUS_REVISION_MISMATCH,
            L"HalAcpiDispatchTable",
            KSWORD_ARK_PLATFORM_DETAIL_TABLE_INVALID,
            view.Signature,
            view.Version);
        return;
    }

    for (index = 0UL; index < functionCount; ++index) {
        KSWORD_ARK_PLATFORM_AUDIT_ENTRY entry;
        ULONG ownerPolicy =
            (index == 5UL || index == 6UL || index == 8UL ||
             index >= KSW_PLATFORM_HAL_ACPI_V5_FUNCTION_COUNT) ?
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL_PCI :
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL_ACPI;
        ULONG signatureId =
            view.Version == KSW_PLATFORM_HAL_ACPI_VERSION_V4 ?
                KSWORD_ARK_PLATFORM_SIGNATURE_HAL_ACPI_V4 :
                KSWORD_ARK_PLATFORM_SIGNATURE_HAL_ACPI_V5;

        KswPlatformInitializeEntry(
            &entry,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI,
            KSWORD_ARK_PLATFORM_AUDIT_ROW_FUNCTION,
            signatureId,
            KSWORD_ARK_PLATFORM_SLOT_FUNCTION,
            ownerPolicy,
            index,
            tableAddress,
            g_KswHalAcpiFunctionNames[index]);
        entry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_STRUCTURE_VALIDATED |
            KSWORD_ARK_PLATFORM_FIELD_READ_ONLY_RANGE |
            KSWORD_ARK_PLATFORM_FIELD_LOCATOR_VALIDATED;
        if (view.Functions[index] == NULL) {
            entry.status = KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNAVAILABLE;
            KswPlatformSetDetail(
                &entry,
                KSWORD_ARK_PLATFORM_DETAIL_NULL_SLOT,
                index,
                BuildNumber,
                view.Version,
                0ULL);
        }
        else {
            entry.liveAddress = (ULONGLONG)(ULONG_PTR)view.Functions[index];
            entry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_LIVE_ADDRESS;
            KswPlatformClassifyFunction(&entry, ModuleInfo, ownerPolicy);
        }
        KswPlatformAppend(Response, Capacity, MaxRows, &entry);
    }
}

static VOID
KswPlatformAddHalSubcomponents(
    _Inout_ KSWORD_ARK_QUERY_PLATFORM_AUDIT_RESPONSE* Response,
    _In_ ULONG Capacity,
    _In_ ULONG MaxRows,
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ ULONG BuildNumber
    )
{
    const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR* locator =
        KswPlatformFindRipLocator(
            g_KswHalSubcomponentLocators,
            RTL_NUMBER_OF(g_KswHalSubcomponentLocators),
            BuildNumber);
    PVOID anchor = NULL;
    PVOID tableAddress = NULL;
    KSW_PLATFORM_HAL_SUBCOMPONENT
        entries[KSW_PLATFORM_HAL_SUBCOMPONENT_MAX_COUNT];
    NTSTATUS locateStatus = STATUS_NOT_SUPPORTED;
    ULONG entryCount = 0UL;
    ULONG index = 0UL;

    if (locator == NULL) {
        if (KswPlatformAddExportedFunction(
                Response,
                Capacity,
                MaxRows,
                KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_SUBCOMPONENTS,
                ModuleInfo,
                L"HalInitSystem",
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL)) {
            return;
        }
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_SUBCOMPONENTS,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNSUPPORTED,
            STATUS_NOT_SUPPORTED,
            L"HalSubComponents",
            KSWORD_ARK_PLATFORM_DETAIL_BUILD_UNSUPPORTED,
            BuildNumber,
            26100ULL);
        return;
    }
    entryCount = locator->ExpectedVersion;
    anchor = locator->AnchorName != NULL ?
        KswPlatformGetRoutine(locator->AnchorName) :
        NULL;
    locateStatus = KswPlatformLocateRipTable(
        ModuleInfo,
        anchor,
        locator,
        KswPlatformValidateHalSubcomponentCandidate,
        &tableAddress);
    if (!NT_SUCCESS(locateStatus)) {
        if (KswPlatformAddExportedFunction(
                Response,
                Capacity,
                MaxRows,
                KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_SUBCOMPONENTS,
                ModuleInfo,
                L"HalInitSystem",
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL)) {
            return;
        }
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_SUBCOMPONENTS,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNSUPPORTED,
            locateStatus,
            L"HalSubComponents",
            locateStatus == STATUS_OBJECT_NAME_COLLISION ?
                KSWORD_ARK_PLATFORM_DETAIL_LOCATOR_NOT_UNIQUE :
                KSWORD_ARK_PLATFORM_DETAIL_LOCATOR_NOT_FOUND,
            BuildNumber,
            (ULONGLONG)(ULONG_PTR)anchor);
        return;
    }

    RtlZeroMemory(entries, sizeof(entries));
    if (!KswordARKHookReadMemorySafe(
            tableAddress,
            entries,
            locator->TableByteSize)) {
        if (KswPlatformAddExportedFunction(
                Response,
                Capacity,
                MaxRows,
                KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_SUBCOMPONENTS,
                ModuleInfo,
                L"HalInitSystem",
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL)) {
            return;
        }
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_SUBCOMPONENTS,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_QUERY_FAILED,
            STATUS_PARTIAL_COPY,
            L"HalSubComponents",
            KSWORD_ARK_PLATFORM_DETAIL_READ_FAILED,
            (ULONGLONG)(ULONG_PTR)tableAddress,
            locator->TableByteSize);
        return;
    }
    if (!KswPlatformHalSubcomponentIdentityMatches(
            ModuleInfo,
            entries,
            entryCount)) {
        if (KswPlatformAddExportedFunction(
                Response,
                Capacity,
                MaxRows,
                KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_SUBCOMPONENTS,
                ModuleInfo,
                L"HalInitSystem",
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL)) {
            return;
        }
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_SUBCOMPONENTS,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_QUERY_FAILED,
            STATUS_REVISION_MISMATCH,
            L"HalSubComponents",
            KSWORD_ARK_PLATFORM_DETAIL_TABLE_INVALID,
            (ULONGLONG)(ULONG_PTR)tableAddress,
            entryCount);
        return;
    }

    for (index = 0UL; index < entryCount; ++index) {
        KSWORD_ARK_PLATFORM_AUDIT_ENTRY entry;
        ULONG nameIndex = 0UL;
        ULONG signatureId =
            entryCount == KSW_PLATFORM_HAL_SUBCOMPONENT_LEGACY_COUNT ?
                KSWORD_ARK_PLATFORM_SIGNATURE_HAL_SUBCOMPONENTS_21 :
                KSWORD_ARK_PLATFORM_SIGNATURE_HAL_SUBCOMPONENTS_22;

        if (!KswPlatformHalSubcomponentIndex(
                index,
                entryCount,
                &nameIndex)) {
            break;
        }
        KswPlatformInitializeEntry(
            &entry,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_SUBCOMPONENTS,
            KSWORD_ARK_PLATFORM_AUDIT_ROW_FUNCTION,
            signatureId,
            KSWORD_ARK_PLATFORM_SLOT_FUNCTION,
            KSWORD_ARK_PLATFORM_OWNER_NT_HAL,
            index,
            tableAddress,
            g_KswHalSubcomponentFunctionNames[nameIndex]);
        entry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_STRUCTURE_VALIDATED |
            KSWORD_ARK_PLATFORM_FIELD_READ_ONLY_RANGE |
            KSWORD_ARK_PLATFORM_FIELD_LOCATOR_VALIDATED;
        if (entries[index].Function == NULL) {
            entry.status = KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNAVAILABLE;
            KswPlatformSetDetail(
                &entry,
                KSWORD_ARK_PLATFORM_DETAIL_NULL_SLOT,
                index,
                BuildNumber,
                entryCount,
                0ULL);
        }
        else {
            entry.liveAddress =
                (ULONGLONG)(ULONG_PTR)entries[index].Function;
            entry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_LIVE_ADDRESS;
            KswPlatformClassifyFunction(
                &entry,
                ModuleInfo,
                KSWORD_ARK_PLATFORM_OWNER_NT_HAL);
        }
        KswPlatformAppend(Response, Capacity, MaxRows, &entry);
    }
}

static VOID
KswPlatformAddWdfFunctions(
    _Inout_ KSWORD_ARK_QUERY_PLATFORM_AUDIT_RESPONSE* Response,
    _In_ ULONG Capacity,
    _In_ ULONG MaxRows,
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo
    )
{
    const WDFFUNC* functionTable = WdfFunctions;
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* tableOwner = NULL;
    ULONG index = 0UL;
    ULONG functionCount = (ULONG)WdfFunctionTableNumEntries;

    if (functionTable == NULL ||
        functionCount == 0UL ||
        functionCount > KSWORD_ARK_PLATFORM_HARD_MAX_ROWS) {
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_WDF_FUNCTIONS,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNSUPPORTED,
            STATUS_NOT_SUPPORTED,
            L"WdfFunctions",
            KSWORD_ARK_PLATFORM_DETAIL_WDF_TABLE_INVALID,
            functionCount,
            0ULL);
        return;
    }
    tableOwner = KswordARKHookFindModuleForAddress(ModuleInfo, (ULONG_PTR)functionTable);
    if (!KswPlatformModuleNameEquals(tableOwner, "Wdf01000.sys") ||
        !KswPlatformRangeInSection(
            tableOwner,
            (ULONG_PTR)functionTable,
            (SIZE_T)functionCount * sizeof(WDFFUNC),
            FALSE,
            FALSE)) {
        KswPlatformAddDiagnostic(
            Response, Capacity, MaxRows,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_WDF_FUNCTIONS,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_SIGNATURE_MISMATCH,
            STATUS_DATA_ERROR,
            L"WdfFunctions",
            KSWORD_ARK_PLATFORM_DETAIL_WDF_TABLE_INVALID,
            (ULONGLONG)(ULONG_PTR)functionTable,
            functionCount);
        return;
    }

    for (index = 0UL; index < functionCount; ++index) {
        KSWORD_ARK_PLATFORM_AUDIT_ENTRY entry;
        WDFFUNC functionAddress = NULL;
        WCHAR fallbackName[KSWORD_ARK_PLATFORM_NAME_CHARS];
        PCWSTR functionName =
            index < RTL_NUMBER_OF(g_KswWdfFunctionNames)
            ? g_KswWdfFunctionNames[index]
            : NULL;
        RtlZeroMemory(fallbackName, sizeof(fallbackName));
        if (functionName == NULL) {
            (VOID)RtlStringCchPrintfW(
                fallbackName,
                RTL_NUMBER_OF(fallbackName),
                L"WdfFunctions[%lu]",
                index);
            functionName = fallbackName;
        }

        KswPlatformInitializeEntry(
            &entry,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_WDF_FUNCTIONS,
            KSWORD_ARK_PLATFORM_AUDIT_ROW_FUNCTION,
            KSWORD_ARK_PLATFORM_SIGNATURE_WDF_BINDING_TABLE,
            KSWORD_ARK_PLATFORM_SLOT_FUNCTION,
            KSWORD_ARK_PLATFORM_OWNER_WDF,
            index,
            (PVOID)functionTable,
            functionName);
        entry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_STRUCTURE_VALIDATED;

        if (!KswordARKHookReadMemorySafe(
                &functionTable[index],
                &functionAddress,
                sizeof(functionAddress))) {
            entry.status = KSWORD_ARK_PLATFORM_AUDIT_STATUS_QUERY_FAILED;
            entry.lastStatus = STATUS_PARTIAL_COPY;
            KswPlatformSetDetail(
                &entry,
                KSWORD_ARK_PLATFORM_DETAIL_READ_FAILED,
                index,
                functionCount,
                0ULL,
                0ULL);
            KswPlatformAppend(Response, Capacity, MaxRows, &entry);
            continue;
        }
        if (functionAddress == NULL) {
            entry.status = KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNAVAILABLE;
            KswPlatformSetDetail(
                &entry,
                KSWORD_ARK_PLATFORM_DETAIL_NULL_SLOT,
                index,
                functionCount,
                0ULL,
                0ULL);
            KswPlatformAppend(Response, Capacity, MaxRows, &entry);
            continue;
        }
        entry.liveAddress = (ULONGLONG)(ULONG_PTR)functionAddress;
        entry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_LIVE_ADDRESS;
        KswPlatformClassifyFunction(
            &entry,
            ModuleInfo,
            KSWORD_ARK_PLATFORM_OWNER_WDF);
        KswPlatformAppend(Response, Capacity, MaxRows, &entry);
    }
}

static VOID
KswPlatformAddWdfCallbacks(
    _Inout_ KSWORD_ARK_QUERY_PLATFORM_AUDIT_RESPONSE* Response,
    _In_ ULONG Capacity,
    _In_ ULONG MaxRows,
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo
    )
{
    ULONG index = 0UL;

    for (index = 0UL; index < RTL_NUMBER_OF(g_KswWdfCallbacks); ++index) {
        KSWORD_ARK_PLATFORM_AUDIT_ENTRY entry;

        KswPlatformInitializeEntry(
            &entry,
            KSWORD_ARK_PLATFORM_AUDIT_SCOPE_WDF_CALLBACKS,
            KSWORD_ARK_PLATFORM_AUDIT_ROW_CALLBACK,
            KSWORD_ARK_PLATFORM_SIGNATURE_X64_PROLOGUE,
            KSWORD_ARK_PLATFORM_SLOT_FUNCTION,
            KSWORD_ARK_PLATFORM_OWNER_KSWORD,
            index,
            NULL,
            g_KswWdfCallbacks[index].Name);
        entry.liveAddress = (ULONGLONG)(ULONG_PTR)g_KswWdfCallbacks[index].Address;
        entry.fieldFlags |= KSWORD_ARK_PLATFORM_FIELD_LIVE_ADDRESS;
        KswPlatformClassifyFunction(
            &entry,
            ModuleInfo,
            KSWORD_ARK_PLATFORM_OWNER_KSWORD);
        KswPlatformAppend(Response, Capacity, MaxRows, &entry);
    }
}

static VOID
KswordARKPlatformAuditLog(
    _In_ WDFDEVICE Device,
    _In_z_ PCSTR LevelText,
    _In_z_ PCSTR FormatText,
    ...
    )
/*++

Routine Description:

    Format and enqueue one platform-audit log line.

Arguments:

    Device - WDF device owning the log channel.
    LevelText - Log level string.
    FormatText - printf-style ANSI template.
    ... - Template arguments.

Return Value:

    None.  Formatting or enqueue failures are ignored; diagnostics must never
    change the outcome of the request they describe.

--*/
{
    CHAR logMessage[KSWORD_ARK_LOG_ENTRY_MAX_BYTES] = { 0 };
    va_list arguments;

    va_start(arguments, FormatText);
    if (NT_SUCCESS(RtlStringCbVPrintfA(logMessage, sizeof(logMessage), FormatText, arguments))) {
        (VOID)KswordARKDriverEnqueueLogFrame(Device, LevelText, logMessage);
    }
    va_end(arguments);
}

static BOOLEAN
KswordARKPlatformAuditRequestIsValid(
    _In_ WDFDEVICE Device,
    _In_ const KSWORD_ARK_QUERY_PLATFORM_AUDIT_REQUEST* RequestPacket,
    _In_ BOOLEAN CallerSuppliedInput
    )
/*++

Routine Description:

    Validate the request packet, naming the field that failed.  The dispatch
    layer only reports STATUS_INVALID_PARAMETER, which cannot distinguish a
    protocol-version mismatch from a malformed packet; a user-mode binary built
    against a different version of the shared header is by far the most common
    cause and used to require reading the source to diagnose.

Arguments:

    Device - WDF device owning the log channel.
    RequestPacket - Caller packet, or the driver's default packet.
    CallerSuppliedInput - FALSE when the defaults are in use, so a rejection
        would indicate a driver-side defect rather than a caller mismatch.

Return Value:

    TRUE when every field is acceptable.

--*/
{
    if (RequestPacket == NULL) {
        return FALSE;
    }
    if (RequestPacket->size != sizeof(*RequestPacket)) {
        KswordARKPlatformAuditLog(
            Device,
            "Warn",
            "Platform audit request rejected: size=%lu, expected=%lu, caller_supplied=%u.",
            (unsigned long)RequestPacket->size,
            (unsigned long)sizeof(*RequestPacket),
            (unsigned)CallerSuppliedInput);
        return FALSE;
    }
    if (RequestPacket->version != KSWORD_ARK_PLATFORM_AUDIT_PROTOCOL_VERSION) {
        KswordARKPlatformAuditLog(
            Device,
            "Warn",
            "Platform audit protocol mismatch: request_version=%lu, driver_version=%lu, "
            "caller_supplied=%u. User-mode and driver binaries are from different builds.",
            (unsigned long)RequestPacket->version,
            (unsigned long)KSWORD_ARK_PLATFORM_AUDIT_PROTOCOL_VERSION,
            (unsigned)CallerSuppliedInput);
        return FALSE;
    }
    if (RequestPacket->flags != 0UL || RequestPacket->reserved0 != 0UL) {
        KswordARKPlatformAuditLog(
            Device,
            "Warn",
            "Platform audit request rejected: flags=0x%08lX, reserved0=0x%08lX, both must be zero.",
            (unsigned long)RequestPacket->flags,
            (unsigned long)RequestPacket->reserved0);
        return FALSE;
    }
    if ((RequestPacket->scopeMask & ~KSWORD_ARK_PLATFORM_AUDIT_SCOPE_ALL) != 0UL) {
        KswordARKPlatformAuditLog(
            Device,
            "Warn",
            "Platform audit request rejected: scopeMask=0x%08lX carries bits outside 0x%08lX.",
            (unsigned long)RequestPacket->scopeMask,
            (unsigned long)KSWORD_ARK_PLATFORM_AUDIT_SCOPE_ALL);
        return FALSE;
    }
    return TRUE;
}

NTSTATUS
KswordARKPlatformAuditIoctlQuery(
    _In_ WDFDEVICE Device,
    _In_ WDFREQUEST Request,
    _In_ size_t InputBufferLength,
    _In_ size_t OutputBufferLength,
    _Out_ size_t* BytesReturned
    )
{
    KSWORD_ARK_QUERY_PLATFORM_AUDIT_REQUEST defaultRequest;
    const KSWORD_ARK_QUERY_PLATFORM_AUDIT_REQUEST* requestPacket = NULL;
    KSWORD_ARK_QUERY_PLATFORM_AUDIT_RESPONSE* response = NULL;
    KSW_HOOK_SYSTEM_MODULE_INFORMATION* moduleInfo = NULL;
    PVOID inputBuffer = NULL;
    PVOID outputBuffer = NULL;
    size_t actualInputBytes = 0U;
    size_t actualOutputBytes = 0U;
    ULONG moduleInfoBytes = 0UL;
    ULONG capacity = 0UL;
    ULONG maxRows = KSWORD_ARK_PLATFORM_DEFAULT_MAX_ROWS;
    ULONG scopeMask = KSWORD_ARK_PLATFORM_AUDIT_SCOPE_ALL;
    ULONG majorVersion = 0UL;
    ULONG minorVersion = 0UL;
    ULONG buildNumber = 0UL;
    BOOLEAN hasInput = FALSE;
    NTSTATUS status = STATUS_SUCCESS;

    UNREFERENCED_PARAMETER(OutputBufferLength);

    if (BytesReturned == NULL) {
        return STATUS_INVALID_PARAMETER;
    }
    *BytesReturned = 0U;
    RtlZeroMemory(&defaultRequest, sizeof(defaultRequest));
    defaultRequest.size = sizeof(defaultRequest);
    defaultRequest.version = KSWORD_ARK_PLATFORM_AUDIT_PROTOCOL_VERSION;
    defaultRequest.scopeMask = KSWORD_ARK_PLATFORM_AUDIT_SCOPE_ALL;
    defaultRequest.maxRows = KSWORD_ARK_PLATFORM_DEFAULT_MAX_ROWS;

    status = KswordARKRetrieveOptionalInputBuffer(
        Request,
        InputBufferLength,
        sizeof(KSWORD_ARK_QUERY_PLATFORM_AUDIT_REQUEST),
        &inputBuffer,
        &actualInputBytes,
        &hasInput);
    if (!NT_SUCCESS(status)) {
        return status;
    }
    UNREFERENCED_PARAMETER(actualInputBytes);
    requestPacket = hasInput ?
        (const KSWORD_ARK_QUERY_PLATFORM_AUDIT_REQUEST*)inputBuffer :
        &defaultRequest;
    if (!KswordARKPlatformAuditRequestIsValid(Device, requestPacket, hasInput)) {
        return STATUS_INVALID_PARAMETER;
    }
    scopeMask = requestPacket->scopeMask == 0UL ?
        KSWORD_ARK_PLATFORM_AUDIT_SCOPE_ALL :
        requestPacket->scopeMask;
    maxRows = requestPacket->maxRows == 0UL ?
        KSWORD_ARK_PLATFORM_DEFAULT_MAX_ROWS :
        requestPacket->maxRows;
    if (maxRows > KSWORD_ARK_PLATFORM_HARD_MAX_ROWS) {
        maxRows = KSWORD_ARK_PLATFORM_HARD_MAX_ROWS;
    }

    status = KswordARKRetrieveRequiredOutputBuffer(
        Request,
        KSW_PLATFORM_RESPONSE_HEADER_SIZE,
        &outputBuffer,
        &actualOutputBytes);
    if (!NT_SUCCESS(status)) {
        return status;
    }
    RtlZeroMemory(outputBuffer, actualOutputBytes);
    response = (KSWORD_ARK_QUERY_PLATFORM_AUDIT_RESPONSE*)outputBuffer;
    response->size = KSW_PLATFORM_RESPONSE_HEADER_SIZE;
    response->version = KSWORD_ARK_PLATFORM_AUDIT_PROTOCOL_VERSION;
    response->queryStatus = KSWORD_ARK_PLATFORM_AUDIT_STATUS_OK;
    response->scopeMask = scopeMask;
    response->responseFlags = KSWORD_ARK_PLATFORM_RESPONSE_NO_PDB;
    response->entrySize = sizeof(KSWORD_ARK_PLATFORM_AUDIT_ENTRY);
    response->signaturePolicyFlags =
        KSWORD_ARK_PLATFORM_FIELD_EXACT_EXPORT |
        KSWORD_ARK_PLATFORM_FIELD_STRUCTURE_VALIDATED |
        KSWORD_ARK_PLATFORM_FIELD_OWNER_VALIDATED |
        KSWORD_ARK_PLATFORM_FIELD_PROLOGUE_FORMAT |
        KSWORD_ARK_PLATFORM_FIELD_LOCATOR_VALIDATED;
    response->lastStatus = STATUS_SUCCESS;
    capacity = KswPlatformOutputCapacity(actualOutputBytes);
    (VOID)PsGetVersion(&majorVersion, &minorVersion, &buildNumber, NULL);
    UNREFERENCED_PARAMETER(majorVersion);
    UNREFERENCED_PARAMETER(minorVersion);
    response->buildNumber = buildNumber;

    status = KswordARKHookBuildModuleSnapshot(&moduleInfo, &moduleInfoBytes);
    if (!NT_SUCCESS(status) || moduleInfo == NULL || moduleInfoBytes == 0UL) {
        if (NT_SUCCESS(status)) {
            status = STATUS_UNSUCCESSFUL;
        }
        KswPlatformAddDiagnostic(
            response, capacity, maxRows, scopeMask,
            KSWORD_ARK_PLATFORM_AUDIT_STATUS_QUERY_FAILED,
            status,
            L"LoadedModuleSnapshot",
            KSWORD_ARK_PLATFORM_DETAIL_MODULE_SNAPSHOT_FAILED,
            moduleInfoBytes,
            0ULL);
        if (moduleInfo != NULL) {
            ExFreePoolWithTag(moduleInfo, KSW_HOOK_SCAN_TAG);
            moduleInfo = NULL;
        }
        *BytesReturned = KSW_PLATFORM_RESPONSE_HEADER_SIZE +
            ((size_t)response->returnedCount * sizeof(KSWORD_ARK_PLATFORM_AUDIT_ENTRY));
        return STATUS_SUCCESS;
    }

    if ((scopeMask & KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_DISPATCH) != 0UL) {
        KswPlatformAddHalDispatch(response, capacity, maxRows, moduleInfo);
    }
    if ((scopeMask & KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_PRIVATE) != 0UL) {
        KswPlatformAddHalPrivate(
            response, capacity, maxRows, moduleInfo, buildNumber);
    }
    if ((scopeMask & KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI) != 0UL) {
        KswPlatformAddHalAcpi(
            response, capacity, maxRows, moduleInfo, buildNumber);
    }
    if ((scopeMask & KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_SUBCOMPONENTS) != 0UL) {
        KswPlatformAddHalSubcomponents(
            response, capacity, maxRows, moduleInfo, buildNumber);
    }
    if ((scopeMask & KSWORD_ARK_PLATFORM_AUDIT_SCOPE_WDF_FUNCTIONS) != 0UL) {
        KswPlatformAddWdfFunctions(response, capacity, maxRows, moduleInfo);
    }
    if ((scopeMask & KSWORD_ARK_PLATFORM_AUDIT_SCOPE_WDF_CALLBACKS) != 0UL) {
        KswPlatformAddWdfCallbacks(response, capacity, maxRows, moduleInfo);
    }

    ExFreePoolWithTag(moduleInfo, KSW_HOOK_SCAN_TAG);
    if ((response->responseFlags & KSWORD_ARK_PLATFORM_RESPONSE_TRUNCATED) != 0UL) {
        response->queryStatus = KSWORD_ARK_PLATFORM_AUDIT_STATUS_BUFFER_TRUNCATED;
    }
    *BytesReturned = KSW_PLATFORM_RESPONSE_HEADER_SIZE +
        ((size_t)response->returnedCount * sizeof(KSWORD_ARK_PLATFORM_AUDIT_ENTRY));
    return STATUS_SUCCESS;
}

typedef struct _KSW_PLATFORM_EDIT_SLOT
{
    PVOID TableAddress;
    PVOID volatile* SlotAddress;
    PVOID CurrentValue;
    // 槽位所在节没有 IMAGE_SCN_MEM_WRITE 时置位；KMDF 绑定表就是这种情况。
    BOOLEAN RequiresWritableAlias;
} KSW_PLATFORM_EDIT_SLOT;

#define KSW_PLATFORM_EDIT_RECORD_LIMIT 64UL

typedef struct _KSW_PLATFORM_EDIT_RECORD
{
    BOOLEAN InUse;
    BOOLEAN RequiresWritableAlias;
    ULONG Scope;
    ULONG EntryIndex;
    PVOID TableAddress;
    PVOID volatile* SlotAddress;
    PVOID OriginalValue;
    PVOID AppliedValue;
} KSW_PLATFORM_EDIT_RECORD;

typedef struct _KSW_PLATFORM_EDIT_STATE
{
    // 用 ERESOURCE 而不是 FAST_MUTEX：只读节槽位要在锁内调用
    // MmProtectMdlSystemAddress 建立可写别名，而该例程只允许 PASSIVE_LEVEL，
    // FAST_MUTEX 会把 IRQL 提到 APC_LEVEL。
    ERESOURCE Lock;
    volatile LONG Initialized;
    KSW_PLATFORM_EDIT_RECORD Records[KSW_PLATFORM_EDIT_RECORD_LIMIT];
} KSW_PLATFORM_EDIT_STATE;

static KSW_PLATFORM_EDIT_STATE g_KswPlatformEditState;

static NTSTATUS
KswPlatformExchangeSlotPointer(
    _In_ PVOID volatile* SlotAddress,
    _In_ BOOLEAN RequiresWritableAlias,
    _In_opt_ PVOID ExpectedValue,
    _In_opt_ PVOID NewValue,
    _Out_ PVOID* PreviousValueOut
    )
/*++

Routine Description:

    对单个函数指针槽做一次原子 CAS。槽位落在只读映像节时（KMDF 绑定表即如
    此），先用 MDL 建立可写系统别名再在别名上 CAS：别名与原地址映射同一物理
    页，lock cmpxchg 对物理内存原子，与其它 CPU 经原地址的访问依然互斥。
    直接写只读映像页会触发 ATTEMPTED_WRITE_TO_READONLY_MEMORY，__except 拦不
    住，所以这条判据必须在调用前定好。

Arguments:

    SlotAddress - 指针宽度且不跨页的槽位地址。
    RequiresWritableAlias - 槽位所在节缺少 IMAGE_SCN_MEM_WRITE 时为 TRUE。
    ExpectedValue - CAS 比较值。
    NewValue - CAS 写入值。
    PreviousValueOut - 回写 CAS 读到的原值；CAS 未发生时为 ExpectedValue。

Return Value:

    STATUS_SUCCESS 表示 CAS 已执行（是否换值由调用方比对 PreviousValueOut）。
    HVCI 下 MmProtectMdlSystemAddress 会拒绝提权，此时返回其 NTSTATUS。

--*/
{
    PMDL mdl = NULL;
    PVOID mappedAddress = NULL;
    PVOID volatile* aliasSlot = NULL;
    BOOLEAN pagesLocked = FALSE;
    NTSTATUS status = STATUS_SUCCESS;

    if (SlotAddress == NULL || PreviousValueOut == NULL) {
        return STATUS_INVALID_PARAMETER;
    }
    *PreviousValueOut = ExpectedValue;
    if (KeGetCurrentIrql() != PASSIVE_LEVEL) {
        return STATUS_INVALID_DEVICE_STATE;
    }

    if (!RequiresWritableAlias) {
        __try {
            *PreviousValueOut = InterlockedCompareExchangePointer(
                SlotAddress,
                NewValue,
                ExpectedValue);
            KeMemoryBarrier();
        }
        __except (EXCEPTION_EXECUTE_HANDLER) {
            *PreviousValueOut = ExpectedValue;
            status = GetExceptionCode();
        }
        return status;
    }

    __try {
        mdl = IoAllocateMdl(
            (PVOID)SlotAddress,
            (ULONG)sizeof(PVOID),
            FALSE,
            FALSE,
            NULL);
        if (mdl == NULL) {
            status = STATUS_INSUFFICIENT_RESOURCES;
            __leave;
        }
        // 只读映像页用 IoModifyAccess 探测会直接抛异常，必须按只读锁定后再
        // 单独提权临时别名，原映射的保护属性始终不动。
        MmProbeAndLockPages(mdl, KernelMode, IoReadAccess);
        pagesLocked = TRUE;
        mappedAddress = MmMapLockedPagesSpecifyCache(
            mdl,
            KernelMode,
            MmCached,
            NULL,
            FALSE,
            NormalPagePriority | MdlMappingNoExecute);
        if (mappedAddress == NULL) {
            status = STATUS_INSUFFICIENT_RESOURCES;
            __leave;
        }
        status = MmProtectMdlSystemAddress(mdl, PAGE_READWRITE);
        if (!NT_SUCCESS(status)) {
            __leave;
        }
        aliasSlot = (PVOID volatile*)mappedAddress;
        *PreviousValueOut = InterlockedCompareExchangePointer(
            aliasSlot,
            NewValue,
            ExpectedValue);
        KeMemoryBarrier();
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        *PreviousValueOut = ExpectedValue;
        status = GetExceptionCode();
    }

    if (mappedAddress != NULL) {
        MmUnmapLockedPages(mappedAddress, mdl);
    }
    if (mdl != NULL) {
        if (pagesLocked) {
            MmUnlockPages(mdl);
        }
        IoFreeMdl(mdl);
    }
    return status;
}

VOID
KswordARKPlatformAuditInitialize(
    VOID
    )
{
    RtlZeroMemory(
        &g_KswPlatformEditState,
        sizeof(g_KswPlatformEditState));
    if (!NT_SUCCESS(ExInitializeResourceLite(&g_KswPlatformEditState.Lock))) {
        // 锁不可用时编辑入口保持关闭，查询路径不受影响。
        return;
    }
    InterlockedExchange(&g_KswPlatformEditState.Initialized, 1L);
}

VOID
KswordARKPlatformAuditUninitialize(
    VOID
    )
{
    ULONG index = 0UL;

    if (InterlockedCompareExchange(
            &g_KswPlatformEditState.Initialized,
            0L,
            0L) == 0L ||
        KeGetCurrentIrql() != PASSIVE_LEVEL) {
        return;
    }

    KeEnterCriticalRegion();
    (VOID)ExAcquireResourceExclusiveLite(&g_KswPlatformEditState.Lock, TRUE);
    // 在锁内翻转标志：任何已经排在锁上的提交都会在拿到锁后看到 0 并立即退出，
    // 不会在恢复完成之后又写回一个已经作废的值。
    InterlockedExchange(&g_KswPlatformEditState.Initialized, 0L);
    for (index = 0UL; index < KSW_PLATFORM_EDIT_RECORD_LIMIT; ++index) {
        KSW_PLATFORM_EDIT_RECORD* record =
            &g_KswPlatformEditState.Records[index];
        PVOID previousValue = NULL;
        if (!record->InUse || record->SlotAddress == NULL) {
            continue;
        }
        // 卸载恢复只覆盖本功能最后发布值；不可访问、别名提权被拒或第三方
        // 值都保持原样，因此这里忽略返回状态。
        (VOID)KswPlatformExchangeSlotPointer(
            record->SlotAddress,
            record->RequiresWritableAlias,
            record->AppliedValue,
            record->OriginalValue,
            &previousValue);
        RtlZeroMemory(record, sizeof(*record));
    }
    ExReleaseResourceLite(&g_KswPlatformEditState.Lock);
    KeLeaveCriticalRegion();
    ExDeleteResourceLite(&g_KswPlatformEditState.Lock);
    RtlZeroMemory(
        &g_KswPlatformEditState,
        sizeof(g_KswPlatformEditState));
}

static NTSTATUS
KswPlatformCommitEdit(
    _In_ ULONG Scope,
    _In_ ULONG EntryIndex,
    _In_ const KSW_PLATFORM_EDIT_SLOT* Slot,
    _In_ PVOID ExpectedValue,
    _In_ PVOID NewValue,
    _Out_ PVOID* PreviousValueOut
    )
{
    KSW_PLATFORM_EDIT_RECORD* record = NULL;
    KSW_PLATFORM_EDIT_RECORD* freeRecord = NULL;
    PVOID previousValue = NULL;
    ULONG index = 0UL;
    NTSTATUS status = STATUS_SUCCESS;

    if (Slot == NULL || Slot->TableAddress == NULL ||
        Slot->SlotAddress == NULL || NewValue == NULL ||
        PreviousValueOut == NULL) {
        return STATUS_INVALID_PARAMETER;
    }
    *PreviousValueOut = NULL;
    if (InterlockedCompareExchange(
            &g_KswPlatformEditState.Initialized,
            0L,
            0L) == 0L) {
        return STATUS_DEVICE_NOT_READY;
    }

    if (KeGetCurrentIrql() != PASSIVE_LEVEL) {
        return STATUS_INVALID_DEVICE_STATE;
    }

    KeEnterCriticalRegion();
    (VOID)ExAcquireResourceExclusiveLite(&g_KswPlatformEditState.Lock, TRUE);
    // 卸载会在锁内把标志翻成 0；排在锁上的提交必须复查，否则会在恢复之后再写。
    if (InterlockedCompareExchange(
            &g_KswPlatformEditState.Initialized,
            0L,
            0L) == 0L) {
        status = STATUS_DEVICE_NOT_READY;
        goto Exit;
    }
    for (index = 0UL; index < KSW_PLATFORM_EDIT_RECORD_LIMIT; ++index) {
        KSW_PLATFORM_EDIT_RECORD* candidate =
            &g_KswPlatformEditState.Records[index];
        if (!candidate->InUse) {
            if (freeRecord == NULL) {
                freeRecord = candidate;
            }
            continue;
        }
        if (candidate->Scope == Scope &&
            candidate->EntryIndex == EntryIndex &&
            candidate->TableAddress == Slot->TableAddress) {
            record = candidate;
            break;
        }
        // 同一物理槽不能以另一组逻辑身份建立第二条恢复记录，否则卸载时
        // 两条 CAS 的原值链可能互相遮蔽，最终残留中间值。
        if (candidate->SlotAddress == Slot->SlotAddress) {
            status = STATUS_CONFLICTING_ADDRESSES;
            goto Exit;
        }
    }
    if (record != NULL &&
        (record->SlotAddress != Slot->SlotAddress ||
         record->AppliedValue != ExpectedValue)) {
        status = STATUS_CONFLICTING_ADDRESSES;
        goto Exit;
    }
    if (record == NULL && freeRecord == NULL) {
        status = STATUS_INSUFFICIENT_RESOURCES;
        goto Exit;
    }

    status = KswPlatformExchangeSlotPointer(
        Slot->SlotAddress,
        Slot->RequiresWritableAlias,
        ExpectedValue,
        NewValue,
        &previousValue);
    *PreviousValueOut = previousValue;
    if (!NT_SUCCESS(status) || previousValue != ExpectedValue) {
        if (NT_SUCCESS(status)) {
            status = STATUS_REVISION_MISMATCH;
        }
        goto Exit;
    }

    if (record == NULL) {
        record = freeRecord;
        RtlZeroMemory(record, sizeof(*record));
        record->InUse = TRUE;
        record->RequiresWritableAlias = Slot->RequiresWritableAlias;
        record->Scope = Scope;
        record->EntryIndex = EntryIndex;
        record->TableAddress = Slot->TableAddress;
        record->SlotAddress = Slot->SlotAddress;
        record->OriginalValue = ExpectedValue;
    }
    record->AppliedValue = NewValue;
    if (record->AppliedValue == record->OriginalValue) {
        RtlZeroMemory(record, sizeof(*record));
    }

Exit:
    ExReleaseResourceLite(&g_KswPlatformEditState.Lock);
    KeLeaveCriticalRegion();
    return status;
}

static NTSTATUS
KswPlatformResolveHalDispatchEditSlot(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ ULONG EntryIndex,
    _Out_ KSW_PLATFORM_EDIT_SLOT* SlotOut
    )
{
    PVOID tableAddress = KswPlatformGetRoutine(L"HalDispatchTable");
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* tableOwner = NULL;
    const KSW_PLATFORM_SLOT_DESCRIPTOR* descriptor = NULL;
    ULONG version = 0UL;
    ULONG slotCount = 0UL;
    ULONG tableBytes = 0UL;

    if (ModuleInfo == NULL || SlotOut == NULL || tableAddress == NULL) {
        return STATUS_PROCEDURE_NOT_FOUND;
    }
    tableOwner = KswordARKHookFindModuleForAddress(
        ModuleInfo,
        (ULONG_PTR)tableAddress);
    if (!KswPlatformIsExpectedHalOwner(tableOwner) ||
        !KswPlatformRangeInSection(
            tableOwner,
            (ULONG_PTR)tableAddress,
            sizeof(version),
            FALSE,
            FALSE) ||
        !KswordARKHookReadMemorySafe(
            tableAddress,
            &version,
            sizeof(version))) {
        return STATUS_DATA_ERROR;
    }
    slotCount = KswPlatformHalDispatchSlotCount(version);
    if (slotCount == 0UL || EntryIndex >= slotCount) {
        return STATUS_REVISION_MISMATCH;
    }
    tableBytes = g_KswHalDispatchSlots[slotCount - 1UL].Offset +
        g_KswHalDispatchSlots[slotCount - 1UL].Width;
    if (!KswPlatformRangeInSection(
            tableOwner,
            (ULONG_PTR)tableAddress,
            tableBytes,
            FALSE,
            FALSE)) {
        return STATUS_DATA_ERROR;
    }
    descriptor = &g_KswHalDispatchSlots[EntryIndex];
    if (descriptor->SlotKind != KSWORD_ARK_PLATFORM_SLOT_FUNCTION ||
        descriptor->Width != sizeof(PVOID)) {
        return STATUS_OBJECT_TYPE_MISMATCH;
    }

    SlotOut->TableAddress = tableAddress;
    SlotOut->SlotAddress = (PVOID volatile*)(
        (UCHAR*)tableAddress + descriptor->Offset);
    if (!KswordARKHookReadMemorySafe(
            (const VOID*)SlotOut->SlotAddress,
            &SlotOut->CurrentValue,
            sizeof(SlotOut->CurrentValue))) {
        RtlZeroMemory(SlotOut, sizeof(*SlotOut));
        return STATUS_PARTIAL_COPY;
    }
    return STATUS_SUCCESS;
}

static NTSTATUS
KswPlatformResolveHalPrivateEditSlot(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ ULONG BuildNumber,
    _In_ ULONG EntryIndex,
    _Out_ KSW_PLATFORM_EDIT_SLOT* SlotOut
    )
{
    const KSW_PLATFORM_PRIVATE_BUILD_DESCRIPTOR* build =
        KswPlatformFindPrivateBuild(BuildNumber);
    const KSW_PLATFORM_SLOT_DESCRIPTOR* descriptor = NULL;
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* tableOwner = NULL;
    PVOID tableAddress = KswPlatformGetRoutine(L"HalPrivateDispatchTable");
    ULONG version = 0UL;
    NTSTATUS status = STATUS_NOT_SUPPORTED;

    if (ModuleInfo == NULL || SlotOut == NULL || EntryIndex == 0UL) {
        return STATUS_INVALID_PARAMETER;
    }

    tableOwner = KswordARKHookFindModuleForAddress(
        ModuleInfo,
        (ULONG_PTR)tableAddress);
    if (tableAddress != NULL &&
        KswPlatformIsExpectedHalOwner(tableOwner) &&
        KswPlatformRangeInSection(
            tableOwner,
            (ULONG_PTR)tableAddress,
            sizeof(version),
            FALSE,
            FALSE) &&
        KswordARKHookReadMemorySafe(
            tableAddress,
            &version,
            sizeof(version))) {
        const KSW_PLATFORM_PRIVATE_BUILD_DESCRIPTOR* versionBuild =
            KswPlatformFindPrivateVersion(version);
        if (versionBuild == NULL) {
            return STATUS_REVISION_MISMATCH;
        }
        if (!KswPlatformRangeInSection(
                tableOwner,
                (ULONG_PTR)tableAddress,
                versionBuild->ByteSize,
                FALSE,
                FALSE)) {
            return STATUS_DATA_ERROR;
        }
        build = versionBuild;
        status = STATUS_SUCCESS;
    }
    else if (build != NULL) {
        status = KswPlatformLocateHalPrivateBySignature(
            ModuleInfo,
            BuildNumber,
            build,
            &tableAddress,
            &version);
    }
    if (!NT_SUCCESS(status) || build == NULL || version != build->Version) {
        return NT_SUCCESS(status) ? STATUS_REVISION_MISMATCH : status;
    }
    if (EntryIndex - 1UL >= RTL_NUMBER_OF(g_KswHalPrivateSlots)) {
        return STATUS_INVALID_PARAMETER;
    }
    descriptor = &g_KswHalPrivateSlots[EntryIndex - 1UL];
    if (descriptor->Offset + descriptor->Width > build->ByteSize ||
        descriptor->SlotKind != KSWORD_ARK_PLATFORM_SLOT_FUNCTION ||
        descriptor->Width != sizeof(PVOID)) {
        return STATUS_OBJECT_TYPE_MISMATCH;
    }

    SlotOut->TableAddress = tableAddress;
    SlotOut->SlotAddress = (PVOID volatile*)(
        (UCHAR*)tableAddress + descriptor->Offset);
    if (!KswordARKHookReadMemorySafe(
            (const VOID*)SlotOut->SlotAddress,
            &SlotOut->CurrentValue,
            sizeof(SlotOut->CurrentValue))) {
        RtlZeroMemory(SlotOut, sizeof(*SlotOut));
        return STATUS_PARTIAL_COPY;
    }
    return STATUS_SUCCESS;
}

static NTSTATUS
KswPlatformResolveHalAcpiEditSlot(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ ULONG BuildNumber,
    _In_ ULONG EntryIndex,
    _Out_ KSW_PLATFORM_EDIT_SLOT* SlotOut
    )
{
    const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR* locator =
        KswPlatformFindRipLocator(
            g_KswHalAcpiLocators,
            RTL_NUMBER_OF(g_KswHalAcpiLocators),
            BuildNumber);
    KSW_PLATFORM_HAL_ACPI_VIEW view;
    PVOID anchor = NULL;
    PVOID tableAddress = NULL;
    ULONG functionCount = 0UL;
    ULONG byteSize = 0UL;
    NTSTATUS status = STATUS_NOT_SUPPORTED;

    if (ModuleInfo == NULL || SlotOut == NULL || locator == NULL ||
        !KswPlatformGetHalPowerAnchor(ModuleInfo, &anchor)) {
        return STATUS_NOT_SUPPORTED;
    }
    status = KswPlatformLocateRipTable(
        ModuleInfo,
        anchor,
        locator,
        KswPlatformValidateHalAcpiCandidate,
        &tableAddress);
    if (!NT_SUCCESS(status)) {
        return status;
    }
    RtlZeroMemory(&view, sizeof(view));
    if (!KswordARKHookReadMemorySafe(
            tableAddress,
            &view,
            FIELD_OFFSET(KSW_PLATFORM_HAL_ACPI_VIEW, Functions)) ||
        !KswPlatformHalAcpiIdentityMatches(
            &view,
            &functionCount,
            &byteSize) ||
        EntryIndex >= functionCount ||
        byteSize > sizeof(view) ||
        !KswordARKHookReadMemorySafe(tableAddress, &view, byteSize) ||
        !KswPlatformHalAcpiIdentityMatches(&view, NULL, NULL)) {
        return STATUS_REVISION_MISMATCH;
    }

    SlotOut->TableAddress = tableAddress;
    SlotOut->SlotAddress = (PVOID volatile*)(
        (UCHAR*)tableAddress +
        FIELD_OFFSET(KSW_PLATFORM_HAL_ACPI_VIEW, Functions) +
        (EntryIndex * sizeof(PVOID)));
    SlotOut->CurrentValue = view.Functions[EntryIndex];
    return STATUS_SUCCESS;
}

static NTSTATUS
KswPlatformResolveHalSubcomponentEditSlot(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ ULONG BuildNumber,
    _In_ ULONG EntryIndex,
    _Out_ KSW_PLATFORM_EDIT_SLOT* SlotOut
    )
{
    const KSW_PLATFORM_RIP_LOCATOR_DESCRIPTOR* locator =
        KswPlatformFindRipLocator(
            g_KswHalSubcomponentLocators,
            RTL_NUMBER_OF(g_KswHalSubcomponentLocators),
            BuildNumber);
    KSW_PLATFORM_HAL_SUBCOMPONENT
        entries[KSW_PLATFORM_HAL_SUBCOMPONENT_MAX_COUNT];
    PVOID anchor = NULL;
    PVOID tableAddress = NULL;
    ULONG entryCount = 0UL;
    NTSTATUS status = STATUS_NOT_SUPPORTED;

    if (ModuleInfo == NULL || SlotOut == NULL || locator == NULL) {
        return STATUS_NOT_SUPPORTED;
    }
    entryCount = locator->ExpectedVersion;
    anchor = locator->AnchorName != NULL ?
        KswPlatformGetRoutine(locator->AnchorName) :
        NULL;
    status = KswPlatformLocateRipTable(
        ModuleInfo,
        anchor,
        locator,
        KswPlatformValidateHalSubcomponentCandidate,
        &tableAddress);
    if (!NT_SUCCESS(status)) {
        return status;
    }
    if (entryCount > RTL_NUMBER_OF(entries) || EntryIndex >= entryCount) {
        return STATUS_INVALID_PARAMETER;
    }
    RtlZeroMemory(entries, sizeof(entries));
    if (!KswordARKHookReadMemorySafe(
            tableAddress,
            entries,
            locator->TableByteSize) ||
        !KswPlatformHalSubcomponentIdentityMatches(
            ModuleInfo,
            entries,
            entryCount)) {
        return STATUS_REVISION_MISMATCH;
    }

    SlotOut->TableAddress = tableAddress;
    SlotOut->SlotAddress = (PVOID volatile*)(
        (UCHAR*)tableAddress +
        (EntryIndex * sizeof(KSW_PLATFORM_HAL_SUBCOMPONENT)) +
        FIELD_OFFSET(KSW_PLATFORM_HAL_SUBCOMPONENT, Function));
    SlotOut->CurrentValue = entries[EntryIndex].Function;
    return STATUS_SUCCESS;
}

static NTSTATUS
KswPlatformResolveWdfFunctionEditSlot(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ ULONG EntryIndex,
    _Out_ KSW_PLATFORM_EDIT_SLOT* SlotOut
    )
/*++

Routine Description:

    在 KMDF 完整绑定表中重新定位一个函数槽。判据与查询路径逐条相同：表指针
    必须属于 Wdf01000.sys，整表必须落在同一非执行节内，索引必须在表项数以
    内。R3 传入的 tableAddress 只用于事后比对，不参与地址计算。

    该表由框架自身持有，系统上所有 KMDF 驱动（含本驱动）共享同一份，因此一个
    槽位的改动是全局的——调用方必须已经取得明确的用户确认。

--*/
{
    // WdfFunctions 声明为 const，编辑路径要在同一地址上做 CAS，所以取槽地址时
    // 显式去掉 const；写入权限由下面的模块与节判据决定，不由类型决定。
    const WDFFUNC* functionTable = WdfFunctions;
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* tableOwner = NULL;
    ULONG functionCount = (ULONG)WdfFunctionTableNumEntries;
    WDFFUNC currentValue = NULL;

    if (ModuleInfo == NULL || SlotOut == NULL) {
        return STATUS_INVALID_PARAMETER;
    }
    if (functionTable == NULL ||
        functionCount == 0UL ||
        functionCount > KSWORD_ARK_PLATFORM_HARD_MAX_ROWS) {
        return STATUS_NOT_SUPPORTED;
    }
    if (EntryIndex >= functionCount) {
        return STATUS_INVALID_PARAMETER;
    }
    tableOwner = KswordARKHookFindModuleForAddress(
        ModuleInfo,
        (ULONG_PTR)functionTable);
    if (!KswPlatformModuleNameEquals(tableOwner, "Wdf01000.sys") ||
        !KswPlatformRangeInSection(
            tableOwner,
            (ULONG_PTR)functionTable,
            (SIZE_T)functionCount * sizeof(WDFFUNC),
            FALSE,
            FALSE)) {
        return STATUS_DATA_ERROR;
    }
    if (!KswordARKHookReadMemorySafe(
            &functionTable[EntryIndex],
            &currentValue,
            sizeof(currentValue))) {
        return STATUS_PARTIAL_COPY;
    }

    SlotOut->TableAddress = (PVOID)(ULONG_PTR)functionTable;
    SlotOut->SlotAddress =
        (PVOID volatile*)(ULONG_PTR)&functionTable[EntryIndex];
    SlotOut->CurrentValue = (PVOID)(ULONG_PTR)currentValue;
    return STATUS_SUCCESS;
}

static NTSTATUS
KswPlatformResolveEditableSlot(
    _In_ const KSW_HOOK_SYSTEM_MODULE_INFORMATION* ModuleInfo,
    _In_ ULONG BuildNumber,
    _In_ ULONG Scope,
    _In_ ULONG EntryIndex,
    _Out_ KSW_PLATFORM_EDIT_SLOT* SlotOut
    )
{
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* slotOwner = NULL;
    NTSTATUS status = STATUS_INVALID_PARAMETER;

    if (SlotOut == NULL) {
        return STATUS_INVALID_PARAMETER;
    }
    RtlZeroMemory(SlotOut, sizeof(*SlotOut));
    switch (Scope) {
    case KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_DISPATCH:
        status = KswPlatformResolveHalDispatchEditSlot(
            ModuleInfo,
            EntryIndex,
            SlotOut);
        break;
    case KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_PRIVATE:
        status = KswPlatformResolveHalPrivateEditSlot(
            ModuleInfo,
            BuildNumber,
            EntryIndex,
            SlotOut);
        break;
    case KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI:
        status = KswPlatformResolveHalAcpiEditSlot(
            ModuleInfo,
            BuildNumber,
            EntryIndex,
            SlotOut);
        break;
    case KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_SUBCOMPONENTS:
        status = KswPlatformResolveHalSubcomponentEditSlot(
            ModuleInfo,
            BuildNumber,
            EntryIndex,
            SlotOut);
        break;
    case KSWORD_ARK_PLATFORM_AUDIT_SCOPE_WDF_FUNCTIONS:
        status = KswPlatformResolveWdfFunctionEditSlot(
            ModuleInfo,
            EntryIndex,
            SlotOut);
        break;
    default:
        // WDF_CALLBACKS 描述的是本驱动 .text 内的编译期地址，没有可写槽。
        return STATUS_INVALID_PARAMETER;
    }
    if (!NT_SUCCESS(status)) {
        return status;
    }
    if (SlotOut->SlotAddress == NULL) {
        RtlZeroMemory(SlotOut, sizeof(*SlotOut));
        return STATUS_INVALID_ADDRESS;
    }

    // 槽位所在节缺少 IMAGE_SCN_MEM_WRITE 时（KMDF 绑定表就在只读节里），直接
    // CAS 会 bug check 0xBE，必须让提交路径改走 MDL 可写别名。判不出归属时同样
    // 走别名：别名路径对可写页也成立，而地址真的无效时探测会抛异常并被捕获。
    slotOwner = KswordARKHookFindModuleForAddress(
        ModuleInfo,
        (ULONG_PTR)SlotOut->SlotAddress);
    SlotOut->RequiresWritableAlias = (BOOLEAN)(
        slotOwner == NULL ||
        !KswPlatformRangeInWritableDataSection(
            slotOwner,
            (ULONG_PTR)SlotOut->SlotAddress,
            sizeof(PVOID)));
    return STATUS_SUCCESS;
}

static VOID
KswPlatformLogControlResult(
    _In_ WDFDEVICE Device,
    _In_ const KSWORD_ARK_CONTROL_PLATFORM_AUDIT_RESPONSE* Response
    )
{
    CHAR message[KSWORD_ARK_LOG_ENTRY_MAX_BYTES] = { 0 };
    NTSTATUS status = STATUS_SUCCESS;

    if (Response == NULL) {
        return;
    }
    status = RtlStringCbPrintfA(
        message,
        sizeof(message),
        "R0 platform slot edit: scope=0x%08lX index=%lu status=%lu nt=0x%08X "
        "table=0x%I64X slot=0x%I64X previous=0x%I64X "
        "requested=0x%I64X current=0x%I64X flags=0x%08lX.",
        Response->scope,
        Response->entryIndex,
        Response->status,
        (unsigned int)Response->lastStatus,
        Response->tableAddress,
        Response->slotAddress,
        Response->previousValue,
        Response->requestedValue,
        Response->currentValue,
        Response->responseFlags);
    if (NT_SUCCESS(status)) {
        (VOID)KswordARKDriverEnqueueLogFrame(
            Device,
            Response->status == KSWORD_ARK_PLATFORM_CONTROL_STATUS_OK ?
                "Warn" : "Error",
            message);
    }
}

NTSTATUS
KswordARKPlatformAuditIoctlControl(
    _In_ WDFDEVICE Device,
    _In_ WDFREQUEST Request,
    _In_ size_t InputBufferLength,
    _In_ size_t OutputBufferLength,
    _Out_ size_t* BytesReturned
    )
{
    const KSWORD_ARK_CONTROL_PLATFORM_AUDIT_REQUEST* input = NULL;
    KSWORD_ARK_CONTROL_PLATFORM_AUDIT_REQUEST requestSnapshot;
    KSWORD_ARK_CONTROL_PLATFORM_AUDIT_RESPONSE* response = NULL;
    KSW_HOOK_SYSTEM_MODULE_INFORMATION* moduleInfo = NULL;
    const KSW_HOOK_SYSTEM_MODULE_ENTRY* targetOwner = NULL;
    KSW_PLATFORM_EDIT_SLOT slot;
    PVOID inputBuffer = NULL;
    PVOID outputBuffer = NULL;
    PVOID previousValue = NULL;
    ULONG moduleInfoBytes = 0UL;
    ULONG majorVersion = 0UL;
    ULONG minorVersion = 0UL;
    ULONG buildNumber = 0UL;
    size_t actualInputBytes = 0U;
    size_t actualOutputBytes = 0U;
    NTSTATUS status = STATUS_SUCCESS;

    UNREFERENCED_PARAMETER(InputBufferLength);
    UNREFERENCED_PARAMETER(OutputBufferLength);

    if (BytesReturned == NULL) {
        return STATUS_INVALID_PARAMETER;
    }
    *BytesReturned = 0U;
    if (KeGetCurrentIrql() != PASSIVE_LEVEL) {
        return STATUS_INVALID_DEVICE_STATE;
    }
    status = KswordARKValidateDeviceIoControlWriteAccess(Request);
    if (!NT_SUCCESS(status)) {
        return status;
    }
    status = KswordARKRetrieveRequiredInputBuffer(
        Request,
        sizeof(requestSnapshot),
        &inputBuffer,
        &actualInputBytes);
    if (!NT_SUCCESS(status)) {
        return status;
    }
    RtlCopyMemory(&requestSnapshot, inputBuffer, sizeof(requestSnapshot));
    input = &requestSnapshot;
    status = KswordARKRetrieveRequiredOutputBuffer(
        Request,
        sizeof(*response),
        &outputBuffer,
        &actualOutputBytes);
    if (!NT_SUCCESS(status)) {
        return status;
    }
    UNREFERENCED_PARAMETER(actualInputBytes);
    UNREFERENCED_PARAMETER(actualOutputBytes);
    response = (KSWORD_ARK_CONTROL_PLATFORM_AUDIT_RESPONSE*)outputBuffer;
    RtlZeroMemory(response, sizeof(*response));
    response->size = sizeof(*response);
    response->version = KSWORD_ARK_PLATFORM_AUDIT_PROTOCOL_VERSION;
    response->scope = input->scope;
    response->entryIndex = input->entryIndex;
    response->requestedValue = input->newValue;
    response->status = KSWORD_ARK_PLATFORM_CONTROL_STATUS_INVALID_REQUEST;
    response->lastStatus = STATUS_INVALID_PARAMETER;
    *BytesReturned = sizeof(*response);

    if (input->size != sizeof(*input) ||
        input->version != KSWORD_ARK_PLATFORM_AUDIT_PROTOCOL_VERSION ||
        input->tableAddress == 0ULL ||
        input->newValue == 0ULL ||
        input->reserved0 != 0UL ||
        input->reserved1 != 0UL ||
        (input->flags & ~KSWORD_ARK_PLATFORM_CONTROL_FLAG_UI_CONFIRMED) != 0UL) {
        KswPlatformLogControlResult(Device, response);
        return STATUS_SUCCESS;
    }
    if ((input->flags & KSWORD_ARK_PLATFORM_CONTROL_FLAG_UI_CONFIRMED) == 0UL ||
        input->confirmationToken !=
            KSWORD_ARK_PLATFORM_CONTROL_CONFIRMATION_TOKEN) {
        response->status =
            KSWORD_ARK_PLATFORM_CONTROL_STATUS_CONFIRMATION_REQUIRED;
        response->lastStatus = STATUS_REQUEST_NOT_ACCEPTED;
        KswPlatformLogControlResult(Device, response);
        return STATUS_SUCCESS;
    }

    {
        KSWORD_ARK_SAFETY_CONTEXT safetyContext = { 0 };
        safetyContext.Operation = KSWORD_ARK_SAFETY_OPERATION_KERNEL_PATCH;
        safetyContext.ContextFlags =
            KSWORD_ARK_SAFETY_CONTEXT_FLAG_UI_CONFIRMED;
        if (input->scope == KSWORD_ARK_PLATFORM_AUDIT_SCOPE_WDF_FUNCTIONS) {
            safetyContext.TargetText = L"Validated KMDF binding table slot";
            safetyContext.TargetTextChars = (USHORT)(
                RTL_NUMBER_OF(L"Validated KMDF binding table slot") - 1U);
        }
        else {
            safetyContext.TargetText = L"Validated HAL function table slot";
            safetyContext.TargetTextChars = (USHORT)(
                RTL_NUMBER_OF(L"Validated HAL function table slot") - 1U);
        }
        status = KswordARKSafetyEvaluate(Device, &safetyContext);
        if (!NT_SUCCESS(status)) {
            response->status =
                KSWORD_ARK_PLATFORM_CONTROL_STATUS_SAFETY_DENIED;
            response->lastStatus = status;
            KswPlatformLogControlResult(Device, response);
            return STATUS_SUCCESS;
        }
    }

    (VOID)PsGetVersion(&majorVersion, &minorVersion, &buildNumber, NULL);
    UNREFERENCED_PARAMETER(majorVersion);
    UNREFERENCED_PARAMETER(minorVersion);
    status = KswordARKHookBuildModuleSnapshot(&moduleInfo, &moduleInfoBytes);
    if (!NT_SUCCESS(status) || moduleInfo == NULL || moduleInfoBytes == 0UL) {
        response->status = KSWORD_ARK_PLATFORM_CONTROL_STATUS_UNSUPPORTED;
        response->lastStatus = NT_SUCCESS(status) ?
            STATUS_UNSUCCESSFUL : status;
        if (moduleInfo != NULL) {
            ExFreePoolWithTag(moduleInfo, KSW_HOOK_SCAN_TAG);
        }
        KswPlatformLogControlResult(Device, response);
        return STATUS_SUCCESS;
    }

    status = KswPlatformResolveEditableSlot(
        moduleInfo,
        buildNumber,
        input->scope,
        input->entryIndex,
        &slot);
    if (!NT_SUCCESS(status)) {
        response->status =
            status == STATUS_INVALID_PARAMETER ||
            status == STATUS_OBJECT_TYPE_MISMATCH ?
                KSWORD_ARK_PLATFORM_CONTROL_STATUS_INVALID_REQUEST :
                KSWORD_ARK_PLATFORM_CONTROL_STATUS_UNSUPPORTED;
        response->lastStatus = status;
        ExFreePoolWithTag(moduleInfo, KSW_HOOK_SCAN_TAG);
        KswPlatformLogControlResult(Device, response);
        return STATUS_SUCCESS;
    }
    response->tableAddress = (ULONGLONG)(ULONG_PTR)slot.TableAddress;
    response->slotAddress = (ULONGLONG)(ULONG_PTR)slot.SlotAddress;
    response->previousValue = (ULONGLONG)(ULONG_PTR)slot.CurrentValue;
    response->currentValue = response->previousValue;
    response->responseFlags |=
        KSWORD_ARK_PLATFORM_CONTROL_RESPONSE_TABLE_REVALIDATED;

    if ((ULONGLONG)(ULONG_PTR)slot.TableAddress != input->tableAddress ||
        (ULONGLONG)(ULONG_PTR)slot.CurrentValue != input->expectedValue) {
        response->status =
            KSWORD_ARK_PLATFORM_CONTROL_STATUS_STALE_SNAPSHOT;
        response->lastStatus = STATUS_REVISION_MISMATCH;
        ExFreePoolWithTag(moduleInfo, KSW_HOOK_SCAN_TAG);
        KswPlatformLogControlResult(Device, response);
        return STATUS_SUCCESS;
    }

    targetOwner = KswordARKHookFindModuleForAddress(
        moduleInfo,
        (ULONG_PTR)input->newValue);
    if (targetOwner == NULL ||
        !KswPlatformAddressSectionMatches(
            targetOwner,
            (ULONG_PTR)input->newValue,
            TRUE)) {
        response->status =
            KSWORD_ARK_PLATFORM_CONTROL_STATUS_TARGET_INVALID;
        response->lastStatus = STATUS_INVALID_ADDRESS;
        ExFreePoolWithTag(moduleInfo, KSW_HOOK_SCAN_TAG);
        KswPlatformLogControlResult(Device, response);
        return STATUS_SUCCESS;
    }
    response->responseFlags |=
        KSWORD_ARK_PLATFORM_CONTROL_RESPONSE_TARGET_EXECUTABLE;

    if (input->newValue == input->expectedValue) {
        response->status = KSWORD_ARK_PLATFORM_CONTROL_STATUS_OK;
        response->lastStatus = STATUS_SUCCESS;
        ExFreePoolWithTag(moduleInfo, KSW_HOOK_SCAN_TAG);
        KswPlatformLogControlResult(Device, response);
        return STATUS_SUCCESS;
    }

    status = KswPlatformCommitEdit(
        input->scope,
        input->entryIndex,
        &slot,
        (PVOID)(ULONG_PTR)input->expectedValue,
        (PVOID)(ULONG_PTR)input->newValue,
        &previousValue);
    response->previousValue = (ULONGLONG)(ULONG_PTR)previousValue;
    response->currentValue = response->previousValue;
    if (status == STATUS_REVISION_MISMATCH ||
        status == STATUS_CONFLICTING_ADDRESSES) {
        response->status =
            KSWORD_ARK_PLATFORM_CONTROL_STATUS_STALE_SNAPSHOT;
        response->lastStatus = status;
    }
    else if (!NT_SUCCESS(status)) {
        response->status =
            KSWORD_ARK_PLATFORM_CONTROL_STATUS_WRITE_FAILED;
        response->lastStatus = status;
    }
    else {
        response->status = KSWORD_ARK_PLATFORM_CONTROL_STATUS_OK;
        response->lastStatus = STATUS_SUCCESS;
        response->currentValue = input->newValue;
        response->responseFlags |=
            KSWORD_ARK_PLATFORM_CONTROL_RESPONSE_CHANGED;
        if (slot.RequiresWritableAlias) {
            response->responseFlags |=
                KSWORD_ARK_PLATFORM_CONTROL_RESPONSE_ALIAS_WRITE;
        }
    }

    ExFreePoolWithTag(moduleInfo, KSW_HOOK_SCAN_TAG);
    KswPlatformLogControlResult(Device, response);
    return STATUS_SUCCESS;
}
