#pragma once

#include "ark/ark_driver.h"

#define KSW_HVM_VMEXIT_REASON_BASIC_MASK 0x0000FFFFUL
#define KSW_HVM_VMEXIT_REASON_ENTRY_FAILURE 0x80000000UL
#define KSW_HVM_VMEXIT_REASON_VMCALL 18UL

#pragma pack(push, 1)
typedef struct _KSW_HVM_DESCRIPTOR_TABLE
{
    USHORT Limit;
    ULONGLONG Base;
} KSW_HVM_DESCRIPTOR_TABLE;

typedef struct _KSW_HVM_SEGMENT_SNAPSHOT
{
    KSW_HVM_DESCRIPTOR_TABLE Gdtr;
    KSW_HVM_DESCRIPTOR_TABLE Idtr;
    USHORT Es;
    USHORT Cs;
    USHORT Ss;
    USHORT Ds;
    USHORT Fs;
    USHORT Gs;
    USHORT Ldtr;
    USHORT Tr;
} KSW_HVM_SEGMENT_SNAPSHOT;
#pragma pack(pop)

typedef struct _KSW_HVM_VMCS_INPUT
{
    ULONGLONG VmxBasic;
    ULONGLONG Cr0Fixed0;
    ULONGLONG Cr0Fixed1;
    ULONGLONG Cr4Fixed0;
    ULONGLONG Cr4Fixed1;
    ULONGLONG EptPointer;
    ULONGLONG GuestStackPointer;
    ULONGLONG HostStackPointer;
    ULONGLONG GuestInstructionPointer;
    ULONGLONG HostInstructionPointer;
    ULONGLONG GuestRflags;
    /*
     * Page-directory base loaded into HOST_CR3 on every VM exit.  Must name an
     * address space that outlives residency - the System process one - not the
     * CR3 that happens to be current while the VMCS is written, which belongs
     * to whichever process asked for residency.  Zero is refused.
     */
    ULONGLONG HostCr3;
    ULONGLONG MsrBitmapPhysical;
    /*
     * Per-processor #VE information area.  Zero means the caller has none, in
     * which case the EPT-violation #VE control is never requested.
     */
    ULONGLONG VeInfoPhysical;
    /*
     * EPTP list published to VMFUNC.  Zero means the caller has none, in which
     * case VM functions are never requested.
     */
    ULONGLONG EptpListPhysical;
    /* CR0/CR4 bits owned by the hypervisor; the guest reads them from shadow. */
    ULONGLONG Cr0PinnedMask;
    ULONGLONG Cr4PinnedMask;
    /* Nonzero makes every address-space switch exit. Expensive by design. */
    UCHAR TrackCr3;
    /* Nonzero makes guest debug-register access exit. */
    UCHAR InterceptDr;
    UCHAR ResidentMode;
    UCHAR EnableNestedVmx;
    /* Only resident builders contribute to transition timing. */
    ULONG MetricsCpuIndex;
    /*
     * Nonzero requests EPT-violation #VE.  This alone delivers nothing: a
     * violation still converts only on a leaf whose suppress-#VE bit is clear
     * (this driver sets it everywhere) and only when the information area is
     * not busy (allocation latches it busy).  Both must also be undone before
     * a single #VE can reach the guest.
     */
    UCHAR EnableVe;
    /*
     * Nonzero arms VM functions and EPTP switching.  VMFUNC performs no CPL
     * check, so arming this publishes every list entry to unprivileged guest
     * code.  Domains are forkable only in the narrowing direction, which is
     * what keeps that from being an escalation path.
     */
    UCHAR EnableVmFunctions;
    USHORT Reserved;
    /*
     * Interrupt descriptor table to install as HOST_IDTR_BASE, or zero to keep
     * using the guest's own.
     *
     * VMX root runs on whatever IDT this field names, and until now that was
     * the guest's - which is correct for everything the host does on purpose,
     * because the host raises no exceptions.  It stops being correct as soon
     * as something *sends* this processor an NMI: an NMI that lands while the
     * processor is in VMX root is not converted into a VM exit no matter what
     * the pin controls say, so it is delivered through this IDT, and the
     * guest's vector 2 belongs to Windows, which bugchecks 0x80 on an NMI it
     * cannot attribute.  Measured 2026-09-07 - that is exactly how the first
     * cross-processor flush attempt failed.
     *
     * A private IDT is therefore a precondition for sending NMIs at all, not
     * an optimization.  Zero keeps the previous behavior exactly.
     */
    ULONGLONG HostIdtBase;
    /*
     * Where to record the controls that end up enforced, or NULL to record
     * nothing.  Purely diagnostic: configuration behaves identically either
     * way.
     */
    struct _KSW_HVM_ACTIVE_CONTROLS* ActiveControls;
} KSW_HVM_VMCS_INPUT;

typedef struct _KSW_HVM_VMEXIT_TELEMETRY
{
    ULONG Reason;
    ULONG InstructionLength;
    ULONG VmInstructionError;
    ULONG Reserved;
    ULONGLONG Qualification;
    ULONGLONG GuestRip;
    ULONGLONG GuestRsp;
} KSW_HVM_VMEXIT_TELEMETRY;

/*
 * What was actually written into the VMCS execution-control fields, and the
 * capability MSR each one was adjusted against.
 *
 * "Which exits does this machine take" and "which of them did we ask for" are
 * different questions, and the second one used to be answerable only by reading
 * the source and reasoning.  The exit histogram made the gap concrete: HLT is
 * the single largest exit reason on the nested target, while resident mode
 * requests no HLT exiting at all - so either the outer hypervisor forces the
 * bit through the allowed-0 half of the capability MSR, or the control is being
 * computed wrongly, and reasoning cannot tell those two apart.
 *
 * The adjusted result is what is kept, not the request: the request is a
 * compile-time constant anyone can read, while the value the processor
 * enforces is the one that explains the exits.  A bit set here that the
 * request did not ask for is, by construction, one the capability MSR made
 * mandatory.
 */
typedef struct _KSW_HVM_ACTIVE_CONTROLS
{
    ULONG Pin;
    ULONG Primary;
    ULONG Secondary;
    ULONG Exit;
    ULONG Entry;
    /* Keep the 64-bit members below naturally aligned. */
    ULONG Reserved;
    ULONGLONG PinCapability;
    ULONGLONG PrimaryCapability;
    ULONGLONG SecondaryCapability;
    ULONGLONG ExitCapability;
    ULONGLONG EntryCapability;
} KSW_HVM_ACTIVE_CONTROLS;

EXTERN_C_START

/*
 * Read one field of the current VMCS.  Returns 0 on success, matching the
 * VMREAD intrinsic this currently forwards to.
 *
 * Every VMCS access in the driver goes through here and its write counterpart.
 * The reason is that field storage is not fixed: under a hypervisor offering
 * the enlightened VMCS, "the current VMCS" is a shared page to be read with
 * ordinary loads, and the VMREAD instruction is both unnecessary and, on the
 * hot exit path, expensive.  Switching storage is one edit here; it is 60-odd
 * edits if every call site spells the instruction out, and the failure mode of
 * missing one is a field silently read from the wrong place.
 *
 * Callers must not assume the field was actually read on failure - Value is
 * left untouched, exactly as the intrinsic leaves it.
 */
UCHAR
KswordARKHvmVmcsFieldLoad(
    _In_ SIZE_T Field,
    _Out_ SIZE_T* Value
    );

/* Write one field of the current VMCS.  Returns 0 on success. */
UCHAR
KswordARKHvmVmcsFieldStore(
    _In_ SIZE_T Field,
    _In_ SIZE_T Value
    );

VOID
KswordARKHvmCaptureSegments(
    _Out_ KSW_HVM_SEGMENT_SNAPSHOT* Snapshot
    );

/* Describe one resolved segment in the layout VMCS guest state expects. */
typedef struct _KSW_HVM_SEGMENT_STATE
{
    USHORT Selector;
    ULONG Limit;
    ULONG AccessRights;
    ULONGLONG Base;
} KSW_HVM_SEGMENT_STATE;

/*
 * Resolve one selector against a captured descriptor-table snapshot.
 *
 * Exported rather than kept private because anything constructing guest state
 * needs exactly this decoding - the system-segment high base, the unusable
 * marker for a null selector, the packed access-rights format.  A second copy
 * would be a second place for those three to drift, and the symptom of drift
 * is a VM entry that fails on guest state with no indication which field.
 */
NTSTATUS
KswordARKHvmReadSegment(
    _In_ const KSW_HVM_SEGMENT_SNAPSHOT* Snapshot,
    _In_ USHORT Selector,
    _Out_ KSW_HVM_SEGMENT_STATE* Segment
    );

ULONGLONG
KswordARKHvmAsmReadSsp(
    VOID
    );

VOID
KswordARKHvmControlledGuestEntry(
    VOID
    );

VOID
KswordARKHvmVmExitEntry(
    VOID
    );

NTSTATUS
KswordARKHvmConfigureVmcs(
    _In_ const KSW_HVM_VMCS_INPUT* Input,
    _Out_ ULONG* VmInstructionError
    );

NTSTATUS
KswordARKHvmReadVmExitTelemetry(
    _Out_ KSW_HVM_VMEXIT_TELEMETRY* Telemetry
    );

/* Omit only fields that have no architectural meaning for a successful CPUID exit. */
NTSTATUS KswordARKHvmReadVmExitTelemetryEx(KSW_HVM_VMEXIT_TELEMETRY* Telemetry,
    BOOLEAN SparseCpuid);

EXTERN_C_END
