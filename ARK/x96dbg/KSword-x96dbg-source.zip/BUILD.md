# Source archive

The top-level paths retain their KSword repository layout. The proxy and launcher
projects build directly with Visual Studio 2022 MSBuild, Release/x64. All three
HostX64 properties documented in docs/ksword-x64dbg-backend.md are required.

upstream/ contains unmodified pinned x64dbg and native TitanEngine source ZIPs.
Apply X96dbgIntegration/patches/x64dbg-ksword-engine.patch to the x64dbg source.
Submodule revisions are recorded in upstream/submodule-revisions.txt; repository
URLs are retained in the original .gitmodules and CMake source.
tools/Build-X96dbgPayload.ps1 -PrepareDependencies retrieves the pinned complete
checkout and the verified unmodified Qt 5.12.12 SDK inside .deps/.

Original Qt and runtime dependency license texts and source links are under
third_party/x64dbg_runtime_licenses/. Native TitanEngine and x64dbg retain their
original licenses in the upstream ZIPs and in the binary plugin package.
