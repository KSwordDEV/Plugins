#pragma once

#include "KswordArkProcessIoctl.h"

// ============================================================
// KswordArkCallbackIoctl.h
// Purpose:
// - Shared callback interception protocol for R3 <-> R0.
// - Defines callback rule blob, runtime state, ask/answer events and IOCTLs.
// ============================================================

#define KSWORD_ARK_CALLBACK_PROTOCOL_VERSION 1UL
#define KSWORD_ARK_CALLBACK_RULE_SCHEMA_VERSION 1UL

// Shared IOCTL function codes on existing \\.\KswordARKLog control device.
#define KSWORD_ARK_IOCTL_FUNCTION_SET_CALLBACK_RULES 0x880
#define KSWORD_ARK_IOCTL_FUNCTION_GET_CALLBACK_RUNTIME_STATE 0x881
#define KSWORD_ARK_IOCTL_FUNCTION_WAIT_CALLBACK_EVENT 0x882
#define KSWORD_ARK_IOCTL_FUNCTION_ANSWER_CALLBACK_EVENT 0x883
#define KSWORD_ARK_IOCTL_FUNCTION_CANCEL_ALL_PENDING_DECISIONS 0x884
#define KSWORD_ARK_IOCTL_FUNCTION_REMOVE_EXTERNAL_CALLBACK 0x885
#define KSWORD_ARK_IOCTL_FUNCTION_ENUM_CALLBACKS 0x886
#define KSWORD_ARK_IOCTL_FUNCTION_REMOVE_EXTERNAL_CALLBACK_EX 0x887
#define KSWORD_ARK_IOCTL_FUNCTION_SET_MINIFILTER_BYPASS_PIDS 0x888
#define KSWORD_ARK_IOCTL_FUNCTION_QUERY_MINIFILTER_BYPASS_PIDS 0x889

#define IOCTL_KSWORD_ARK_SET_CALLBACK_RULES \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_SET_CALLBACK_RULES, \
        METHOD_BUFFERED, \
        FILE_WRITE_ACCESS)

#define IOCTL_KSWORD_ARK_GET_CALLBACK_RUNTIME_STATE \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_GET_CALLBACK_RUNTIME_STATE, \
        METHOD_BUFFERED, \
        FILE_ANY_ACCESS)

#define IOCTL_KSWORD_ARK_WAIT_CALLBACK_EVENT \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_WAIT_CALLBACK_EVENT, \
        METHOD_BUFFERED, \
        FILE_ANY_ACCESS)

#define IOCTL_KSWORD_ARK_ANSWER_CALLBACK_EVENT \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_ANSWER_CALLBACK_EVENT, \
        METHOD_BUFFERED, \
        FILE_WRITE_ACCESS)

#define IOCTL_KSWORD_ARK_CANCEL_ALL_PENDING_DECISIONS \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_CANCEL_ALL_PENDING_DECISIONS, \
        METHOD_BUFFERED, \
        FILE_WRITE_ACCESS)

#define IOCTL_KSWORD_ARK_REMOVE_EXTERNAL_CALLBACK \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_REMOVE_EXTERNAL_CALLBACK, \
        METHOD_BUFFERED, \
        FILE_WRITE_ACCESS)

#define IOCTL_KSWORD_ARK_ENUM_CALLBACKS \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_ENUM_CALLBACKS, \
        METHOD_BUFFERED, \
        FILE_ANY_ACCESS)

#define IOCTL_KSWORD_ARK_REMOVE_EXTERNAL_CALLBACK_EX \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_REMOVE_EXTERNAL_CALLBACK_EX, \
        METHOD_BUFFERED, \
        FILE_WRITE_ACCESS)

#define IOCTL_KSWORD_ARK_SET_MINIFILTER_BYPASS_PIDS \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_SET_MINIFILTER_BYPASS_PIDS, \
        METHOD_BUFFERED, \
        FILE_WRITE_ACCESS)

#define IOCTL_KSWORD_ARK_QUERY_MINIFILTER_BYPASS_PIDS \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_QUERY_MINIFILTER_BYPASS_PIDS, \
        METHOD_BUFFERED, \
        FILE_ANY_ACCESS)

// Callback type.
#define KSWORD_ARK_CALLBACK_TYPE_NONE 0UL
#define KSWORD_ARK_CALLBACK_TYPE_REGISTRY 1UL
#define KSWORD_ARK_CALLBACK_TYPE_PROCESS_CREATE 2UL
#define KSWORD_ARK_CALLBACK_TYPE_THREAD_CREATE 3UL
#define KSWORD_ARK_CALLBACK_TYPE_IMAGE_LOAD 4UL
#define KSWORD_ARK_CALLBACK_TYPE_OBJECT 5UL
#define KSWORD_ARK_CALLBACK_TYPE_MINIFILTER 6UL
// 兼容旧配置/旧源码常量名：该类型已经接入文件系统微过滤器规则链路，不再是 UI 预留项。
#define KSWORD_ARK_CALLBACK_TYPE_MINIFILTER_RESERVED KSWORD_ARK_CALLBACK_TYPE_MINIFILTER

// External callback remove type.
#define KSWORD_ARK_EXTERNAL_CALLBACK_REMOVE_TYPE_PROCESS 1UL
#define KSWORD_ARK_EXTERNAL_CALLBACK_REMOVE_TYPE_THREAD 2UL
#define KSWORD_ARK_EXTERNAL_CALLBACK_REMOVE_TYPE_IMAGE 3UL
#define KSWORD_ARK_EXTERNAL_CALLBACK_REMOVE_TYPE_OBJECT 4UL
#define KSWORD_ARK_EXTERNAL_CALLBACK_REMOVE_TYPE_REGISTRY 5UL
#define KSWORD_ARK_EXTERNAL_CALLBACK_REMOVE_TYPE_MINIFILTER 6UL
#define KSWORD_ARK_EXTERNAL_CALLBACK_REMOVE_TYPE_WFP_CALLOUT 7UL
#define KSWORD_ARK_EXTERNAL_CALLBACK_REMOVE_TYPE_ETW_PROVIDER 8UL

// External callback remove protocol version.
#define KSWORD_ARK_EXTERNAL_CALLBACK_REMOVE_PROTOCOL_VERSION 1UL

// Callback enumeration protocol version. V3 adds optimistic snapshot validation.
#define KSWORD_ARK_CALLBACK_ENUM_PROTOCOL_VERSION_V2 2UL
#define KSWORD_ARK_CALLBACK_ENUM_PROTOCOL_VERSION 3UL

// Callback enumeration request flags.
#define KSWORD_ARK_ENUM_CALLBACK_FLAG_INCLUDE_KSWORD_SELF 0x00000001UL
#define KSWORD_ARK_ENUM_CALLBACK_FLAG_INCLUDE_MINIFILTERS 0x00000002UL
#define KSWORD_ARK_ENUM_CALLBACK_FLAG_INCLUDE_UNSUPPORTED 0x00000004UL
#define KSWORD_ARK_ENUM_CALLBACK_FLAG_INCLUDE_PRIVATE 0x00000008UL
#define KSWORD_ARK_ENUM_CALLBACK_FLAG_INCLUDE_ALL \
    (KSWORD_ARK_ENUM_CALLBACK_FLAG_INCLUDE_KSWORD_SELF | \
     KSWORD_ARK_ENUM_CALLBACK_FLAG_INCLUDE_MINIFILTERS | \
     KSWORD_ARK_ENUM_CALLBACK_FLAG_INCLUDE_UNSUPPORTED | \
     KSWORD_ARK_ENUM_CALLBACK_FLAG_INCLUDE_PRIVATE)

// Callback enumeration response flags. Hash flags are valid only on V3 responses.
#define KSWORD_ARK_ENUM_CALLBACK_RESPONSE_FLAG_TRUNCATED 0x00000001UL
#define KSWORD_ARK_ENUM_CALLBACK_RESPONSE_FLAG_MORE_DATA 0x00000002UL
#define KSWORD_ARK_ENUM_CALLBACK_RESPONSE_FLAG_SNAPSHOT_HASH_VALID 0x00000004UL
#define KSWORD_ARK_ENUM_CALLBACK_RESPONSE_FLAG_IDENTITY_HASH_VALID 0x00000008UL
#define KSWORD_ARK_ENUM_CALLBACK_RESPONSE_FLAG_SNAPSHOT_CHANGED 0x00000010UL

// Callback enumeration snapshot policy. REQUIRE_MATCH compares the whole logical result.
#define KSWORD_ARK_CALLBACK_SNAPSHOT_POLICY_NONE 0UL
#define KSWORD_ARK_CALLBACK_SNAPSHOT_POLICY_REQUIRE_MATCH 1UL

// Callback enumeration classes.
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_REGISTRY 1UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_PROCESS 2UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_THREAD 3UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_IMAGE 4UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_OBJECT 5UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_MINIFILTER 6UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_WFP_CALLOUT 7UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_ETW_PROVIDER 8UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_GENERIC_KERNEL 9UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_BUGCHECK 10UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_BUGCHECK_REASON 11UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_SHUTDOWN 12UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_FILE_SYSTEM 13UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_LOGON_SESSION 14UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_IMAGE_VERIFICATION 15UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_NMI 16UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_LEGACY_FS_FILTER 17UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_POWER_SETTING 18UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_COALESCING 19UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_PRIORITY 20UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_DEBUG_PRINT 21UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_EMP 22UL
#define KSWORD_ARK_CALLBACK_ENUM_CLASS_PLUG_PLAY 23UL

// Callback registration subtypes.
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_UNKNOWN 0UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_PROCESS_LEGACY 1UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_PROCESS_EX 2UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_PROCESS_EX2 3UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_THREAD_LEGACY 4UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_THREAD_EX_NON_SYSTEM 5UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_THREAD_EX_SUBSYSTEMS 6UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_IMAGE_LEGACY_OR_EX_DEFAULT 7UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_IMAGE_EX_CONFLICTING_ARCHITECTURE 8UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_BUGCHECK_CLASSIC 10UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_BUGCHECK_SECONDARY_DUMP 11UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_BUGCHECK_DUMP_IO 12UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_BUGCHECK_TRIAGE_DUMP 13UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_BUGCHECK_REASON_OTHER 14UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_SHUTDOWN 20UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_FILE_SYSTEM_CHANGE 30UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_LOGON_LEGACY 40UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_LOGON_EX 41UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_IMAGE_VERIFY_INFORMATIONAL 50UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_IMAGE_VERIFY_BLOCK 51UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_GENERIC_CALLBACK_OBJECT 60UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_NMI 61UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_DESKTOP_OBJECT 70UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_LEGACY_FS_CLASS_INIT 80UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_LEGACY_FS_PRE 81UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_LEGACY_FS_POST 82UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_POWER_SETTING 90UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_COALESCING 91UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_PRIORITY 92UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_DEBUG_PRINT 93UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_EMP 94UL
#define KSWORD_ARK_CALLBACK_REGISTRATION_TYPE_PLUG_PLAY 95UL

// Callback enumeration sources.
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_KSWORD_SELF 1UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_FLTMGR_ENUMERATION 2UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_PRIVATE_UNSUPPORTED 3UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_PRIVATE_PATTERN_SCAN 4UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_PRIVATE_NOTIFY_ARRAY 5UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_PRIVATE_REGISTRY_LIST 6UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_PRIVATE_OBJECT_TYPE_LIST 7UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_WFP_MGMT_API 8UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_ETW_DYNDATA 9UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_PDB_PROFILE 10UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_PUBLIC_API 11UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_PRIVATE_BUGCHECK_LIST 12UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_PRIVATE_FILESYSTEM_LIST 13UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_PRIVATE_LOGON_LIST 14UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_CALLBACK_OBJECT 15UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_DRIVER_OBJECT_SCAN 16UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_OBJECT_DIRECTORY 17UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_PRIVATE_NMI_LIST 18UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_LEGACY_FS_PUBLIC_AND_STRUCTURAL 19UL
#define KSWORD_ARK_CALLBACK_ENUM_SOURCE_PRIVATE_SPECIAL_CALLBACK 20UL

// Callback enumeration row status.
#define KSWORD_ARK_CALLBACK_ENUM_STATUS_UNKNOWN 0UL
#define KSWORD_ARK_CALLBACK_ENUM_STATUS_OK 1UL
#define KSWORD_ARK_CALLBACK_ENUM_STATUS_NOT_REGISTERED 2UL
#define KSWORD_ARK_CALLBACK_ENUM_STATUS_UNSUPPORTED 3UL
#define KSWORD_ARK_CALLBACK_ENUM_STATUS_QUERY_FAILED 4UL
#define KSWORD_ARK_CALLBACK_ENUM_STATUS_BUFFER_TRUNCATED 5UL
#define KSWORD_ARK_CALLBACK_ENUM_STATUS_SUSPICIOUS 6UL

// Callback enumeration field flags.
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_CALLBACK_ADDRESS 0x00000001UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_CONTEXT_ADDRESS 0x00000002UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_REGISTRATION_ADDRESS 0x00000004UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_MODULE 0x00000008UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_NAME 0x00000010UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_ALTITUDE 0x00000020UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_OWNED_BY_KSWORD 0x00000040UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_REMOVABLE_CANDIDATE 0x00000080UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_OPERATION_MASK 0x00000100UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_OBJECT_TYPE_MASK 0x00000200UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_IDENTIFIER 0x00000400UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_HANDLE 0x00000800UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_TRUSTED 0x00001000UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_VERIFIED_REMOVE 0x00002000UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_EXPERIMENTAL_REMOVE 0x00004000UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_RAW_STORAGE_VALUE 0x00008000UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_STORAGE_ADDRESS 0x00010000UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_OWNER_MODULE_RANGE 0x00020000UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_PROFILE_GATED 0x00040000UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_REGISTRATION_TYPE 0x00080000UL
// Identity hash is stable for one logical row; generation identifies the whole ordered snapshot.
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_IDENTITY_HASH 0x00100000UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_ENUMERATION_GENERATION 0x00200000UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_CLASS_INIT_DATA_VALIDATED 0x00400000UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_PRE_POST_PAIR 0x00800000UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_CALLBACK_OWNER_MATCH 0x01000000UL
#define KSWORD_ARK_CALLBACK_ENUM_FIELD_DETAIL_ARGS 0x02000000UL

// Stable Legacy FS filter diagnostics. R0 returns only these codes and numeric
// arguments; R3 formats user-visible text in the active language context.
#define KSWORD_ARK_CALLBACK_ENUM_DETAIL_NONE 0UL
#define KSWORD_ARK_CALLBACK_ENUM_DETAIL_LEGACY_FS_PUBLIC_EMPTY 1UL
#define KSWORD_ARK_CALLBACK_ENUM_DETAIL_LEGACY_FS_COUNT_LIMIT 2UL
#define KSWORD_ARK_CALLBACK_ENUM_DETAIL_LEGACY_FS_CLASS_INIT_NOT_FOUND 3UL
#define KSWORD_ARK_CALLBACK_ENUM_DETAIL_LEGACY_FS_CLASS_INIT_AMBIGUOUS 4UL
#define KSWORD_ARK_CALLBACK_ENUM_DETAIL_LEGACY_FS_CLASS_INIT_VALIDATED 5UL
#define KSWORD_ARK_CALLBACK_ENUM_DETAIL_LEGACY_FS_OWNER_MATCH 6UL
#define KSWORD_ARK_CALLBACK_ENUM_DETAIL_LEGACY_FS_OWNER_MISMATCH 7UL
#define KSWORD_ARK_CALLBACK_ENUM_DETAIL_LEGACY_FS_OWNER_UNRESOLVED 8UL
#define KSWORD_ARK_CALLBACK_ENUM_DETAIL_LEGACY_FS_PUBLIC_ENUM_FAILED 9UL
#define KSWORD_ARK_CALLBACK_ENUM_DETAIL_ARG_COUNT 4U

// Callback enumeration trust flags.
#define KSWORD_ARK_CALLBACK_TRUST_NONE 0x00000000UL
#define KSWORD_ARK_CALLBACK_TRUST_PDB_PROFILE 0x00000001UL
#define KSWORD_ARK_CALLBACK_TRUST_PUBLIC_API 0x00000002UL
#define KSWORD_ARK_CALLBACK_TRUST_FALLBACK_PATTERN 0x00000004UL
#define KSWORD_ARK_CALLBACK_TRUST_REVALIDATED 0x00000008UL
#define KSWORD_ARK_CALLBACK_TRUST_OWNER_MODULE_RESOLVED 0x00000010UL
#define KSWORD_ARK_CALLBACK_TRUST_OWNER_MODULE_MISSING 0x00000020UL
#define KSWORD_ARK_CALLBACK_TRUST_PROFILE_GATED 0x00000040UL
#define KSWORD_ARK_CALLBACK_TRUST_STORAGE_VALIDATED 0x00000080UL
#define KSWORD_ARK_CALLBACK_TRUST_STRUCTURE_SIGNATURE 0x00000100UL

// Callback owner range states. These values are read-only diagnostics.
#define KSWORD_ARK_CALLBACK_OWNER_RANGE_UNKNOWN 0UL
#define KSWORD_ARK_CALLBACK_OWNER_RANGE_WITHIN_MODULE 1UL
#define KSWORD_ARK_CALLBACK_OWNER_RANGE_MODULE_UNRESOLVED 2UL

// Callback removal behavior flags.
#define KSWORD_ARK_CALLBACK_REMOVE_BEHAVIOR_NONE 0x00000000UL
#define KSWORD_ARK_CALLBACK_REMOVE_BEHAVIOR_PUBLIC_API 0x00000001UL
#define KSWORD_ARK_CALLBACK_REMOVE_BEHAVIOR_EXPERIMENTAL_UNLINK 0x00000002UL
#define KSWORD_ARK_CALLBACK_REMOVE_BEHAVIOR_REQUIRE_REVALIDATION 0x00000004UL
#define KSWORD_ARK_CALLBACK_REMOVE_BEHAVIOR_FORCE_AFTER_PUBLIC_FAILURE 0x00000008UL

// Callback enumeration fixed text bounds.
#define KSWORD_ARK_CALLBACK_ENUM_NAME_CHARS 128U
#define KSWORD_ARK_CALLBACK_ENUM_ALTITUDE_CHARS 64U
#define KSWORD_ARK_CALLBACK_ENUM_MODULE_PATH_CHARS 260U
#define KSWORD_ARK_CALLBACK_ENUM_DETAIL_CHARS 260U

// External callback remove response text bounds.
#define KSWORD_ARK_EXTERNAL_CALLBACK_MODULE_NAME_MAX_CHARS 260U
#define KSWORD_ARK_EXTERNAL_CALLBACK_SERVICE_NAME_MAX_CHARS 260U

// External callback remove flags.
#define KSWORD_ARK_EXTERNAL_CALLBACK_REMOVE_FLAG_NONE 0UL
#define KSWORD_ARK_EXTERNAL_CALLBACK_REMOVE_FLAG_EXPERIMENTAL_UNLINK 0x00000001UL
#define KSWORD_ARK_EXTERNAL_CALLBACK_REMOVE_FLAG_REQUIRE_REVALIDATION 0x00000002UL

// External callback remove mapping flags.
#define KSWORD_ARK_EXTERNAL_CALLBACK_MAPPING_FLAG_MODULE 0x00000001UL
#define KSWORD_ARK_EXTERNAL_CALLBACK_MAPPING_FLAG_ENUMERATED 0x00000002UL
#define KSWORD_ARK_EXTERNAL_CALLBACK_MAPPING_FLAG_PUBLIC_API 0x00000004UL
#define KSWORD_ARK_EXTERNAL_CALLBACK_MAPPING_FLAG_PDB_TRUSTED 0x00000008UL
#define KSWORD_ARK_EXTERNAL_CALLBACK_MAPPING_FLAG_EXPERIMENTAL 0x00000010UL

// Match mode.
#define KSWORD_ARK_MATCH_MODE_NONE 0UL
#define KSWORD_ARK_MATCH_MODE_EXACT 1UL
#define KSWORD_ARK_MATCH_MODE_PREFIX 2UL
#define KSWORD_ARK_MATCH_MODE_WILDCARD 3UL
#define KSWORD_ARK_MATCH_MODE_REGEX 4UL

// Action type.
#define KSWORD_ARK_RULE_ACTION_NONE 0UL
#define KSWORD_ARK_RULE_ACTION_ALLOW 1UL
#define KSWORD_ARK_RULE_ACTION_DENY 2UL
#define KSWORD_ARK_RULE_ACTION_ASK_USER 3UL
#define KSWORD_ARK_RULE_ACTION_LOG_ONLY 4UL
#define KSWORD_ARK_RULE_ACTION_STRIP_ACCESS 5UL

// Decision type.
#define KSWORD_ARK_DECISION_NONE 0UL
#define KSWORD_ARK_DECISION_ALLOW 1UL
#define KSWORD_ARK_DECISION_DENY 2UL

// Global/group/rule enable flags.
#define KSWORD_ARK_CALLBACK_GLOBAL_FLAG_ENABLED 0x00000001UL
#define KSWORD_ARK_CALLBACK_GROUP_FLAG_ENABLED 0x00000001UL
#define KSWORD_ARK_CALLBACK_RULE_FLAG_ENABLED 0x00000001UL

// Registry operation mask.
#define KSWORD_ARK_REG_OP_CREATE_KEY 0x00000001UL
#define KSWORD_ARK_REG_OP_OPEN_KEY 0x00000002UL
#define KSWORD_ARK_REG_OP_DELETE_KEY 0x00000004UL
#define KSWORD_ARK_REG_OP_SET_VALUE 0x00000008UL
#define KSWORD_ARK_REG_OP_DELETE_VALUE 0x00000010UL
#define KSWORD_ARK_REG_OP_RENAME_KEY 0x00000020UL
#define KSWORD_ARK_REG_OP_SET_INFO 0x00000040UL
#define KSWORD_ARK_REG_OP_QUERY_VALUE 0x00000080UL
#define KSWORD_ARK_REG_OP_ALL 0xFFFFFFFFUL

// Process/thread/image/object operation mask.
#define KSWORD_ARK_PROCESS_OP_CREATE 0x00000001UL
#define KSWORD_ARK_THREAD_OP_CREATE 0x00000001UL
#define KSWORD_ARK_THREAD_OP_EXIT 0x00000002UL
#define KSWORD_ARK_IMAGE_OP_LOAD 0x00000001UL
#define KSWORD_ARK_OBJECT_OP_HANDLE_CREATE 0x00000001UL
#define KSWORD_ARK_OBJECT_OP_HANDLE_DUPLICATE 0x00000002UL
#define KSWORD_ARK_OBJECT_OP_TYPE_PROCESS 0x00000100UL
#define KSWORD_ARK_OBJECT_OP_TYPE_THREAD 0x00000200UL
#define KSWORD_ARK_OBJECT_OP_TYPE_DESKTOP 0x00000400UL

// Minifilter operation mask. Values intentionally mirror the file monitor protocol.
#define KSWORD_ARK_MINIFILTER_OP_CREATE  0x00000001UL
#define KSWORD_ARK_MINIFILTER_OP_READ    0x00000002UL
#define KSWORD_ARK_MINIFILTER_OP_WRITE   0x00000004UL
#define KSWORD_ARK_MINIFILTER_OP_SETINFO 0x00000008UL
#define KSWORD_ARK_MINIFILTER_OP_RENAME  0x00000010UL
#define KSWORD_ARK_MINIFILTER_OP_DELETE  0x00000020UL
#define KSWORD_ARK_MINIFILTER_OP_CLEANUP 0x00000040UL
#define KSWORD_ARK_MINIFILTER_OP_CLOSE   0x00000080UL
#define KSWORD_ARK_MINIFILTER_OP_ALL \
    (KSWORD_ARK_MINIFILTER_OP_CREATE | \
     KSWORD_ARK_MINIFILTER_OP_READ | \
     KSWORD_ARK_MINIFILTER_OP_WRITE | \
     KSWORD_ARK_MINIFILTER_OP_SETINFO | \
     KSWORD_ARK_MINIFILTER_OP_RENAME | \
     KSWORD_ARK_MINIFILTER_OP_DELETE | \
     KSWORD_ARK_MINIFILTER_OP_CLEANUP | \
     KSWORD_ARK_MINIFILTER_OP_CLOSE)

// Blob format constants.
#define KSWORD_ARK_CALLBACK_RULE_BLOB_MAGIC 0x5242434BUL // "KCBR"
#define KSWORD_ARK_CALLBACK_MAX_GROUP_COUNT 256UL
#define KSWORD_ARK_CALLBACK_MAX_RULE_COUNT 4096UL
#define KSWORD_ARK_CALLBACK_MAX_STRING_BYTES (1024UL * 1024UL)
#define KSWORD_ARK_MINIFILTER_BYPASS_PID_MAX_COUNT 128UL

// Event packet fixed text bounds.
#define KSWORD_ARK_CALLBACK_EVENT_MAX_INITIATOR_CHARS 260U
#define KSWORD_ARK_CALLBACK_EVENT_MAX_TARGET_CHARS 520U
#define KSWORD_ARK_CALLBACK_EVENT_MAX_PATTERN_CHARS 260U
#define KSWORD_ARK_CALLBACK_EVENT_MAX_NAME_CHARS 64U

typedef struct _KSWORD_ARK_GUID128
{
    unsigned char bytes[16];
} KSWORD_ARK_GUID128;

typedef struct _KSWORD_ARK_CALLBACK_RULE_BLOB_HEADER
{
    unsigned long size;
    unsigned long magic;
    unsigned long protocolVersion;
    unsigned long schemaVersion;
    unsigned long globalFlags;
    unsigned long groupCount;
    unsigned long ruleCount;
    unsigned long groupOffsetBytes;
    unsigned long ruleOffsetBytes;
    unsigned long stringOffsetBytes;
    unsigned long stringBytes;
    unsigned long crc32;
    unsigned long reserved;
    unsigned long long ruleVersion;
} KSWORD_ARK_CALLBACK_RULE_BLOB_HEADER;

typedef struct _KSWORD_ARK_CALLBACK_GROUP_BLOB
{
    unsigned long groupId;
    unsigned long flags;
    unsigned long priority;
    unsigned long reserved;
    unsigned long nameOffsetBytes;
    unsigned short nameLengthChars;
    unsigned short reserved2;
    unsigned long commentOffsetBytes;
    unsigned short commentLengthChars;
    unsigned short reserved3;
} KSWORD_ARK_CALLBACK_GROUP_BLOB;

typedef struct _KSWORD_ARK_CALLBACK_RULE_BLOB
{
    unsigned long ruleId;
    unsigned long groupId;
    unsigned long flags;
    unsigned long callbackType;
    unsigned long operationMask;
    unsigned long action;
    unsigned long matchMode;
    unsigned long priority;

    unsigned long initiatorOffsetBytes;
    unsigned short initiatorLengthChars;
    unsigned short reserved1;
    unsigned long targetOffsetBytes;
    unsigned short targetLengthChars;
    unsigned short reserved2;

    unsigned long askTimeoutMs;
    unsigned long askDefaultDecision;

    unsigned long ruleNameOffsetBytes;
    unsigned short ruleNameLengthChars;
    unsigned short reserved3;
    unsigned long commentOffsetBytes;
    unsigned short commentLengthChars;
    unsigned short reserved4;
} KSWORD_ARK_CALLBACK_RULE_BLOB;

typedef struct _KSWORD_ARK_CALLBACK_WAIT_REQUEST
{
    unsigned long size;
    unsigned long version;
    unsigned long waiterTag;
    unsigned long reserved;
} KSWORD_ARK_CALLBACK_WAIT_REQUEST;

typedef struct _KSWORD_ARK_CALLBACK_EVENT_PACKET
{
    unsigned long size;
    unsigned long version;
    KSWORD_ARK_GUID128 eventGuid;

    unsigned long callbackType;
    unsigned long operationType;
    unsigned long action;
    unsigned long matchMode;

    unsigned long defaultDecision;
    unsigned long timeoutMs;
    unsigned long groupId;
    unsigned long ruleId;

    unsigned long groupPriority;
    unsigned long rulePriority;
    unsigned long originatingPid;
    unsigned long originatingTid;
    unsigned long sessionId;
    unsigned long pathUnavailable;
    unsigned long reserved;

    unsigned long long createdAtUtc100ns;
    unsigned long long deadlineUtc100ns;

    wchar_t initiatorPath[KSWORD_ARK_CALLBACK_EVENT_MAX_INITIATOR_CHARS];
    wchar_t targetPath[KSWORD_ARK_CALLBACK_EVENT_MAX_TARGET_CHARS];
    wchar_t ruleInitiatorPattern[KSWORD_ARK_CALLBACK_EVENT_MAX_PATTERN_CHARS];
    wchar_t ruleTargetPattern[KSWORD_ARK_CALLBACK_EVENT_MAX_PATTERN_CHARS];
    wchar_t groupName[KSWORD_ARK_CALLBACK_EVENT_MAX_NAME_CHARS];
    wchar_t ruleName[KSWORD_ARK_CALLBACK_EVENT_MAX_NAME_CHARS];
} KSWORD_ARK_CALLBACK_EVENT_PACKET;

typedef struct _KSWORD_ARK_CALLBACK_ANSWER_REQUEST
{
    unsigned long size;
    unsigned long version;
    KSWORD_ARK_GUID128 eventGuid;
    unsigned long decision;
    unsigned long sourceSessionId;
    unsigned long reserved;
    unsigned long long answeredAtUtc100ns;
} KSWORD_ARK_CALLBACK_ANSWER_REQUEST;

typedef struct _KSWORD_ARK_CALLBACK_RUNTIME_STATE
{
    unsigned long size;
    unsigned long version;

    unsigned long driverOnline;
    unsigned long callbacksRegisteredMask;
    unsigned long globalEnabled;
    unsigned long rulesApplied;

    unsigned long groupCount;
    unsigned long ruleCount;
    unsigned long pendingDecisionCount;
    unsigned long waitingReceiverCount;

    unsigned long long appliedRuleVersion;
    unsigned long long appliedAtUtc100ns;

    // Raw NTSTATUS of each callback registration attempt. A driver that starts
    // in degraded mode keeps running with some of these set to a failure code,
    // so R3 can tell "capability disabled on this machine" apart from "driver
    // not loaded". Zero means the callback registered normally.
    long waitQueueStatus;
    long registryCallbackStatus;
    long processCallbackStatus;
    long threadCallbackStatus;
    long imageCallbackStatus;
    long objectCallbackStatus;
} KSWORD_ARK_CALLBACK_RUNTIME_STATE;

typedef struct _KSWORD_ARK_MINIFILTER_BYPASS_PID_REQUEST
{
    unsigned long size;
    unsigned long version;
    unsigned long pidCount;
    unsigned long flags;
    unsigned long processIds[KSWORD_ARK_MINIFILTER_BYPASS_PID_MAX_COUNT];
} KSWORD_ARK_MINIFILTER_BYPASS_PID_REQUEST;

typedef struct _KSWORD_ARK_MINIFILTER_BYPASS_PID_RESPONSE
{
    unsigned long size;
    unsigned long version;
    unsigned long pidCount;
    unsigned long flags;
    unsigned long processIds[KSWORD_ARK_MINIFILTER_BYPASS_PID_MAX_COUNT];
} KSWORD_ARK_MINIFILTER_BYPASS_PID_RESPONSE;

typedef struct _KSWORD_ARK_REMOVE_EXTERNAL_CALLBACK_REQUEST
{
    unsigned long size;
    unsigned long version;
    unsigned long callbackClass;
    unsigned long flags;
    unsigned long long callbackAddress;
} KSWORD_ARK_REMOVE_EXTERNAL_CALLBACK_REQUEST;

typedef struct _KSWORD_ARK_REMOVE_EXTERNAL_CALLBACK_RESPONSE
{
    unsigned long size;
    unsigned long version;
    unsigned long callbackClass;
    unsigned long reserved;
    unsigned long long callbackAddress;
    long ntstatus;
    unsigned long long moduleBase;
    unsigned long moduleSize;
    unsigned long mappingFlags;
    wchar_t modulePath[KSWORD_ARK_EXTERNAL_CALLBACK_MODULE_NAME_MAX_CHARS];
    wchar_t serviceName[KSWORD_ARK_EXTERNAL_CALLBACK_SERVICE_NAME_MAX_CHARS];
} KSWORD_ARK_REMOVE_EXTERNAL_CALLBACK_RESPONSE;

typedef struct _KSWORD_ARK_REMOVE_EXTERNAL_CALLBACK_EX_REQUEST
{
    unsigned long size;
    unsigned long version;
    unsigned long callbackClass;
    unsigned long flags;
    unsigned long long callbackAddress;
    // For a verified Object Callback row this is the actual RegistrationHandle
    // returned by ObRegisterCallbacks; nodes/callback pointers are forbidden substitutes.
    unsigned long long registrationAddress;
    // Exact diagnostic storage identity (for Object Callback, the list node),
    // carried separately so it can never be mistaken for RegistrationHandle.
    unsigned long long rawStorageValue;
    unsigned long long enumerationGeneration;
    unsigned long long identityHash;
    unsigned long source;
    unsigned long operationMask;
    unsigned long objectTypeMask;
    unsigned long trustFlags;
    unsigned long removeBehavior;
} KSWORD_ARK_REMOVE_EXTERNAL_CALLBACK_EX_REQUEST;

typedef struct _KSWORD_ARK_REMOVE_EXTERNAL_CALLBACK_EX_RESPONSE
{
    unsigned long size;
    unsigned long version;
    unsigned long callbackClass;
    unsigned long source;
    unsigned long long callbackAddress;
    unsigned long long registrationAddress;
    unsigned long long rawStorageValue;
    unsigned long long enumerationGeneration;
    unsigned long long identityHash;
    long ntstatus;
    long revalidationStatus;
    unsigned long trustFlags;
    unsigned long removeBehavior;
    unsigned long mappingFlags;
    unsigned long long moduleBase;
    unsigned long moduleSize;
    unsigned long reserved;
    wchar_t modulePath[KSWORD_ARK_EXTERNAL_CALLBACK_MODULE_NAME_MAX_CHARS];
    wchar_t serviceName[KSWORD_ARK_EXTERNAL_CALLBACK_SERVICE_NAME_MAX_CHARS];
    wchar_t message[KSWORD_ARK_CALLBACK_ENUM_DETAIL_CHARS];
} KSWORD_ARK_REMOVE_EXTERNAL_CALLBACK_EX_RESPONSE;

// V2 wire layout is retained verbatim so newer R0/R3 binaries can negotiate with older peers.
typedef struct _KSWORD_ARK_ENUM_CALLBACKS_REQUEST_V2
{
    unsigned long size;
    unsigned long version;
    unsigned long flags;
    unsigned long reserved;
    unsigned long maxEntries;
    unsigned long startIndex;
} KSWORD_ARK_ENUM_CALLBACKS_REQUEST_V2;

typedef struct _KSWORD_ARK_ENUM_CALLBACKS_REQUEST
{
    unsigned long size;
    unsigned long version;
    unsigned long flags;
    unsigned long reserved;
    unsigned long maxEntries;
    unsigned long startIndex;
    // V3 continuation pages echo the first page's complete ordered snapshot identity.
    unsigned long long expectedSnapshotHash;
    unsigned long expectedTotalCount;
    unsigned long snapshotPolicy;
} KSWORD_ARK_ENUM_CALLBACKS_REQUEST;

typedef struct _KSWORD_ARK_CALLBACK_ENUM_ENTRY
{
    unsigned long size;
    unsigned long callbackClass;
    unsigned long source;
    unsigned long status;
    unsigned long fieldFlags;
    unsigned long operationMask;
    unsigned long objectTypeMask;
    long lastStatus;
    unsigned long long callbackAddress;
    unsigned long long contextAddress;
    // A handle/cookie only when the corresponding field flags prove that meaning.
    unsigned long long registrationAddress;
    // Private storage/node identity used for revalidation, never as an API handle.
    unsigned long long rawStorageValue;
    // V3 publishes a whole-snapshot generation plus a stable identity for this logical row.
    unsigned long long enumerationGeneration;
    unsigned long long identityHash;
    unsigned long trustFlags;
    unsigned long removeBehavior;
    unsigned long long moduleBase;
    unsigned long moduleSize;
    unsigned long ownerRangeState;
    unsigned long registrationType;
    unsigned long reserved;
    wchar_t name[KSWORD_ARK_CALLBACK_ENUM_NAME_CHARS];
    wchar_t altitude[KSWORD_ARK_CALLBACK_ENUM_ALTITUDE_CHARS];
    wchar_t modulePath[KSWORD_ARK_CALLBACK_ENUM_MODULE_PATH_CHARS];
    wchar_t detail[KSWORD_ARK_CALLBACK_ENUM_DETAIL_CHARS];
    // Appended fields preserve the prefix layout consumed by older R3 clients.
    unsigned long detailCode;
    unsigned long detailReserved;
    unsigned long long detailArgs[KSWORD_ARK_CALLBACK_ENUM_DETAIL_ARG_COUNT];
} KSWORD_ARK_CALLBACK_ENUM_ENTRY;

// V2 header excludes snapshot metadata and therefore remains 32 bytes on both R0 and R3.
typedef struct _KSWORD_ARK_ENUM_CALLBACKS_RESPONSE_HEADER_V2
{
    unsigned long size;
    unsigned long version;
    unsigned long totalCount;
    unsigned long returnedCount;
    unsigned long entrySize;
    unsigned long flags;
    long lastStatus;
    unsigned long nextIndex;
} KSWORD_ARK_ENUM_CALLBACKS_RESPONSE_HEADER_V2;

// V2 response keeps the historical flexible-array wire offset for binary compatibility.
typedef struct _KSWORD_ARK_ENUM_CALLBACKS_RESPONSE_V2
{
    unsigned long size;
    unsigned long version;
    unsigned long totalCount;
    unsigned long returnedCount;
    unsigned long entrySize;
    unsigned long flags;
    long lastStatus;
    unsigned long nextIndex;
    KSWORD_ARK_CALLBACK_ENUM_ENTRY entries[1];
} KSWORD_ARK_ENUM_CALLBACKS_RESPONSE_V2;

typedef struct _KSWORD_ARK_ENUM_CALLBACKS_RESPONSE
{
    unsigned long size;
    unsigned long version;
    unsigned long totalCount;
    unsigned long returnedCount;
    unsigned long entrySize;
    unsigned long flags;
    long lastStatus;
    unsigned long nextIndex;
    // Both values currently identify the same ordered snapshot; separate fields preserve semantics.
    unsigned long long enumerationGeneration;
    unsigned long long snapshotHash;
    KSWORD_ARK_CALLBACK_ENUM_ENTRY entries[1];
} KSWORD_ARK_ENUM_CALLBACKS_RESPONSE;
