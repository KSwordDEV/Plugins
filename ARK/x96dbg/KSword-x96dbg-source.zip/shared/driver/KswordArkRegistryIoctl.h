#pragma once

#include "KswordArkProcessIoctl.h"

// ============================================================
// KswordArkRegistryIoctl.h
// 作用：
// - 定义 R3/R0 注册表查询与编辑协议；
// - 协议只承载路径、值名、类型和原始数据，不承载 UI 格式化细节。
// ============================================================

#define KSWORD_ARK_REGISTRY_PROTOCOL_VERSION 1UL

#define KSWORD_ARK_IOCTL_FUNCTION_READ_REGISTRY_VALUE 0x823UL
#define KSWORD_ARK_IOCTL_FUNCTION_ENUM_REGISTRY_KEY 0x840UL
#define KSWORD_ARK_IOCTL_FUNCTION_SET_REGISTRY_VALUE 0x841UL
#define KSWORD_ARK_IOCTL_FUNCTION_DELETE_REGISTRY_VALUE 0x842UL
#define KSWORD_ARK_IOCTL_FUNCTION_CREATE_REGISTRY_KEY 0x843UL
#define KSWORD_ARK_IOCTL_FUNCTION_DELETE_REGISTRY_KEY 0x844UL
#define KSWORD_ARK_IOCTL_FUNCTION_RENAME_REGISTRY_VALUE 0x845UL
#define KSWORD_ARK_IOCTL_FUNCTION_RENAME_REGISTRY_KEY 0x846UL

#define IOCTL_KSWORD_ARK_READ_REGISTRY_VALUE \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_READ_REGISTRY_VALUE, \
        METHOD_BUFFERED, \
        FILE_WRITE_ACCESS)

#define IOCTL_KSWORD_ARK_ENUM_REGISTRY_KEY \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_ENUM_REGISTRY_KEY, \
        METHOD_BUFFERED, \
        FILE_ANY_ACCESS)

#define IOCTL_KSWORD_ARK_SET_REGISTRY_VALUE \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_SET_REGISTRY_VALUE, \
        METHOD_BUFFERED, \
        FILE_WRITE_ACCESS)

#define IOCTL_KSWORD_ARK_DELETE_REGISTRY_VALUE \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_DELETE_REGISTRY_VALUE, \
        METHOD_BUFFERED, \
        FILE_WRITE_ACCESS)

#define IOCTL_KSWORD_ARK_CREATE_REGISTRY_KEY \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_CREATE_REGISTRY_KEY, \
        METHOD_BUFFERED, \
        FILE_WRITE_ACCESS)

#define IOCTL_KSWORD_ARK_DELETE_REGISTRY_KEY \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_DELETE_REGISTRY_KEY, \
        METHOD_BUFFERED, \
        FILE_WRITE_ACCESS)

#define IOCTL_KSWORD_ARK_RENAME_REGISTRY_VALUE \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_RENAME_REGISTRY_VALUE, \
        METHOD_BUFFERED, \
        FILE_WRITE_ACCESS)

#define IOCTL_KSWORD_ARK_RENAME_REGISTRY_KEY \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_RENAME_REGISTRY_KEY, \
        METHOD_BUFFERED, \
        FILE_WRITE_ACCESS)

#define KSWORD_ARK_REGISTRY_PATH_CHARS 512U
#define KSWORD_ARK_REGISTRY_VALUE_NAME_CHARS 256U
#define KSWORD_ARK_REGISTRY_DATA_MAX_BYTES 4096U
#define KSWORD_ARK_REGISTRY_ENUM_KEY_NAME_CHARS 256U
#define KSWORD_ARK_REGISTRY_ENUM_VALUE_DATA_MAX_BYTES 1024U
#define KSWORD_ARK_REGISTRY_ENUM_MAX_SUBKEYS 256U
#define KSWORD_ARK_REGISTRY_ENUM_MAX_VALUES 128U

#define KSWORD_ARK_REGISTRY_READ_FLAG_VALUE_NAME_PRESENT 0x00000001UL
#define KSWORD_ARK_REGISTRY_ENUM_FLAG_INCLUDE_SUBKEYS 0x00000001UL
#define KSWORD_ARK_REGISTRY_ENUM_FLAG_INCLUDE_VALUES 0x00000002UL
#define KSWORD_ARK_REGISTRY_ENUM_VALUE_FLAG_NAME_PRESENT 0x00000001UL
#define KSWORD_ARK_REGISTRY_SET_FLAG_VALUE_NAME_PRESENT 0x00000001UL
#define KSWORD_ARK_REGISTRY_DELETE_VALUE_FLAG_NAME_PRESENT 0x00000001UL

#define KSWORD_ARK_REGISTRY_READ_STATUS_UNKNOWN 0UL
#define KSWORD_ARK_REGISTRY_READ_STATUS_SUCCESS 1UL
#define KSWORD_ARK_REGISTRY_READ_STATUS_NOT_FOUND 2UL
#define KSWORD_ARK_REGISTRY_READ_STATUS_BUFFER_TOO_SMALL 3UL
#define KSWORD_ARK_REGISTRY_READ_STATUS_FAILED 4UL

#define KSWORD_ARK_REGISTRY_ENUM_STATUS_UNKNOWN 0UL
#define KSWORD_ARK_REGISTRY_ENUM_STATUS_SUCCESS 1UL
#define KSWORD_ARK_REGISTRY_ENUM_STATUS_NOT_FOUND 2UL
#define KSWORD_ARK_REGISTRY_ENUM_STATUS_PARTIAL 3UL
#define KSWORD_ARK_REGISTRY_ENUM_STATUS_FAILED 4UL

#define KSWORD_ARK_REGISTRY_OPERATION_STATUS_UNKNOWN 0UL
#define KSWORD_ARK_REGISTRY_OPERATION_STATUS_SUCCESS 1UL
#define KSWORD_ARK_REGISTRY_OPERATION_STATUS_NOT_FOUND 2UL
#define KSWORD_ARK_REGISTRY_OPERATION_STATUS_ALREADY_EXISTS 3UL
#define KSWORD_ARK_REGISTRY_OPERATION_STATUS_FAILED 4UL

typedef struct _KSWORD_ARK_READ_REGISTRY_VALUE_REQUEST
{
    unsigned long version;
    unsigned long flags;
    unsigned long maxDataBytes;
    unsigned long reserved;
    wchar_t keyPath[KSWORD_ARK_REGISTRY_PATH_CHARS];
    wchar_t valueName[KSWORD_ARK_REGISTRY_VALUE_NAME_CHARS];
} KSWORD_ARK_READ_REGISTRY_VALUE_REQUEST;

typedef struct _KSWORD_ARK_READ_REGISTRY_VALUE_RESPONSE
{
    unsigned long version;
    unsigned long status;
    unsigned long valueType;
    unsigned long dataBytes;
    unsigned long requiredBytes;
    long lastStatus;
    unsigned long reserved;
    unsigned char data[KSWORD_ARK_REGISTRY_DATA_MAX_BYTES];
} KSWORD_ARK_READ_REGISTRY_VALUE_RESPONSE;

typedef struct _KSWORD_ARK_ENUM_REGISTRY_KEY_ENTRY
{
    wchar_t name[KSWORD_ARK_REGISTRY_ENUM_KEY_NAME_CHARS];
} KSWORD_ARK_ENUM_REGISTRY_KEY_ENTRY;

typedef struct _KSWORD_ARK_ENUM_REGISTRY_VALUE_ENTRY
{
    unsigned long valueType;
    unsigned long dataBytes;
    unsigned long requiredBytes;
    unsigned long flags;
    wchar_t name[KSWORD_ARK_REGISTRY_VALUE_NAME_CHARS];
    unsigned char data[KSWORD_ARK_REGISTRY_ENUM_VALUE_DATA_MAX_BYTES];
} KSWORD_ARK_ENUM_REGISTRY_VALUE_ENTRY;

typedef struct _KSWORD_ARK_ENUM_REGISTRY_KEY_REQUEST
{
    unsigned long version;
    unsigned long flags;
    unsigned long maxSubKeys;
    unsigned long maxValues;
    unsigned long maxValueDataBytes;
    unsigned long reserved;
    wchar_t keyPath[KSWORD_ARK_REGISTRY_PATH_CHARS];
} KSWORD_ARK_ENUM_REGISTRY_KEY_REQUEST;

typedef struct _KSWORD_ARK_ENUM_REGISTRY_KEY_RESPONSE
{
    unsigned long version;
    unsigned long status;
    unsigned long subKeyCount;
    unsigned long returnedSubKeyCount;
    unsigned long valueCount;
    unsigned long returnedValueCount;
    long lastStatus;
    unsigned long reserved;
    KSWORD_ARK_ENUM_REGISTRY_KEY_ENTRY subKeys[KSWORD_ARK_REGISTRY_ENUM_MAX_SUBKEYS];
    KSWORD_ARK_ENUM_REGISTRY_VALUE_ENTRY values[KSWORD_ARK_REGISTRY_ENUM_MAX_VALUES];
} KSWORD_ARK_ENUM_REGISTRY_KEY_RESPONSE;

typedef struct _KSWORD_ARK_SET_REGISTRY_VALUE_REQUEST
{
    unsigned long version;
    unsigned long flags;
    unsigned long valueType;
    unsigned long dataBytes;
    wchar_t keyPath[KSWORD_ARK_REGISTRY_PATH_CHARS];
    wchar_t valueName[KSWORD_ARK_REGISTRY_VALUE_NAME_CHARS];
    unsigned char data[KSWORD_ARK_REGISTRY_DATA_MAX_BYTES];
} KSWORD_ARK_SET_REGISTRY_VALUE_REQUEST;

typedef struct _KSWORD_ARK_REGISTRY_VALUE_NAME_REQUEST
{
    unsigned long version;
    unsigned long flags;
    unsigned long reserved0;
    unsigned long reserved1;
    wchar_t keyPath[KSWORD_ARK_REGISTRY_PATH_CHARS];
    wchar_t valueName[KSWORD_ARK_REGISTRY_VALUE_NAME_CHARS];
} KSWORD_ARK_REGISTRY_VALUE_NAME_REQUEST;

typedef struct _KSWORD_ARK_REGISTRY_KEY_PATH_REQUEST
{
    unsigned long version;
    unsigned long flags;
    unsigned long reserved0;
    unsigned long reserved1;
    wchar_t keyPath[KSWORD_ARK_REGISTRY_PATH_CHARS];
} KSWORD_ARK_REGISTRY_KEY_PATH_REQUEST;

typedef struct _KSWORD_ARK_RENAME_REGISTRY_VALUE_REQUEST
{
    unsigned long version;
    unsigned long flags;
    unsigned long reserved0;
    unsigned long reserved1;
    wchar_t keyPath[KSWORD_ARK_REGISTRY_PATH_CHARS];
    wchar_t oldValueName[KSWORD_ARK_REGISTRY_VALUE_NAME_CHARS];
    wchar_t newValueName[KSWORD_ARK_REGISTRY_VALUE_NAME_CHARS];
} KSWORD_ARK_RENAME_REGISTRY_VALUE_REQUEST;

typedef struct _KSWORD_ARK_RENAME_REGISTRY_KEY_REQUEST
{
    unsigned long version;
    unsigned long flags;
    unsigned long reserved0;
    unsigned long reserved1;
    wchar_t keyPath[KSWORD_ARK_REGISTRY_PATH_CHARS];
    wchar_t newKeyName[KSWORD_ARK_REGISTRY_ENUM_KEY_NAME_CHARS];
} KSWORD_ARK_RENAME_REGISTRY_KEY_REQUEST;

typedef struct _KSWORD_ARK_REGISTRY_OPERATION_RESPONSE
{
    unsigned long version;
    unsigned long status;
    long lastStatus;
    unsigned long reserved;
} KSWORD_ARK_REGISTRY_OPERATION_RESPONSE;
