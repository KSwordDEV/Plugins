#pragma once

#include "KswordArkKernelIoctl.h"

// ============================================================
// KswordArkPlatformAuditIoctl.h
// 作用：
// - 定义 R3 <-> R0 HAL/WDF 审计协议与函数槽受控编辑协议；
// - 地址只在公开导出、WDF 绑定表或经过结构校验的表内读取；
// - 编辑按 scope/index 在 R0 重新定位槽位，并以表地址、旧值和原子 CAS
//   约束单个函数指针；不提供任意地址内存写入能力；
// - 可编辑 scope 为四个 HAL 子表与 WDF_FUNCTIONS。WDF_CALLBACKS 描述的是本
//   驱动自身 .text 内的编译期函数地址，没有可写槽，永远只读。
// ============================================================

#define KSWORD_ARK_PLATFORM_AUDIT_PROTOCOL_VERSION 5UL

#define KSWORD_ARK_IOCTL_FUNCTION_QUERY_PLATFORM_AUDIT 0x8E4UL
#define KSWORD_ARK_IOCTL_FUNCTION_CONTROL_PLATFORM_AUDIT 0x8E6UL
#define IOCTL_KSWORD_ARK_QUERY_PLATFORM_AUDIT \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_QUERY_PLATFORM_AUDIT, \
        METHOD_BUFFERED, \
        FILE_ANY_ACCESS)

#define IOCTL_KSWORD_ARK_CONTROL_PLATFORM_AUDIT \
    CTL_CODE( \
        KSWORD_ARK_IOCTL_DEVICE_TYPE, \
        KSWORD_ARK_IOCTL_FUNCTION_CONTROL_PLATFORM_AUDIT, \
        METHOD_BUFFERED, \
        FILE_WRITE_ACCESS)

#define KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_DISPATCH       0x00000001UL
#define KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_PRIVATE        0x00000002UL
#define KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_ACPI           0x00000004UL
#define KSWORD_ARK_PLATFORM_AUDIT_SCOPE_HAL_SUBCOMPONENTS  0x00000008UL
#define KSWORD_ARK_PLATFORM_AUDIT_SCOPE_WDF_FUNCTIONS      0x00000010UL
#define KSWORD_ARK_PLATFORM_AUDIT_SCOPE_WDF_CALLBACKS      0x00000020UL
#define KSWORD_ARK_PLATFORM_AUDIT_SCOPE_ALL                0x0000003FUL

#define KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNAVAILABLE       0UL
#define KSWORD_ARK_PLATFORM_AUDIT_STATUS_OK                1UL
#define KSWORD_ARK_PLATFORM_AUDIT_STATUS_PARTIAL           2UL
#define KSWORD_ARK_PLATFORM_AUDIT_STATUS_UNSUPPORTED       3UL
#define KSWORD_ARK_PLATFORM_AUDIT_STATUS_SIGNATURE_MISMATCH 4UL
#define KSWORD_ARK_PLATFORM_AUDIT_STATUS_QUERY_FAILED      5UL
#define KSWORD_ARK_PLATFORM_AUDIT_STATUS_BUFFER_TRUNCATED  6UL

#define KSWORD_ARK_PLATFORM_AUDIT_ROW_TABLE                1UL
#define KSWORD_ARK_PLATFORM_AUDIT_ROW_FUNCTION             2UL
#define KSWORD_ARK_PLATFORM_AUDIT_ROW_CALLBACK             3UL
#define KSWORD_ARK_PLATFORM_AUDIT_ROW_DIAGNOSTIC           4UL

#define KSWORD_ARK_PLATFORM_HOOK_UNKNOWN                   0UL
#define KSWORD_ARK_PLATFORM_HOOK_CLEAN                     1UL
#define KSWORD_ARK_PLATFORM_HOOK_SUSPICIOUS                2UL
#define KSWORD_ARK_PLATFORM_HOOK_UNSUPPORTED               3UL

#define KSWORD_ARK_PLATFORM_CONFIDENCE_NONE                0UL
#define KSWORD_ARK_PLATFORM_CONFIDENCE_LOW                25UL
#define KSWORD_ARK_PLATFORM_CONFIDENCE_MEDIUM             60UL
#define KSWORD_ARK_PLATFORM_CONFIDENCE_HIGH               90UL

#define KSWORD_ARK_PLATFORM_FIELD_LIVE_ADDRESS             0x00000001UL
#define KSWORD_ARK_PLATFORM_FIELD_ORIGINAL_ADDRESS         0x00000002UL
#define KSWORD_ARK_PLATFORM_FIELD_TABLE_ADDRESS            0x00000004UL
#define KSWORD_ARK_PLATFORM_FIELD_MODULE                   0x00000008UL
#define KSWORD_ARK_PLATFORM_FIELD_PROLOGUE_FORMAT          0x00000020UL
#define KSWORD_ARK_PLATFORM_FIELD_OWNER_VALIDATED          0x00000040UL
#define KSWORD_ARK_PLATFORM_FIELD_STRUCTURE_VALIDATED      0x00000080UL
#define KSWORD_ARK_PLATFORM_FIELD_EXACT_EXPORT             0x00000100UL
#define KSWORD_ARK_PLATFORM_FIELD_EXECUTABLE_VALIDATED     0x00000200UL
#define KSWORD_ARK_PLATFORM_FIELD_READ_ONLY_RANGE          0x00000400UL
#define KSWORD_ARK_PLATFORM_FIELD_DETAIL_ARGS              0x00000800UL
#define KSWORD_ARK_PLATFORM_FIELD_BASELINE_VALIDATED       0x00001000UL
#define KSWORD_ARK_PLATFORM_FIELD_LOCATOR_VALIDATED        0x00002000UL

#define KSWORD_ARK_PLATFORM_RESPONSE_TRUNCATED              0x00000001UL
#define KSWORD_ARK_PLATFORM_RESPONSE_PARTIAL                0x00000002UL
#define KSWORD_ARK_PLATFORM_RESPONSE_FAIL_CLOSED            0x00000004UL
#define KSWORD_ARK_PLATFORM_RESPONSE_NO_PDB                 0x00000008UL

#define KSWORD_ARK_PLATFORM_SIGNATURE_NONE                  0UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_PUBLIC_HAL_V6         1UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_PUBLIC_HAL_V4_V5      2UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_WDF_BINDING_TABLE     3UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_X64_PROLOGUE          4UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_EXACT_EXPORT_ONLY     5UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_RIP_RELATIVE_MASKED   6UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_HAL_PRIVATE_V54       7UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_HAL_PRIVATE_V58       8UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_HAL_PRIVATE_V61       9UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_HAL_ACPI_V5          10UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_HAL_SUBCOMPONENTS_22 11UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_HAL_PRIVATE_V51      12UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_HAL_SUBCOMPONENTS_21 13UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_HAL_ACPI_V4          14UL
#define KSWORD_ARK_PLATFORM_SIGNATURE_MAX \
    KSWORD_ARK_PLATFORM_SIGNATURE_HAL_ACPI_V4

#define KSWORD_ARK_PLATFORM_SLOT_UNSPECIFIED                0UL
#define KSWORD_ARK_PLATFORM_SLOT_FUNCTION                   1UL
#define KSWORD_ARK_PLATFORM_SLOT_SCALAR                     2UL
#define KSWORD_ARK_PLATFORM_SLOT_DUMMY                      3UL

#define KSWORD_ARK_PLATFORM_OWNER_NONE                      0UL
#define KSWORD_ARK_PLATFORM_OWNER_NT_HAL                    1UL
#define KSWORD_ARK_PLATFORM_OWNER_NT_HAL_PCI                2UL
#define KSWORD_ARK_PLATFORM_OWNER_NT_HAL_ACPI               3UL
#define KSWORD_ARK_PLATFORM_OWNER_WDF                       4UL
#define KSWORD_ARK_PLATFORM_OWNER_KSWORD                    5UL

#define KSWORD_ARK_PLATFORM_ORIGINAL_SOURCE_NONE            0UL
#define KSWORD_ARK_PLATFORM_ORIGINAL_SOURCE_DISK_IMAGE      1UL

// R0 只返回稳定 detailCode/参数；自然语言由 R3 根据当前语言包生成。
#define KSWORD_ARK_PLATFORM_DETAIL_NONE                     0UL
#define KSWORD_ARK_PLATFORM_DETAIL_OWNER_CONSISTENT         1UL
#define KSWORD_ARK_PLATFORM_DETAIL_OWNER_MISMATCH           2UL
#define KSWORD_ARK_PLATFORM_DETAIL_NON_EXECUTABLE           3UL
#define KSWORD_ARK_PLATFORM_DETAIL_NULL_SLOT                4UL
#define KSWORD_ARK_PLATFORM_DETAIL_READ_FAILED              5UL
#define KSWORD_ARK_PLATFORM_DETAIL_BUILD_UNSUPPORTED        6UL
#define KSWORD_ARK_PLATFORM_DETAIL_VERSION_MISMATCH         7UL
#define KSWORD_ARK_PLATFORM_DETAIL_RANGE_INVALID            8UL
#define KSWORD_ARK_PLATFORM_DETAIL_LOCATOR_NOT_UNIQUE       9UL
#define KSWORD_ARK_PLATFORM_DETAIL_LOCATOR_NOT_FOUND       10UL
#define KSWORD_ARK_PLATFORM_DETAIL_TABLE_INVALID           11UL
#define KSWORD_ARK_PLATFORM_DETAIL_MODULE_SNAPSHOT_FAILED  12UL
#define KSWORD_ARK_PLATFORM_DETAIL_SCALAR_VALUE            13UL
#define KSWORD_ARK_PLATFORM_DETAIL_DUMMY_SLOT              14UL
#define KSWORD_ARK_PLATFORM_DETAIL_DETOUR_EXTERNAL         15UL
#define KSWORD_ARK_PLATFORM_DETAIL_DETOUR_SAME_OWNER       16UL
#define KSWORD_ARK_PLATFORM_DETAIL_FORMAT_RECOGNIZED       17UL
#define KSWORD_ARK_PLATFORM_DETAIL_FORMAT_UNKNOWN          18UL
#define KSWORD_ARK_PLATFORM_DETAIL_WDF_TABLE_INVALID       19UL
#define KSWORD_ARK_PLATFORM_DETAIL_WDF_INDEX_INVALID       20UL
#define KSWORD_ARK_PLATFORM_DETAIL_ACPI_V5_VALIDATED       21UL
#define KSWORD_ARK_PLATFORM_DETAIL_SUBCOMPONENT_VALIDATED  22UL
#define KSWORD_ARK_PLATFORM_DETAIL_BASELINE_MATCH          23UL
#define KSWORD_ARK_PLATFORM_DETAIL_BASELINE_MISMATCH       24UL

#define KSWORD_ARK_PLATFORM_CONTROL_FLAG_UI_CONFIRMED       0x00000001UL
// 历史上只有 HAL 槽可编辑，令牌沿用 'HALE'；协议 v5 起同一令牌也覆盖
// WDF_FUNCTIONS 槽，改值只会让新旧二进制互相拒绝，没有额外安全收益。
#define KSWORD_ARK_PLATFORM_CONTROL_CONFIRMATION_TOKEN      0x48414C45UL /* 'HALE' */

#define KSWORD_ARK_PLATFORM_CONTROL_STATUS_OK                    0UL
#define KSWORD_ARK_PLATFORM_CONTROL_STATUS_INVALID_REQUEST       1UL
#define KSWORD_ARK_PLATFORM_CONTROL_STATUS_CONFIRMATION_REQUIRED 2UL
#define KSWORD_ARK_PLATFORM_CONTROL_STATUS_UNSUPPORTED           3UL
#define KSWORD_ARK_PLATFORM_CONTROL_STATUS_STALE_SNAPSHOT        4UL
#define KSWORD_ARK_PLATFORM_CONTROL_STATUS_TARGET_INVALID        5UL
#define KSWORD_ARK_PLATFORM_CONTROL_STATUS_WRITE_FAILED          6UL
#define KSWORD_ARK_PLATFORM_CONTROL_STATUS_SAFETY_DENIED         7UL

#define KSWORD_ARK_PLATFORM_CONTROL_RESPONSE_CHANGED             0x00000001UL
#define KSWORD_ARK_PLATFORM_CONTROL_RESPONSE_TARGET_EXECUTABLE   0x00000002UL
#define KSWORD_ARK_PLATFORM_CONTROL_RESPONSE_TABLE_REVALIDATED   0x00000004UL
// 槽位所在节不可写（KMDF 绑定表就在 Wdf01000.sys 的只读节里），R0 先建立
// MDL 可写别名再 CAS。HVCI 会拒绝提权，此时返回 WRITE_FAILED 且不置该位。
#define KSWORD_ARK_PLATFORM_CONTROL_RESPONSE_ALIAS_WRITE         0x00000008UL

#define KSWORD_ARK_PLATFORM_DEFAULT_MAX_ROWS 1024UL
#define KSWORD_ARK_PLATFORM_HARD_MAX_ROWS    1024UL

#define KSWORD_ARK_PLATFORM_NAME_CHARS        96U
#define KSWORD_ARK_PLATFORM_MODULE_PATH_CHARS 260U
#define KSWORD_ARK_PLATFORM_DETAIL_ARG_COUNT   4U

typedef struct _KSWORD_ARK_QUERY_PLATFORM_AUDIT_REQUEST
{
    // 说明：R3 只传入范围掩码和行预算，R0 会拒绝未知版本与保留字段。
    unsigned long size;
    unsigned long version;
    unsigned long scopeMask;
    unsigned long maxRows;
    unsigned long flags;
    unsigned long reserved0;
} KSWORD_ARK_QUERY_PLATFORM_AUDIT_REQUEST;

typedef struct _KSWORD_ARK_PLATFORM_AUDIT_ENTRY
{
    // 说明：统一承载 HAL 表项、WDF 函数、WDF 回调和显式降级诊断。
    unsigned long size;
    unsigned long scope;
    unsigned long rowKind;
    unsigned long status;
    unsigned long hookStatus;
    unsigned long confidence;
    unsigned long fieldFlags;
    unsigned long signatureId;
    unsigned long slotKind;
    unsigned long ownerPolicy;
    unsigned long entryIndex;
    long lastStatus;
    unsigned long moduleSize;
    unsigned long prologueSignatureId;
    unsigned long originalAddressSource;
    unsigned long reserved0;
    unsigned long long liveAddress;
    unsigned long long originalAddress;
    unsigned long long tableAddress;
    unsigned long long moduleBase;
    unsigned long long detailArgs[KSWORD_ARK_PLATFORM_DETAIL_ARG_COUNT];
    unsigned long detailCode;
    unsigned long reserved1;
    wchar_t name[KSWORD_ARK_PLATFORM_NAME_CHARS];
    wchar_t modulePath[KSWORD_ARK_PLATFORM_MODULE_PATH_CHARS];
} KSWORD_ARK_PLATFORM_AUDIT_ENTRY;

typedef struct _KSWORD_ARK_QUERY_PLATFORM_AUDIT_RESPONSE
{
    // 说明：METHOD_BUFFERED 可变长响应，R3 必须同时校验 entrySize 和 returnedCount。
    unsigned long size;
    unsigned long version;
    unsigned long queryStatus;
    unsigned long scopeMask;
    unsigned long responseFlags;
    unsigned long totalCount;
    unsigned long returnedCount;
    unsigned long entrySize;
    unsigned long buildNumber;
    unsigned long signaturePolicyFlags;
    long lastStatus;
    unsigned long reserved0;
    KSWORD_ARK_PLATFORM_AUDIT_ENTRY entries[1];
} KSWORD_ARK_QUERY_PLATFORM_AUDIT_RESPONSE;

typedef struct _KSWORD_ARK_CONTROL_PLATFORM_AUDIT_REQUEST
{
    // R3 提交刷新时的身份快照；R0 不直接使用 tableAddress 计算写地址。
    unsigned long size;
    unsigned long version;
    unsigned long scope;
    unsigned long entryIndex;
    unsigned long flags;
    unsigned long confirmationToken;
    unsigned long reserved0;
    unsigned long reserved1;
    unsigned long long tableAddress;
    unsigned long long expectedValue;
    unsigned long long newValue;
} KSWORD_ARK_CONTROL_PLATFORM_AUDIT_REQUEST;

typedef struct _KSWORD_ARK_CONTROL_PLATFORM_AUDIT_RESPONSE
{
    unsigned long size;
    unsigned long version;
    unsigned long status;
    unsigned long scope;
    unsigned long entryIndex;
    unsigned long responseFlags;
    long lastStatus;
    unsigned long reserved0;
    unsigned long long tableAddress;
    unsigned long long slotAddress;
    unsigned long long previousValue;
    unsigned long long currentValue;
    unsigned long long requestedValue;
} KSWORD_ARK_CONTROL_PLATFORM_AUDIT_RESPONSE;
